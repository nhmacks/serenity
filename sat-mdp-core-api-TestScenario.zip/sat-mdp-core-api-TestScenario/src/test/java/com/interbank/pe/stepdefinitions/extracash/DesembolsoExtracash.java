package com.interbank.pe.stepdefinitions.extracash;

import com.interbank.pe.model.Extracash.DesembolsoIncrementoLinea.Request.*;
import com.interbank.pe.model.Extracash.ofertaAjusta.OfertaAjustadaResponseError;
import com.interbank.pe.model.cliente.cuentas.CuentaAhorros;
import com.interbank.pe.model.cliente.cuentas.response.Account;
import com.interbank.pe.questions.Extracash.OfertaAjustadaMensajeError;
import com.interbank.pe.questions.VerificaCodigoRespuesta;
import com.interbank.pe.questions.cliente.accounts.DatosDeLaCuenta;
import com.interbank.pe.questions.cliente.accounts.ObtenerCuentaAhorros;
import com.interbank.pe.stepdefinitions.accounts.RegistroDeCuenta;
import com.interbank.pe.tasks.extracash.DesembolsarExtracashIncrementoLinea;
import com.interbank.pe.utils.soap.UtilsTarjeta;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.util.EnvironmentVariables;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.CoreMatchers.equalTo;

public class DesembolsoExtracash {
    private EnvironmentVariables environmentVariables;
    String clienteTarjetaCredito = theActorInTheSpotlight().recall("pan");
    String clienteMontoCampanna = theActorInTheSpotlight().recall("montoCampanna");
    String clienteTipoDocumento = theActorInTheSpotlight().recall("tipoDocumento");
    String clienteLineaCreditoTC = theActorInTheSpotlight().recall("lineaCreditoTC");
    String clienteCodigoCliente = theActorInTheSpotlight().recall("codigoCliente");
    String clienteNumeroContratoTC = theActorInTheSpotlight().recall("numeroContratoTC");

    String clienteNumeroDocumento = theActorInTheSpotlight().recall("numeroDocumento");

    String cardIdtType = "";

    private final RequestDesembolsoIncrementoLinea request = new RequestDesembolsoIncrementoLinea();
    private final CommonData commonData = new CommonData();
    private final IdentityDocument identityDocument = new IdentityDocument();
    private final Transaction transaction = new Transaction();
    private final ExchangeRate exchangeRate = new ExchangeRate();
    private final PaymentMethod paymentMethod = new PaymentMethod();
    private final CustomerAccount customerAccount = new CustomerAccount();
    private final AccountId accountId = new AccountId();
    private final AccountNum accountNum = new AccountNum();
    private final List<PaymentMethod> paymentMethodList = new ArrayList<>();
    String rqIdentityDocumentType;
    String rqIdentityDocumentId;
    String rqTransactionCurrencyId;
    Double rqTransactionAmount;
    Double rqExchangeRateBuy;
    Double rqExchangeRateSale;
    String rqPaymentMethodsId;
    String rqPaymentMethodsOperationType;
    String rqPaymentMethodsCurrencyId;
    Double rqPaymentMethodsAmount;
    String rqPaymentMethodsEquivalentCurrency;
    String rqAccountIdBankId;
    String rqAccountIdCurrencyId;
    String rqAccountIdProductId;
    String rqAccountNumBranchId;
    String rqAccountNumAccountHost;
    String rqCardId;
    String rqReferenceId;
    String rqDocumentType;
    Double rqDisbursementAmount;
    Integer rqPayTerm;
    Double rqInstallmentAmount;
    String rqMinimumTerm;
    String rqMaximumTerm;
    Double rqDeferredInterestAmount;
    Double rqFinancedAmount;
    String rqFirstDueDate;
    Double rqInsuranceAmount;
    String rqInsuranceFlag;
    Double rqNewLineAmount;
    Integer rqCellphone;
    String rqSystemType;
    @Steps
    RegistroDeCuenta registroDeCuenta;
    String caAccountNumber;

    @And("el {} cuenta con una cuenta de ahorro")
    public void elClienteCuentaConUnaCuentaDeAhorro(String actor) {
        CuentaAhorros cuentaAhorros = new ObtenerCuentaAhorros(this.clienteCodigoCliente).answeredBy(theActorInTheSpotlight());
        this.caAccountNumber = cuentaAhorros.getNumCuentaAhorro();
        System.out.println("Numero de cuenta de ahorros del cliente: " + this.caAccountNumber);
        // SI EL CLIENTE NO TIENE CUENTA DE AHORRO, CREAR CUENTA DE AHORRO
        if (cuentaAhorros.getNumCuentaAhorro() == null) {
            registroDeCuenta.clienteGeneraTokenDeSesion(actor);
            registroDeCuenta.realizaAltaDeUnaCuentaDeAhorro();
            registroDeCuenta.guardarLosDatosDeLaCuentaEnElTXTCuentaCliente();
            Account account = new DatosDeLaCuenta().answeredBy(theActorInTheSpotlight()).getAccounts().get(0);
            this.caAccountNumber = account.getAccountNumber();
        }
    }

    @And("indica realizar desembolso de campaña extracash por {string}")
    public void indicaRealizarDesembolsoDeCampannaExtracashPor(String flujo) {
        if (Objects.equals(flujo, "PAN en claro")) {
            this.cardIdtType = "0";
            this.rqCardId = clienteTarjetaCredito;
        } else if (Objects.equals(flujo, "PAN truncado mas codigo unico")) {
            this.cardIdtType = "1";
            this.rqReferenceId = clienteCodigoCliente.replaceFirst("^0+(?!$)", "");
            this.rqCardId = UtilsTarjeta.truncarPAN(clienteTarjetaCredito);
        } else if ((Objects.equals(flujo, "PAN truncado mas documento de identidad"))) {
            this.cardIdtType = "2";
            this.rqDocumentType = clienteTipoDocumento;
            this.rqReferenceId = clienteNumeroDocumento;
            this.rqCardId = UtilsTarjeta.truncarPAN(clienteTarjetaCredito);
        } else if ((Objects.equals(flujo, "PAN truncado mas numero de cuenta"))) {
            this.cardIdtType = "3";
            this.rqReferenceId = clienteNumeroContratoTC;
            this.rqCardId = UtilsTarjeta.truncarPAN(clienteTarjetaCredito);
        }
        this.rqIdentityDocumentType = clienteTipoDocumento;
        this.rqIdentityDocumentId = clienteNumeroDocumento;

        this.rqTransactionCurrencyId = "001";
        this.rqTransactionAmount = Double.parseDouble(clienteMontoCampanna);

        this.rqExchangeRateBuy = 0.0;
        this.rqExchangeRateSale = 0.0;

        this.rqPaymentMethodsId = "04";
        this.rqPaymentMethodsOperationType = "A";
        this.rqPaymentMethodsCurrencyId = "001";
        this.rqPaymentMethodsAmount = Double.parseDouble(clienteMontoCampanna);
        this.rqPaymentMethodsEquivalentCurrency = "001";

        this.rqAccountIdBankId = "03";
        this.rqAccountIdCurrencyId = "001";
        this.rqAccountIdProductId = "002";

        this.rqAccountNumBranchId = caAccountNumber.substring(0, 3);
        this.rqAccountNumAccountHost = caAccountNumber.substring(3);
        this.rqDisbursementAmount = Double.parseDouble(clienteMontoCampanna);
        this.rqPayTerm = 12;
        this.rqInstallmentAmount = 142.65;
        this.rqMinimumTerm = "00";
        this.rqMaximumTerm = "00";
        this.rqDeferredInterestAmount = 0.0;
        this.rqFinancedAmount = 1506.36;
        this.rqFirstDueDate = "20230701";
        this.rqInsuranceAmount = 0.0;
        this.rqInsuranceFlag = "N";
        this.rqNewLineAmount = Double.parseDouble(clienteMontoCampanna);
        this.rqCellphone = 999999999;
        this.rqSystemType = "G";
    }

    @When("realiza el alta de extracash")
    public void realiza_el_alta_de_extracash() {
        identityDocument.setType(rqIdentityDocumentType);
        identityDocument.setId(rqIdentityDocumentId);
        transaction.setCurrencyId(rqTransactionCurrencyId);
        transaction.setAmount(rqTransactionAmount);
        exchangeRate.setBuy(rqExchangeRateBuy);
        exchangeRate.setSale(rqExchangeRateSale);
        paymentMethod.setId(rqPaymentMethodsId);
        paymentMethod.setOperationType(rqPaymentMethodsOperationType);
        paymentMethod.setCurrencyId(rqPaymentMethodsCurrencyId);
        paymentMethod.setAmount(rqPaymentMethodsAmount);
        paymentMethod.setEquivalentCurrency(rqPaymentMethodsEquivalentCurrency);
        paymentMethodList.add(paymentMethod);

        accountId.setBankId(rqAccountIdBankId);
        accountId.setCurrencyId(rqAccountIdCurrencyId);
        accountId.setProductId(rqAccountIdProductId);

        accountNum.setBranchId(rqAccountNumBranchId);
        accountNum.setAccountHost(rqAccountNumAccountHost);

        request.setCardId(rqCardId);
        request.setReferenceId(rqReferenceId);
        request.setDocumentType(rqDocumentType);
        request.setDisbursementAmount(rqDisbursementAmount);
        request.setPayTerm(rqPayTerm);
        request.setInstallmentAmount(rqInstallmentAmount);
        request.setMinimumTerm(rqMinimumTerm);
        request.setMaximumTerm(rqMaximumTerm);
        request.setDeferredInterestAmount(rqDeferredInterestAmount);
        request.setFinancedAmount(rqFinancedAmount);
        request.setFirstDueDate(rqFirstDueDate);
        request.setInsuranceAmount(rqInsuranceAmount);
        request.setInsuranceFlag(rqInsuranceFlag);
        request.setNewLineAmount(rqNewLineAmount);
        request.setCellphone(rqCellphone);
        request.setSystemType(rqSystemType);

        customerAccount.setAccountNum(accountNum);
        customerAccount.setAccountId(accountId);
        paymentMethod.setCustomerAccount(customerAccount);
        commonData.setPaymentMethods(paymentMethodList);
        commonData.setExchangeRate(exchangeRate);
        commonData.setTransaction(transaction);
        commonData.setIdentityDocument(identityDocument);
        request.setCommonData(commonData);
        theActorInTheSpotlight().whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri9")));
        theActorInTheSpotlight().attemptsTo(DesembolsarExtracashIncrementoLinea.enCuenta(this.cardIdtType, request));
    }

    @And("el sistema retorna el mensaje no procede financiamiento")
    public void elSistemaRetornaElMensajeNoProcedeFinanciamiento() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0251")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("CDQO330  ATC0251 MENSAJE MPA0664 - NO PROCEDE FINA NCIAMIENTO, CONSUMO EXCED")
                        )
                );
    }

    @And("indica como monto de extracash a desembolsar {string}")
    public void indicaComoMontoDeExtracashADesembolsar(String montoDesembolso) {
        this.rqDisbursementAmount = Double.parseDouble(montoDesembolso);
        this.rqNewLineAmount = Double.parseDouble(clienteLineaCreditoTC);
    }

    @And("indica realizar desembolso de campaña extracash a {string} cuotas")
    public void indicaRealizarDesembolsoDeCampannaExtracashACuotas(String numeroCuotas) {
        this.rqPayTerm = Integer.parseInt(numeroCuotas);
    }

    @And("el sistema de simulacion retorna el mensaje error plazo no permitido")
    public void elSistemaDeSimulacionRetornaElMensajeErrorPlazoNoPermitido() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("6021")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("CDQO330  CDQ6021 PLAZO NO PERMITIDO"))
                );
    }

    @And("el sistema de simulacion retorna el mensaje error plazo seleccionado es zero")
    public void elSistemaDeSimulacionRetornaElMensajeErrorPlazoSeleccionadoEsZero() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0004")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("BSEX330O  ERROR PLAZO SELECCIONADO ES ZEROS"))
                );
    }

    @And("no especifica monto de extracash a desembolsar")
    public void noEspecificaMontoDeExtracashADesembolsar() {
        this.rqDisbursementAmount = 0.00;
    }

    @And("el sistema de desembolso extracash retorna el mensaje importe desembolso es zeros")
    public void elSistemaDeDesembolsoExtracashRetornaElMensajeImporteDesembolsoEsZeros() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0002")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("BSEX330O  ERROR IMPORTE DESEMBOLSO ES ZEROS"))
                );
    }

    @And("especifica como tarjeta de credito a desembolsar extracash una tarjeta invalida")
    public void especificaComoTarjetaDeCreditoADesembolsarExtracashUnaTarjetaInvalida() {
        this.rqCardId = "9999999999999999";
    }

    @And("el sistema de desembolso de extracash retorna el mensaje tarjeta no existe")
    public void elSistemaDeDesembolsoDeExtracashRetornaElMensajeTarjetaNoExiste() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("01 0")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERROR TARJETA NO EXISTE"))
                );
    }


    @And("no especifica monto de nueva linea de tarjeta de credito")
    public void noEspecificaMontoDeNuevaLineaDeTarjetaDeCredito() {
        this.rqNewLineAmount = 0.0;
    }

}
