package com.interbank.pe.stepdefinitions.servicios;

import com.interbank.pe.model.Extracash.ofertaAjusta.OfertaAjustadaResponseError;
import com.interbank.pe.model.MovimientosTC;
import com.interbank.pe.model.cuotas.Request.PaseCuotasRequest;
import com.interbank.pe.model.cuotas.TransactionInstallment;
import com.interbank.pe.questions.Extracash.OfertaAjustadaMensajeError;
import com.interbank.pe.questions.VerificaCodigoRespuesta;
import com.interbank.pe.questions.VerificaMensaje;
import com.interbank.pe.questions.cuotas.VerificaTransaccionEnCuotas;
import com.interbank.pe.tasks.card.PagoDeServicio;
import com.interbank.pe.tasks.card.SimulacionDePago;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Entonces;
import io.cucumber.java.es.Y;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.util.EnvironmentVariables;
import org.hamcrest.CoreMatchers;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.CoreMatchers.*;

public class SimulacionDeCuotasStepDefs {
    public Actor Actor;
    PaseCuotasRequest rqCuotas = new PaseCuotasRequest();
    private EnvironmentVariables environmentVariables;
    String fechaFactura = "2022-03-23";
    String numCuotas = "1";
    String moneda = MovimientosTC.getResponseCollection("currency");
    String monto = MovimientosTC.getResponseCollection("amount");
    String numeroExtracto = MovimientosTC.getResponseCollection("numeroExtracto");
    String tarjetaCredito = MovimientosTC.getResponseCollection("card").trim();
    String numeroMovimientoExtracto = MovimientosTC.getResponseCollection("numeroMovimientoExtracto").trim();

    @Entonces("^simula pasar a \"([^\"]*)\" cuotas el movimiento seleccionado$")
    public void realiza_la_simulacion_de_pase_a_cuotas(String cuota) {
        this.numCuotas = cuota;
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente")
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")));
        Actor.attemptsTo(
                SimulacionDePago.EnCuotas(cuota)
        );
    }


    @Cuando("^procede a confirmar pasar a cuotas la operacion$")
    public void procede_a_confirmar_pasar_la_operacion_en_cuotas() {

        rqCuotas.setTotalInstallments(this.numCuotas);
        rqCuotas.setTransactionCurrency(this.moneda);
        rqCuotas.setDocumentType(1);
        rqCuotas.setInvoiceAmount(this.monto);
        rqCuotas.setInvoiceDate(this.fechaFactura);
        rqCuotas.setExtracNumber(this.numeroExtracto);

        theActorInTheSpotlight().whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")));
        theActorInTheSpotlight().attemptsTo(
                PagoDeServicio.EnCuotas(rqCuotas, tarjetaCredito, numeroMovimientoExtracto)
        );
    }

    @Entonces("^Verifica el nombre de la compañia sea (.*)$")
    public void verifica_que_el_nombre_de_la_compannia(String company_name) {
        TransactionInstallment trx = new VerificaTransaccionEnCuotas().answeredBy(Actor);
        Actor.should(
                seeThat(VerificaCodigoRespuesta.delServicio(), equalTo(200)),
                seeThat("Muestra dia de pago", actor -> trx.getPaymentDate(), notNullValue()),
                seeThat("El nombre de la compañia es ",act -> trx.getCompanyName(),containsString(company_name)),
                seeThat("Muestra monto a pagar por cuota",actor -> trx.getAmount(),notNullValue()),
                seeThat("Muestra Numero de transaccion", actor -> trx.getTransactionNumber(),notNullValue()),
                seeThat("Muestra Fecha de Liquidacion", actor -> trx.getSettlementDate(), notNullValue())
        );
    }


    @Cuando("^Mensaje del proveedor es (.*)")
    public void mensaje_del_proveedor_es_MPA_NO_PROCEDE_TRASLADO_CONSUMO_EXCEDE_LA_LINEA_CRED(String mensaje) {
        Actor.should(
                seeThat("Mensaje de proveedor", VerificaMensaje.ejecucionConExito(), containsString(mensaje))
        );

    }

    @Y("^simula pasar a cuotas el movimiento seleccionado$")
    public void simulaPasarACuotasElMovimientoSeleccionado() {
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente")
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")));
        Actor.attemptsTo(
                SimulacionDePago.EnCuotas("4")
        );
    }


    @And("el sistema retorna el mensaje ERROR LINEA-NO-ASIGNADA")
    public void elSistemaRetornaElMensajeERRORLINEANOASIGNADA() {
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight().should(seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), CoreMatchers.equalTo("403")));
        theActorInTheSpotlight().should(seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), CoreMatchers.equalTo("Business error")));
        theActorInTheSpotlight().should(seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), CoreMatchers.equalTo("0004")));
        theActorInTheSpotlight().should(seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), CoreMatchers.equalTo("ERROR LINEA-NO-ASIGNADA")));
    }

    @Entonces("coloca la operacion realizada en \"([^\"]*)\" cuotas$")
    public void coloca_la_operacion_realizada_en_cuotas(String cuota) {
        this.numCuotas = cuota;
        theActorInTheSpotlight()
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")))
                .attemptsTo(SimulacionDePago.EnCuotas(cuota));
    }

    @Entonces("la transaccion pasada en cuentas desaparece de los movimientos en la tarjeta del cliente")
    public void la_transaccion_pasada_en_cuentas_desaparece_de_los_movimientos_en_la_tarjeta_del_cliente(String cuota) {
        theActorInTheSpotlight()
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")))
                .attemptsTo(SimulacionDePago.EnCuotas(cuota));
    }

    @And("no especifica el numero de cuotas")
    public void noEspecificaElNumeroDeCuotas() {
        this.numCuotas = "";
    }

    @And("especifica como moneda de operacion una moneda invalida")
    public void especificaComoMonedaDeOperacionUnaMonedaInvalida() {
        this.moneda = "XX";
    }

    @And("ingresa datos invalidos como numero de cuotas {string}")
    public void ingresaDatosInvalidosComoNumeroDeCuotas(String numCuotas) {
        this.numCuotas = numCuotas;
    }

    @And("no especifica la moneda de la operacion en cuotas")
    public void noEspecificaLaMonedaDeLaOperacionEnCuotas() {
        this.moneda = "";
    }

    @And("especifica como moneda de operacion una moneda no existente")
    public void especificaComoMonedaDeOperacionUnaMonedaNoExistente() {
        this.moneda = "999";
    }

    @And("especifica un monto de factura diferente al movimiento generado anteriormente")
    public void especificaUnMontoDeFacturaDiferenteAlMovimientoGeneradoAnteriormente() {
        this.monto = "999";
    }

    @And("especifica un dato invalido como monto de la factura")
    public void especificaUnDatoInvalidoComoMontoDeLaFactura() {
        this.monto = "XXX";
    }

    @Then("el sistema retornara mensaje solicitud incorrecta")
    public void elSistemaRetornaraMensajeSolicitudIncorrecta() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 400", VerificaCodigoRespuesta.delServicio(), equalTo(400)));
    }

    @And("no especifica datos como monto de factura")
    public void noEspecificaDatosComoMontoDeFactura() {
        this.monto = "";
    }

    @And("no especifica datos como fecha de factura")
    public void noEspecificaDatosComoFechaDeFactura() {
        this.fechaFactura = "";
    }

    @And("especifica datos invalidos como fecha de factura")
    public void especificaDatosInvalidosComoFechaDeFactura() {
        this.fechaFactura = "%#$%.";
    }

    @And("no especifica datos como numero de extracto")
    public void noEspecificaDatosComoNumeroDeExtracto() {
        this.numeroExtracto = "";
    }

    @And("especifica datos invalidos como numero de extracto")
    public void especificaDatosInvalidosComoNumeroDeExtracto() {
        this.numeroExtracto = "XPXXP";
    }

    @And("especifica un numero de extracto diferente a la operacion realizada anteriormente")
    public void especificaUnNumeroDeExtractoDiferenteALaOperacionRealizadaAnteriormente() {
        this.numeroExtracto = "99";
    }

    @Then("el sistema retornara mensaje no existe registro para el criterio")
    public void elSistemaRetornaraMensajeNoExisteRegistroParaElCriterio() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0016")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("MPA0070 - NO EXISTE REGIST    ARA EL CRITERIO DE SE"))
                );
    }

    @And("ingresa una tarjeta de credito en formato truncado")
    public void ingresaUnaTarjetaDeCreditoEnFormatoTruncado() {
        this.tarjetaCredito = "99999XXXXXX999999";
    }

    @Then("el sistema retornara mensaje INGRESAR PAN EN CLARO")
    public void elSistemaRetornaraMensajeINGRESARPANENCLARO() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0079")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("CDIOA04 INGRESAR PAN EN CLARO"))
                );
    }

    @And("ingresa una tarjeta de credito no existente")
    public void ingresaUnaTarjetaDeCreditoNoExistente() {
        this.tarjetaCredito = "9999999999999999";
    }

    @Then("el sistema retornara mensaje TARJETA NO HALLADA")
    public void elSistemaRetornaraMensajeTARJETANOHALLADA() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0016")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("TARJETA NO HALLADA"))
                );
    }
}
