package com.interbank.pe.runners;


import com.interbank.pe.utils.JiraXrayOperation;
import io.cucumber.junit.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import java.util.logging.Logger;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(
        plugin = {
                  "json:target/cucumber/cucumber.json",
                  "pretty"
                 },
        features = "src/test/resources/features/",
        glue = {"com.interbank.pe.stepdefinitions","com.interbank.pe.Hooks"},
        tags = "@MBLI2-1364",
        publish = true
        )


public class RunnerTest {

    @BeforeClass
    public static void beforeAll(){
        Logger.getLogger(RunnerTest.class.getName()).info("Before all execution >>>");
    }

    @AfterClass
    public static void afterAll(){
        Logger.getLogger(RunnerTest.class.getName()).info("After all execution >>>");
        JiraXrayOperation.importCucumberResult("/target/cucumber/cucumber.json");
    }
}