package com.interbank.pe.stepdefinitions.servicios;

import com.interbank.pe.model.Extracash.ofertaAjusta.OfertaAjustadaResponseError;
import com.interbank.pe.model.MovimientosTC;
import com.interbank.pe.model.Transaccion.TransaccionCuotas.TransaccionCuotas;
import com.interbank.pe.model.tarjeta.Tarjeta;
import com.interbank.pe.questions.Extracash.OfertaAjustadaMensajeError;
import com.interbank.pe.questions.movimientos.ObtenerMovimientos;
import com.interbank.pe.questions.Transaccion.TransaccionCuotas.ObtenerTransaccionCuotas;
import com.interbank.pe.questions.VerificaCodigoRespuesta;
import com.interbank.pe.questions.VerificaMensaje;
import com.interbank.pe.questions.tarjeta.ListarTarjetas;
import com.interbank.pe.questions.tarjeta.PagoMinFull;
import com.interbank.pe.questions.tarjeta.VerificarSaldo;
import com.interbank.pe.tasks.card.ConsultarTarjetaTC;
import com.interbank.pe.tasks.card.GuardarDatosAntiguos;
import com.interbank.pe.tasks.card.GuardarDatosPagoLiquidacion;
import com.interbank.pe.tasks.services.ConsultaCuotasTransaccion;
import com.interbank.pe.tasks.services.PagoDeServicio;
import com.interbank.pe.tasks.services.colocaciones.Abonar;
import com.interbank.pe.utils.soap.Moneda;
import com.interbank.pe.utils.soap.UtilsCampanna;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java.es.Dado;
import io.cucumber.java.es.Entonces;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.util.EnvironmentVariables;

import java.util.HashMap;
import java.util.List;
import java.util.Objects;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorCalled;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.CoreMatchers.*;

public class PayServicesStepDefs {
    public Actor Actor;
    public String tarjeta;
    public String contrato;
    public String monto;
    public String codigoUnico;
    public String moneda;

    private EnvironmentVariables environmentVariables;
    public static final String MSJCONFORME = "EJECUCION CON EXITO";

    @Dado("^el cliente realiza una compra (.*) con la tarjeta \"([^\"]*)\" por el monto \"([^\"]*)\" en moneda \"([^\"]*)\"$")
    public void cliente_realiza_un_consumo_con_la_tarjeta_por_el_monto_en_moneda(String flujo, String tarjeta, String monto, String moneda) {
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente").whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri7")));
        Actor.attemptsTo(PagoDeServicio.EnEfectivo(flujo, tarjeta, monto, moneda));
        Actor.should(seeThat(VerificaCodigoRespuesta.delServicio(), equalTo(200)));
        Actor.should(seeThat("Verifica que el servicio contenga el mensaje ", VerificaMensaje.ejecucionConExito(), containsString(MSJCONFORME)));
    }

    @Entonces("^verifica codigo de respuesta$")
    public void verifica_codigo_de_respuesta() {
        Actor.should(seeThat(VerificaCodigoRespuesta.delServicio(), equalTo(200)));

    }

    @Entonces("^Verifica que se haya realizado la compra con exito$")
    public void verifica_realizar_la_compra_con_exito() {
        Actor.should(seeThat(VerificaMensaje.ejecucionConExito(), equalTo("EJECUCION CON EXITO")));
    }

    @Dado("^genera un abono por el flujo (.*) a su TC \"([^\"]*)\" con \"([^\"]*)\" en \"([^\"]*)\" y \"([^\"]*)\"$")
    public void genera_el_abono_a_su_TC_con_en_y(String flujo, String tarjeta, String contrato, String moneda, String monto) {
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente").whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri3")));
        Actor.attemptsTo(Abonar.enTarjetaCredito(flujo, tarjeta, contrato, moneda, monto, "28345"));
        Actor.should(seeThat(VerificaCodigoRespuesta.delServicio(), equalTo(200)));
        Actor.should(seeThat("Verifica que el servicio contenga el mensaje ", VerificaMensaje.ejecucionConExito(), containsString(MSJCONFORME)));
    }

    //Toma TC del archivo tarjeta cliente para los escenarios GIRU y PASARELLA

    @Given("que el cliente tiene tarjeta de credito activa")
    public void queElClienteTieneTarjetaDeCreditoActiva() {
        List<Tarjeta> tarjetaList = new ListarTarjetas().answeredBy(Actor);
        for (Tarjeta tarjeta : tarjetaList) {
            this.tarjeta = tarjeta.getCard();
            this.contrato = tarjeta.getContrato();
            this.codigoUnico = tarjeta.getCustomerType();
            System.out.println("Tarjeta " + this.tarjeta);
            System.out.println("Contrato " + this.contrato);
            System.out.println("Codigo Unico " + this.codigoUnico);
            break;
        }
    }

    //Flujo premia
    @Given("que el {} tiene tarjeta de credito del tipo {string} activa")
    public void queElClienteTieneTarjetaDeCreditoDelTipoActiva(String Actor, String producto) {
        theActorCalled(Actor);
        List<Tarjeta> tarjetaList = new ListarTarjetas().answeredBy(theActorInTheSpotlight());
        for (Tarjeta tarjeta : tarjetaList) {
            if (Objects.equals(tarjeta.getDescription(), producto)) {
                this.tarjeta = tarjeta.getCard();
                this.contrato = tarjeta.getContrato();
                this.codigoUnico = tarjeta.getCustomerType();
                MovimientosTC.setResponseCollection("card", this.tarjeta);
                break;
            }
        }
    }


    @And("mediante el flujo {}, selecciona el cupon a canjear en {string}")
    public void medianteElFlujoPREMIASeleccionaElCuponACanjearEn(String flujo, String monto) {
        this.monto = monto;
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente").whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri3")));
        Actor.attemptsTo(Abonar.enTarjetaCredito(flujo, this.tarjeta, this.contrato, "001", monto, "800331"));
        Actor.should(seeThat(VerificaCodigoRespuesta.delServicio(), equalTo(200)));
        Actor.should(seeThat("Verifica que el servicio contenga el mensaje ", VerificaMensaje.ejecucionConExito(), containsString(MSJCONFORME)));
    }

    //Flujo Giru

    @And("revisa el saldo disponible de su tarjeta antes del reclamo")
    public void revisaElSaldoDisponibleDeSuTarjetaAntesDelReclamo() {
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente")
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")));
        Actor.attemptsTo(
                ConsultarTarjetaTC.obtenerDatos(this.tarjeta, this.codigoUnico)
        );
        Actor.should(
                seeThat(VerificaCodigoRespuesta.delServicio(), equalTo(200)
                ));
        Actor.attemptsTo(
                GuardarDatosAntiguos.deLaTC()
        );
    }

    @And("mediante el flujo {}, genero un reclamo por cobro indebido con {string} en {string} y {string}")
    public void medianteElFlujoGIRUGeneroUnReclamoPorCobroIndebidoConEnY(String flujo, String codigoFactura, String monto, String moneda) {
        this.monto = monto;
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente").whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri3")));
        Actor.attemptsTo(Abonar.enTarjetaCredito(flujo, this.tarjeta, this.contrato, moneda, monto, codigoFactura));
        Actor.should(seeThat(VerificaCodigoRespuesta.delServicio(), equalTo(200)));
        Actor.should(seeThat("Verifica que el servicio contenga el mensaje ", VerificaMensaje.ejecucionConExito(), containsString(MSJCONFORME)));
    }

    @And("genera un abono por el flujo {} en {string} y {string}")
    public void generaUnAbonoPorElFlujoPASARELLA_ABONAREnY(String flujo, String monto, String moneda) {
        this.monto = monto;
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente").whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri3")));
        Actor.attemptsTo(Abonar.enTarjetaCredito(flujo, this.tarjeta, this.contrato, moneda, this.monto, "28345"));
        Actor.should(seeThat(VerificaCodigoRespuesta.delServicio(), equalTo(200)));
        Actor.should(seeThat("Verifica que el servicio contenga el mensaje ", VerificaMensaje.ejecucionConExito(), containsString(MSJCONFORME)));
    }

    @Then("verifica que el saldo ha sido actualizado")
    public void verificaQueElSaldoHaSidoActualizado() {
        Actor.should(
                seeThat(VerificarSaldo.deTarjeta())
        );
    }

//Codigo validacion de transaccion

    @Then("se visualizara el detalle la operacion realizada {}")
    public void seVisualizaraElDetalleLaOperacionRealizadaPAGOCONTARJOTROBA(String nombreComercio) {
        HashMap<String, String> consumo = new ObtenerMovimientos().answeredBy(Actor);
        System.out.println("consumo" + consumo);
        System.out.println("fechaFactura" + consumo.get("fechaFactura"));
        Actor.should(
                seeThat("TEST", act -> consumo.get("nombreComercioReducido"), equalTo(nombreComercio)),
                seeThat("TEST", act -> consumo.get("importeFactura"), equalTo(this.monto))
        );
    }

    //codigo pago min y full
    @Given("que el cliente consulta el pago minimo de su tarjeta {string} con {string}")
    public void queElClienteConsultaElPagoMinimoDeSuTarjetaCon(String tarjeta, String codigoUnico) {
        this.tarjeta = tarjeta;
        this.codigoUnico = codigoUnico;
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente")
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")));
        Actor.attemptsTo(
                ConsultarTarjetaTC.obtenerDatos(this.tarjeta, this.codigoUnico)
        );
        Actor.should(
                seeThat(VerificaCodigoRespuesta.delServicio(), equalTo(200)
                ));
        Actor.attemptsTo(
                GuardarDatosPagoLiquidacion.deLaTC()
        );
    }

    @When("genera el pago minimo por el flujo {} a su TC {string} y {string}")
    public void generaElPagoMinimoPorElFlujoASuTCY(String flujo, String contrato, String moneda) {
        if (Objects.equals(moneda, "soles")) {
            this.monto = com.interbank.pe.model.Tarjeta.getResponseCollection("AntespagoMinimoSoles");
        } else if (Objects.equals(moneda, "dolares")) {
            this.monto = com.interbank.pe.model.Tarjeta.getResponseCollection("AntespagoMinimoDolares");
        }
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente").whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri3")));
        Actor.attemptsTo(Abonar.enTarjetaCredito(flujo, this.tarjeta, contrato, moneda, this.monto, "28345"));
        Actor.should(seeThat(VerificaCodigoRespuesta.delServicio(), equalTo(200)));
        Actor.should(seeThat("Verifica que el servicio contenga el mensaje ", VerificaMensaje.ejecucionConExito(), containsString(MSJCONFORME)));
    }

    @Given("que el cliente consulta el pago full de su tarjeta {string} con {string}")
    public void queElClienteConsultaElPagoFullDeSuTarjetaCon(String tarjeta, String codigoUnico) {
        this.tarjeta = tarjeta;
        this.codigoUnico = codigoUnico;
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente")
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")));
        Actor.attemptsTo(
                ConsultarTarjetaTC.obtenerDatos(this.tarjeta, this.codigoUnico)
        );
        Actor.should(
                seeThat(VerificaCodigoRespuesta.delServicio(), equalTo(200)
                ));
        Actor.attemptsTo(
                GuardarDatosPagoLiquidacion.deLaTC()
        );
    }

    @Then("al consultar nuevamente el pago full verifica que no presenta deuda pendiente en el mes")
    public void alConsultarNuevamenteElPagoFullVerificaQueNoPresentaDeudaPendienteEnElMes() {
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente")
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")));
        Actor.attemptsTo(
                ConsultarTarjetaTC.obtenerDatos(this.tarjeta, this.codigoUnico)
        );
        Actor.should(seeThat(PagoMinFull.Liquidacion()));
    }

    @Then("verifica que no tiene pago minimo pendiente a la fecha")
    public void verificaQueNoTienePagoMinimoPendienteALaFecha() {
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente")
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")));
        Actor.attemptsTo(
                ConsultarTarjetaTC.obtenerDatos(this.tarjeta, this.codigoUnico)
        );
        Actor.should(seeThat(PagoMinFull.Liquidacion()));
    }

    @When("genera el pago full por el flujo {} a su TC {string} y {string}")
    public void generaElPagoFullPorElFlujoPASARELLA_ABONARASuTCY(String flujo, String contrato, String moneda) {
        Moneda moneda1 = Moneda.SOLES;
        if ((moneda1 == Moneda.SOLES)) {
            this.monto = com.interbank.pe.model.Tarjeta.getResponseCollection("AntespagoTotalSoles");
        } else if ((moneda1 == Moneda.DOLARES)) {
            this.monto = com.interbank.pe.model.Tarjeta.getResponseCollection("AntespagoTotalDolares");
        }
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente").whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri3")));
        System.out.println("monto:" + this.monto);
        Actor.attemptsTo(Abonar.enTarjetaCredito(flujo, this.tarjeta, contrato, moneda, this.monto, "28345"));
        Actor.should(seeThat(VerificaCodigoRespuesta.delServicio(), equalTo(200)));
        Actor.should(seeThat("Verifica que el servicio contenga el mensaje ", VerificaMensaje.ejecucionConExito(), containsString(MSJCONFORME)));
    }


    @When("genera un abono por el flujo {} a su TC {string} y {string}")
    public void generaUnAbonoPorElFlujoAPP_ABONARASuTCY(String flujo, String contrato, String moneda) {
        if (Objects.equals(moneda, "soles")) {
            this.monto = com.interbank.pe.model.Tarjeta.getResponseCollection("AntespagoMinimoSoles");
        } else if (Objects.equals(moneda, "dolares")) {
            this.monto = com.interbank.pe.model.Tarjeta.getResponseCollection("AntespagoMinimoDolares");
        }
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente").whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri3")));
        Actor.attemptsTo(Abonar.enTarjetaCredito(flujo, this.tarjeta, contrato, moneda, this.monto, "990028345"));
        Actor.should(seeThat(VerificaCodigoRespuesta.delServicio(), equalTo(200)));
        Actor.should(seeThat("Verifica que el servicio contenga el mensaje ", VerificaMensaje.ejecucionConExito(), containsString(MSJCONFORME)));
    }

    @When("realiza pago de servicio {string} en {string} en {string}")
    public void realizaPagoDeServicioEnEn(String flujo, String monto, String moneda) {
        this.monto = monto;
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente").whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri7")));
        Actor.attemptsTo(PagoDeServicio.EnEfectivo(flujo, this.tarjeta, monto, moneda));
        Actor.should(seeThat(VerificaCodigoRespuesta.delServicio(), equalTo(200)));
        Actor.should(seeThat("Verifica que el servicio contenga el mensaje ", VerificaMensaje.ejecucionConExito(), containsString(MSJCONFORME)));
    }

    @Then("la operacion se proceso correctamente")
    public void laOperacionSeProcesoCorrectamente() {
        System.out.println("----------------------");
        System.out.println("Tarjeta: " + this.tarjeta);
        System.out.println("Contrato: " + this.contrato);
        System.out.println("Monto: " + this.monto);
        System.out.println("----------------------");
    }

    @And("genera una operacion con su tarjeta de credito por el monto de {string}")
    public void generaUnaOperacionConSuTarjetaDeCreditoPorElMontoDe(String monto) {
        String clienteCard = theActorInTheSpotlight().recall("card");
        theActorInTheSpotlight()
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri7")))
                .attemptsTo(PagoDeServicio.EnEfectivo("BENEFIT", clienteCard, monto, "604"));
        theActorInTheSpotlight()
                .should(
                        seeThat("Estado del servicio es 200 ", VerificaCodigoRespuesta.delServicio(), equalTo(200)),
                        seeThat("Mensaje: EJECUCION CON EXITO", VerificaMensaje.ejecucionConExito(), containsString("EJECUCION CON EXITO"))
                );
    }

    @And("se debe visualizar la transaccion en cuotas")
    public void seDebeVisualizarLaTransaccionEnCuotas() {

        theActorInTheSpotlight().whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri9")));
        theActorInTheSpotlight().attemptsTo(ConsultaCuotasTransaccion.cliente());
        theActorInTheSpotlight()
                .should(
                        seeThat("Estado del servicio es 200 ", VerificaCodigoRespuesta.delServicio(), equalTo(200))
                );

        TransaccionCuotas transaccionCuotas = new ObtenerTransaccionCuotas().answeredBy(theActorInTheSpotlight());


        theActorInTheSpotlight()
                .should(
                        seeThat("Numero de columnas", x -> transaccionCuotas.getRowsNumber(), notNullValue()),
                        seeThat("Currency", x -> transaccionCuotas.getCurrency(), equalTo("604")),
                        seeThat("Operation Fig Pag", x -> transaccionCuotas.getOperationFigPag(), equalTo("1")),
                        seeThat("Operation End Date", x -> transaccionCuotas.getOperationEndDate(), notNullValue()),
                        seeThat("Continue Flag", x -> transaccionCuotas.getContinueFlag(), equalTo("N")),
                        seeThat("Beneficiary Type", x -> transaccionCuotas.getBeneficiaryType(), equalTo("TI")),
                        seeThat("AccountHost", x -> transaccionCuotas.getAccountHost(), notNullValue()),
                        seeThat("Office", x -> transaccionCuotas.getOffice(), equalTo("0100")),
                        seeThat("getIdentityId", x -> transaccionCuotas.getIdentityId(), equalTo("0003")),
                        seeThat("getCardId", x -> transaccionCuotas.getCardId(), notNullValue()),
                        seeThat("getPayBalance", x -> transaccionCuotas.getInstallments().get(0).getPayBalance(), notNullValue()),
                        seeThat("getLiquidatedNumberShare", x -> transaccionCuotas.getInstallments().get(0).getLiquidatedNumberShare(), equalTo("0")),
                        seeThat("getCurrentNumberShare", x -> transaccionCuotas.getInstallments().get(0).getCurrentNumberShare(), equalTo("0")),
                        seeThat("getInstallmentsTotal", x -> transaccionCuotas.getInstallments().get(0).getInstallmentsTotal(), notNullValue()),
                        seeThat("getLoanAmount", x -> transaccionCuotas.getInstallments().get(0).getLoanAmount(), notNullValue()),
                        seeThat("getTotalAmount", x -> transaccionCuotas.getInstallments().get(0).getTotalAmount(), notNullValue()),
                        seeThat("getCommerce", x -> transaccionCuotas.getInstallments().get(0).getCommerce(), notNullValue()),
                        seeThat("getInstallmentsPassDate", x -> transaccionCuotas.getInstallments().get(0).getInstallmentsPassDate(), equalTo(UtilsCampanna.fechaActual())),
                        seeThat("getProcessHour", x -> transaccionCuotas.getInstallments().get(0).getProcessHour(), notNullValue()),
                        seeThat("getProcessDate", x -> transaccionCuotas.getInstallments().get(0).getProcessDate(), equalTo(UtilsCampanna.fechaActual())),
                        seeThat("getOperationCurrency", x -> transaccionCuotas.getInstallments().get(0).getOperationCurrency(), equalTo("604")),
                        seeThat("getFinancingNumber", x -> transaccionCuotas.getInstallments().get(0).getFinancingNumber(), equalTo("1")),
                        seeThat("getLoanOperation", x -> transaccionCuotas.getInstallments().get(0).getLoanOperation(), notNullValue()),
                        seeThat("getOperationDate", x -> transaccionCuotas.getInstallments().get(0).getOperationDate(), notNullValue())
                );
    }

    @Then("la transaccion pasada en cuotas desaparece de los en la tarjeta del cliente")
    public void laTransaccionPasadaEnCuotasDesapareceDeLosEnLaTarjetaDelCliente() {
        theActorInTheSpotlight().should(seeThat(VerificaCodigoRespuesta.delServicio(), equalTo(200)));
    }

    @Then("el sistema de cuotas retorna el mensaje error en total cuotas")
    public void elSistemaDeCuotasRetornaElMensajeErrorEnTotalCuotas() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0004")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERROR EN TOTAL CUOTAS                              -CDIO023"))
                );
    }


    @Then("el sistema de cuotas retorna el mensaje el registro no se encuentra en la base de datos")
    public void elSistemaDeCuotasRetornaElMensajeElRegistroNoSeEncuentraEnLaBaseDeDatos() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0016")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("MPE0005 - EL REGISTRO NO E    E EN LA B.D."))
                );
    }

    @Then("el sistema retornara mensaje error en datos")
    public void elSistemaRetornaraMensajeErrorEnDatos() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0016")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERROR EN DATOS                                     -CDOO075"))
                );
    }


    @And("genera una operacion con su tarjeta de credito con monto igual a su linea de credito")
    public void generaUnaOperacionConSuTarjetaDeCreditoConMontoIgualASuLineaDeCredito() {
        String clienteLineaCredito = theActorInTheSpotlight().recall("lineaCredito");
        String clienteCard = theActorInTheSpotlight().recall("card");
        System.out.println("Linea Credito cliente" + clienteLineaCredito);
        theActorInTheSpotlight()
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri7")))
                .attemptsTo(PagoDeServicio.EnEfectivo("BENEFIT", clienteCard, clienteLineaCredito, "604"));
        theActorInTheSpotlight()
                .should(
                        seeThat("Estado del servicio es 200 ", VerificaCodigoRespuesta.delServicio(), equalTo(200)),
                        seeThat("Mensaje: EJECUCION CON EXITO", VerificaMensaje.ejecucionConExito(), containsString("EJECUCION CON EXITO"))
                );
    }

    @And("genera una operacion {string} en {string} en {string}")
    public void generaUnaOperacionEnEn(String flujo, String monto, String moneda) {
        String clienteLineaCredito = theActorInTheSpotlight().recall("lineaCredito");
        String clienteCard = theActorInTheSpotlight().recall("card");
        theActorInTheSpotlight()
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri7")))
                .attemptsTo(PagoDeServicio.EnEfectivo(flujo, clienteCard, clienteLineaCredito, moneda));
        theActorInTheSpotlight()
                .should(
                        seeThat("Estado del servicio es 200 ", VerificaCodigoRespuesta.delServicio(), equalTo(200)),
                        seeThat("Mensaje: EJECUCION CON EXITO", VerificaMensaje.ejecucionConExito(), containsString("EJECUCION CON EXITO"))
                );
    }

    @And("cuenta con {} movimientos realizados sobre su tarjeta de credito")
    public void cuentaConMovimientosRealizadosSobreSuTarjetaDeCredito(int cantMovimientos) {
        String card = MovimientosTC.getResponseCollection("card");
        for (int x = 0; x <= cantMovimientos; x++) {
            theActorInTheSpotlight()
                    .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri7")))
                    .attemptsTo(PagoDeServicio.EnEfectivo("CORECSALEASING", card, "15.00", "604"));
            theActorInTheSpotlight()
                    .should(
                            seeThat("Estado del servicio es 200 ", VerificaCodigoRespuesta.delServicio(), equalTo(200)),
                            seeThat("Mensaje: EJECUCION CON EXITO", VerificaMensaje.ejecucionConExito(), containsString("EJECUCION CON EXITO"))
                    );
        }


    }

    @And("tiene movimientos realizados sobre su tarjeta de credito")
    public void tieneMovimientosRealizadosSobreSuTarjetaDeCredito() {
        String card = MovimientosTC.getResponseCollection("card");
        System.out.println("tarjeta: " + card);
        theActorInTheSpotlight()
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri7")))
                .attemptsTo(PagoDeServicio.EnEfectivo("CORECSALEASING", card, "15.00", "604"));
        theActorInTheSpotlight()
                .should(
                        seeThat("Estado del servicio es 200 ", VerificaCodigoRespuesta.delServicio(), equalTo(200)),
                        seeThat("Mensaje: EJECUCION CON EXITO", VerificaMensaje.ejecucionConExito(), containsString("EJECUCION CON EXITO"))
                );
    }
}
