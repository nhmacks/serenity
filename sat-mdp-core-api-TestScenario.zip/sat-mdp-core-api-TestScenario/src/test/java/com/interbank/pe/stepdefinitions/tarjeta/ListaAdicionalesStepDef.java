package com.interbank.pe.stepdefinitions.tarjeta;

import com.interbank.pe.model.Extracash.ofertaAjusta.OfertaAjustadaResponseError;
import com.interbank.pe.model.tarjeta.InformacionTC.Response.ResponseListaTCAdicional;
import com.interbank.pe.questions.Extracash.OfertaAjustadaMensajeError;
import com.interbank.pe.questions.tarjeta.ListarTCadicionales;
import com.interbank.pe.tasks.card.ListaTCAdicionales;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.util.EnvironmentVariables;
import org.hamcrest.CoreMatchers;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorCalled;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.CoreMatchers.notNullValue;

public class ListaAdicionalesStepDef {
    String codigoUnico;
    private EnvironmentVariables environmentVariables;

    //Escenario Negativos
    @Given("que no es un cliente de Interbank")
    public void queNoEsUnClienteDeInterbank() {

    }

    @When("intenten consultar su informacion")
    public void intentenConsultarSuInformacion() {

    }

    @Then("se debera mostrar el siguiente mensaje {string}")
    public void seDeberaMostrarElSiguienteMensaje(String arg0) {
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight().should(seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), CoreMatchers.equalTo("403")));
        theActorInTheSpotlight().should(seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), CoreMatchers.equalTo("Business error")));
        theActorInTheSpotlight().should(seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), CoreMatchers.equalTo("0059")));
        theActorInTheSpotlight().should(seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), CoreMatchers.equalTo("ERROR IMPORTE CUOTA MAYOR CEM")));

    }

    @Then("se debera mostrar todas las tarjetas donde es beneficiario")
    public void seDeberaMostrarTodasLasTarjetasDondeEsBeneficiario() {

    }

    @Given("que el cliente es titular en un contrato")
    public void queElClienteEsTitularEnUnContrato() {

    }

    @When("consulte su informacion")
    public void consulteSuInformacion() {
        theActorInTheSpotlight().whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")))
                .attemptsTo(ListaTCAdicionales.delCliente(this.codigoUnico));
    }

    @Given("que el cliente es titular")
    public void queElClienteEsTitular() {

    }

    @And("ese contrato cuenta con tarjetas adicionales")
    public void eseContratoCuentaConTarjetasAdicionales() {

    }

    @Given("que el cliente es beneficiario en dos contratos")
    public void queElClienteEsBeneficiarioEnDosContratos() {

    }

    @Given("que el cliente es beneficiario en un contrato")
    public void queElClienteEsBeneficiarioEnUnContrato() {
        //Traer un cliente
        //Generar datos de un cliente adicional
        //Crear al cliente

    }

    @Then("se debera mostrar la tarjeta donde es beneficiario")
    public void seDeberaMostrarLaTarjetaDondeEsBeneficiario() {

    }

    @And("es titular en otro con tarjeta sin acusar")
    public void esTitularEnOtroConTarjetaSinAcusar() {

    }

    @Then("se debera  mostrar solo la tarjeta donde es beneficiario")
    public void seDeberaMostrarSoloLaTarjetaDondeEsBeneficiario() {

    }

    @And("es titular en otro con bloqueo de cuenta")
    public void esTitularEnOtroConBloqueoDeCuenta() {

    }

    @Given("que el cliente es beneficiario en un contrato con tarjeta sin acusar")
    public void queElClienteEsBeneficiarioEnUnContratoConTarjetaSinAcusar() {

    }

    @And("es titular en otro con tarjeta activa")
    public void esTitularEnOtroConTarjetaActiva() {

    }

    @Given("que el cliente es beneficiario en un contrato con tarjeta bloqueada")
    public void queElClienteEsBeneficiarioEnUnContratoConTarjetaBloqueada() {

    }

    @Given("que el cliente es beneficiario en un contrato con tarjeta activa")
    public void queElClienteEsBeneficiarioEnUnContratoConTarjetaActiva() {

    }

    @And("en dos contratos con tarjeta sin acusar")
    public void enDosContratosConTarjetaSinAcusar() {

    }

    @Given("que el cliente es beneficiario en dos contratos con tarjeta activa")
    public void queElClienteEsBeneficiarioEnDosContratosConTarjetaActiva() {

    }

    @And("en dos contratos con tarjeta bloqueada")
    public void enDosContratosConTarjetaBloqueada() {

    }

    @Given("que el cliente es beneficiario en un contrato con tarjeta activa, en otro contrato con tarjeta sin acusar")
    public void queElClienteEsBeneficiarioEnUnContratoConTarjetaActivaEnOtroContratoConTarjetaSinAcusar() {

    }

    @And("en otro contratos con tarjeta bloqueada")
    public void enOtroContratosConTarjetaBloqueada() {

    }

    @Then("retorna la lista de datos de la cuenta")
    public void retornaLaListaDeDatosDeLaCuenta() {
        //Modelo            variable =                  new Question
        ResponseListaTCAdicional responseListaTCAdicional = new ListarTCadicionales().answeredBy(theActorInTheSpotlight());
        System.out.println("Cantidad de tarejtas" + responseListaTCAdicional.getItems());
        System.out.println("Lista de tarjetas" + responseListaTCAdicional.getCard().get(0).getNumber());
        System.out.println("Lista de tarjetas" + responseListaTCAdicional.getCard().get(1).getNumber());
        theActorInTheSpotlight().should(seeThat(actor -> responseListaTCAdicional.getCard().get(0).getNumber(), notNullValue()));


    }


    @Given("que el {} es beneficiario en cuatro contratos {string}")
    public void queElClienteEsBeneficiarioEnCuatroContratos(String actor, String codigoUnico) {
        theActorCalled(actor);
        this.codigoUnico = codigoUnico;

    }
}
