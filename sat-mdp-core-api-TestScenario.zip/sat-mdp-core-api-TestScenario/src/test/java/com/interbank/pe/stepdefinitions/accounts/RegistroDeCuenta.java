package com.interbank.pe.stepdefinitions.accounts;

import com.interbank.pe.model.cliente.Token.TokenResponse;
import com.interbank.pe.model.cliente.cliente.RequestCrearCliente.Clientes;
import com.interbank.pe.model.cliente.cuentas.request.*;
import com.interbank.pe.questions.VerificaCodigoRespuesta;
import com.interbank.pe.questions.cliente.Token.ObtenerToken;
import com.interbank.pe.questions.cliente.accounts.ListarClientesSinCuentaAhorro;
import com.interbank.pe.tasks.cliente.Cuenta.AltaDeCuenta;
import com.interbank.pe.tasks.cliente.Cuenta.GuardarDatosDeCuenta;
import com.interbank.pe.tasks.cliente.Token.GeneraToken;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.util.EnvironmentVariables;

import java.util.ArrayList;
import java.util.List;

import static com.interbank.pe.utils.soap.UtilsCliente.obtenerTipoDocumento;
import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorCalled;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.Matchers.equalTo;

public class RegistroDeCuenta {


    private EnvironmentVariables environmentVariables;
    AccountRequest accountRequest;
    Account account;
    Customer customer;
    IdentityDocument identityDocument;
    Email email;
    Phone phone;
    private String token;
    List<Phone> phones;
    List<Email> emails;
    List<Customer> customers;
    List<Account> accounts;


    String tipoDocumento;
    String codigoCliente;
    String numeroDocumento;

    @Given("cliente se encuentra onbordeado")
    public void clienteSeEncuentraOnbordeado() {
    }

    @And("quiere una cuenta de ahorros")
    public void quiereUnaCuentaDeAhorros() {

    }

    @Given("{} genera token de sesion")
    public void clienteGeneraTokenDeSesion(String actor) {
        theActorCalled(actor);
        theActorInTheSpotlight().whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri8")));
        theActorInTheSpotlight().attemptsTo(GeneraToken.deSesion());
        TokenResponse tokenResponse = new ObtenerToken().answeredBy(theActorInTheSpotlight());
        this.token = tokenResponse.getAccess_token();
    }
    @When("realiza alta de una cuenta de ahorro")
    public void realizaAltaDeUnaCuentaDeAhorro() {
        accountRequest = new AccountRequest();
        account = new Account();
        customer = new Customer();
        identityDocument = new IdentityDocument();
        email = new Email();
        phone = new Phone();

        phones = new ArrayList<>();
        emails = new ArrayList<>();
        customers = new ArrayList<>();
        accounts = new ArrayList<>();

        this.tipoDocumento = theActorInTheSpotlight().recall("tipoDocumento");
        this.codigoCliente = theActorInTheSpotlight().recall("codigoCliente");
        this.numeroDocumento = theActorInTheSpotlight().recall("numeroDocumento");
        account.setCurrencyCode("PEN");
        account.setSubProduct("CUENTA_S");
        account.setAccountType("INDIVIDUAL");
        customer.setId(this.codigoCliente);
        customer.setTitular(true);
        identityDocument.setType(obtenerTipoDocumento(this.tipoDocumento));
        identityDocument.setNumber(this.numeroDocumento);
        email.setType("PERSONAL");
        email.setValue("MACKS.NUNEZ@ENCORA.COM");
        phone.setType("CELULAR");
        phone.setCarrier("MOVISTAR");
        phone.setNumber("51999999999");

        phones.add(phone);
        emails.add(email);
        customer.setPhone(phones);
        customer.setEmail(emails);
        customer.setIdentityDocument(this.identityDocument);
        accounts.add(account);
        customers.add(customer);

        accountRequest.setAccounts(accounts);
        accountRequest.setCustomers(customers);

        theActorInTheSpotlight().attemptsTo(AltaDeCuenta.deAhorro(token, accountRequest));
    }


    @Then("guardar los datos de la cuenta en el TXT cuentaCliente")
    public void guardarLosDatosDeLaCuentaEnElTXTCuentaCliente() {
        theActorInTheSpotlight().should(seeThat(VerificaCodigoRespuesta.delServicio(), equalTo(200)));
        theActorInTheSpotlight().attemptsTo(GuardarDatosDeCuenta.deAhorro());
    }

    @When("^realiza el alta de cuenta de ahorro sobre \"([^\"]*)\" clientes$")
    public void realizaElAltaDeCuentaDeAhorroSobreClientes(Integer cantClientes) {
        int x = 0;
        theActorCalled("Cliente");
        List<Clientes> clSinCuentaAhorro = new ListarClientesSinCuentaAhorro().answeredBy(theActorInTheSpotlight());
        for (Clientes cliente : clSinCuentaAhorro) {
            theActorInTheSpotlight().remember("tipoDocumento", cliente.getTipoDocumento());
            theActorInTheSpotlight().remember("codigoCliente", cliente.getCodigoCliente());
            theActorInTheSpotlight().remember("numeroDocumento", cliente.getNumeroDocumento());

            clienteGeneraTokenDeSesion("Cliente");
            realizaAltaDeUnaCuentaDeAhorro();
            guardarLosDatosDeLaCuentaEnElTXTCuentaCliente();

            x++;
            System.out.println("variable X: " + x);
            if (x >= cantClientes) {
                break;
            }
        }

    }

}
