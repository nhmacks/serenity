package com.interbank.pe.stepdefinitions.tarjeta;

import com.interbank.pe.questions.VerificaCodigoRespuesta;
import com.interbank.pe.questions.tarjeta.VerificarSaldo;
import com.interbank.pe.tasks.card.ConsultarTarjetaTC;
import com.interbank.pe.tasks.card.GuardarDatosAntiguos;
import io.cucumber.java.en.And;
import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Dado;
import io.cucumber.java.es.Entonces;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.util.EnvironmentVariables;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static org.hamcrest.CoreMatchers.equalTo;

public class ConsultarTarjetaStepDef {
    public Actor Actor;
    private EnvironmentVariables environmentVariables;
    @Dado("^que el cliente revisa el saldo disponible de su tarjeta de credito antes de transaccionar \"([^\"]*)\" \"([^\"]*)\"$")
    public void el_cliente_revisa_el_saldo_disponible_de_su_tarjeta_de_credito_antes_de_transaccionar(String tarjeta, String codigoUnico) {
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente")
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")));
        Actor.attemptsTo(
                ConsultarTarjetaTC.obtenerDatos(tarjeta, codigoUnico)
        );
        Actor.should(
                seeThat(VerificaCodigoRespuesta.delServicio(),equalTo(200)
                ));
        Actor.attemptsTo(
                GuardarDatosAntiguos.deLaTC()
        );

    }

    @Cuando("^realiza consumo Benefit en \"([^\"]*)\" y \"([^\"]*)\" con su TC \"([^\"]*)\"$")
    public void realiza_consumo_Benefit_en_y_con_su_TC(String arg1, String arg2, String arg3) {
        // Write code here that turns the phrase above into concrete actions

    }

    @Cuando("^el cliente consulta nuevamente el saldo disponible \"([^\"]*)\" \"([^\"]*)\"$")
    public void el_cliente_consulta_nuevamente_el_saldo_disponible(String tarjeta, String codigoUnico) {
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente")
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")));
        Actor.attemptsTo(
                ConsultarTarjetaTC.obtenerDatos(tarjeta, codigoUnico)
        );
        Actor.should(
                seeThat(VerificaCodigoRespuesta.delServicio(),equalTo(200)
                ));
    }

    @Entonces("^verifica que el saldo ha sido actualizado correctamente$")
    public void se_verifica_que_el_saldo_ha_sido_actualizado_correctamente() {
        Actor.should(
                seeThat(VerificarSaldo.deTarjeta())
        );
    }

    @Cuando("^consulta los datos de la tarjeta \"([^\"]*)\" con \"([^\"]*)\"$")
    public void consulta_los_datos_de_la_tarjeta_con(String tarjeta, String codigoUnio) {
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente")
                        .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")));
        Actor.attemptsTo(
                ConsultarTarjetaTC.obtenerDatos(tarjeta, codigoUnio)
        );

    }

    @Entonces("^el estado del servicio es (.*)$")
    public void revisa_el_estado_del_servicio(Integer statusCode) {
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente");
        Actor.should(
                seeThat(VerificaCodigoRespuesta.delServicio(), equalTo(statusCode)
                ));
    }



}
