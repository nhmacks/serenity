package com.interbank.pe.stepdefinitions.CompraDeuda;

import com.interbank.pe.model.CompraDeDeuda.SimulacionCompraDeuda.Request.SimulacionCompraDeudaRequest;
import com.interbank.pe.model.CompraDeDeuda.SimulacionCompraDeuda.Request.Simulation;
import com.interbank.pe.model.CompraDeDeuda.SimulacionCompraDeuda.Response.InformacionSimulacion;
import com.interbank.pe.model.Extracash.ofertaAjusta.OfertaAjustadaResponseError;
import com.interbank.pe.questions.Extracash.OfertaAjustadaMensajeError;
import com.interbank.pe.questions.VerificaCodigoRespuesta;
import com.interbank.pe.questions.compraDeuda.ObtenerRespuestaCuotasSimulada;
import com.interbank.pe.stepdefinitions.servicios.PayServicesStepDefs;
import com.interbank.pe.tasks.compraDeuda.SimulacionCompraDeuda;
import com.interbank.pe.utils.soap.UtilsTarjeta;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.util.EnvironmentVariables;

import java.util.Objects;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;

public class SimulacionCompraDeudaDefs {
    private EnvironmentVariables environmentVariables;
    @Steps
    PayServicesStepDefs payServicesStepDefs;

    String clienteContrato = theActorInTheSpotlight().recall("contrato");
    String clienteCustomerType = theActorInTheSpotlight().recall("customerType");
    String clienteCard = theActorInTheSpotlight().recall("card");

    String clienteLineaCredito = theActorInTheSpotlight().recall("lineaCredito");
    String clienteTipoDocumento = theActorInTheSpotlight().recall("tipoDocumento");
    String clienteNumeroDocumento = theActorInTheSpotlight().recall("numeroDocumento");

    public SimulacionCompraDeudaRequest request = new SimulacionCompraDeudaRequest();
    public Simulation simulation = new Simulation();
    String processType = "2";
    String contractId = "";
    String cardId = "";
    String amount = "0.00";
    String paymentTerm = "";
    String deferredTerm = "";
    String newAmount = "";
    String currency = "";
    String tem = "";
    String maximumAmount = "";
    String minimumAmount = "";
    String percentageAvaible = "";
    String user = "";
    String documentType = "";
    String referenceId = "";
    String cardIdtType = "";
    String montoUsado = "";
    InformacionSimulacion informacionSimulacion;

    @Given("^indica realizar consulta de simulacion de compra de deuda por \"([^\"]*)\"$")
    public void indica_realizar_consulta_de_simulacion_de_compra_de_deuda_por_pan_en_claro(String flujo) {
        System.out.println("flujo: " + flujo);
        if (Objects.equals(flujo, "PAN en claro")) {
            this.cardIdtType = "0";
            this.cardId = clienteCard;
        } else if (Objects.equals(flujo, "PAN truncado mas codigo unico")) {
            this.cardIdtType = "1";
            this.referenceId = clienteCustomerType;
            this.cardId = UtilsTarjeta.truncarPAN(clienteCard);
        } else if ((Objects.equals(flujo, "PAN truncado mas documento de identidad"))) {
            this.cardIdtType = "2";
            this.documentType = clienteTipoDocumento;
            this.referenceId = clienteNumeroDocumento;
            this.cardId = UtilsTarjeta.truncarPAN(clienteCard);
        } else if ((Objects.equals(flujo, "PAN truncado mas numero de cuenta"))) {
            this.cardIdtType = "3";
            this.referenceId = clienteContrato;
            this.cardId = UtilsTarjeta.truncarPAN(clienteCard);
        }
        this.processType = "2";
        this.paymentTerm = "48";
        this.deferredTerm = "01";
        this.currency = "604";
        this.tem = "0.49";
        this.maximumAmount = String.valueOf(Double.parseDouble(clienteLineaCredito) + 20000.00);
        this.minimumAmount = String.valueOf(Double.parseDouble(clienteLineaCredito) + 0.00);
        this.amount = String.valueOf(UtilsTarjeta.montoAleatorioRandom(Double.parseDouble(this.minimumAmount), Double.valueOf(this.maximumAmount)));
        this.newAmount = String.valueOf(Double.parseDouble(amount) + 1);
        this.percentageAvaible = "0.0";
        this.user = "X12585";
    }

    @When("realiza la simulacion de compra de deuda")
    public void realiza_la_simulacion_de_compra_de_deuda() {
        simulation.setProcessType(processType);
        simulation.setContractId(contractId);
        simulation.setCardId(cardId);
        simulation.setAmount(amount);
        simulation.setPaymentTerm(paymentTerm);
        simulation.setDeferredTerm(deferredTerm);
        simulation.setNewAmount(newAmount);
        simulation.setCurrency(currency);
        simulation.setTem(this.tem);
        simulation.setMaximumAmount(maximumAmount);
        simulation.setMinimumAmount(minimumAmount);
        simulation.setPercentageAvailable(percentageAvaible);
        simulation.setUser(user);
        request.setDocumentType(documentType);
        request.setReferenceId(referenceId);
        request.setSimulation(simulation);

        theActorInTheSpotlight()
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")))
                .attemptsTo(SimulacionCompraDeuda.deCliente(request, cardIdtType));
    }

    @Then("retorna la informacion de las cuotas simuladas")
    public void retorna_la_informacion_de_las_cuotas_simuladas() {
        theActorInTheSpotlight().
                should(
                        seeThat("estado del servicio", VerificaCodigoRespuesta.delServicio(), equalTo(200))
                );

        informacionSimulacion = new ObtenerRespuestaCuotasSimulada().answeredBy(theActorInTheSpotlight()).getSimulationInformation();
        theActorInTheSpotlight()
                .should(seeThat("Valida getCardId", actor -> informacionSimulacion.getCardId(), equalTo("")),
                        seeThat("Valida getSimulatedAmount", actor -> informacionSimulacion.getSimulatedAmount(), equalTo(simulation.getAmount() + 0)),
                        seeThat("Valida getCurrency", actor -> informacionSimulacion.getCurrency(), equalTo(simulation.getCurrency())),
                        seeThat("Valida getTea", actor -> informacionSimulacion.getTea(), notNullValue()),
                        seeThat("Valida getCapitalizedInterest", actor -> informacionSimulacion.getCapitalizedInterest(), notNullValue()),
                        seeThat("Valida getDeferredInterest", actor -> informacionSimulacion.getDeferredInterest(), notNullValue()),
                        seeThat("Valida getFinancedAmount", actor -> informacionSimulacion.getFinancedAmount(), notNullValue()),
                        seeThat("Valida getExpirationDate", actor -> informacionSimulacion.getExpirationDate(), notNullValue()),
                        seeThat("Valida getDeferredDays", actor -> informacionSimulacion.getDeferredDays(), notNullValue()),
                        seeThat("Valida getInstallmentAmount", actor -> informacionSimulacion.getInstallmentAmount(), notNullValue()),
                        seeThat("Valida getAmountAvailable", actor -> informacionSimulacion.getAmountAvailable(), notNullValue()),
                        seeThat("Valida getMaximumOffer", actor -> informacionSimulacion.getMaximumOffer(), notNullValue()),
                        seeThat("Valida getFlag", actor -> informacionSimulacion.getFlag(), equalTo("S"))
                );
    }

    @Then("retorna la informacion de las cuotas simuladas y la tarjeta truncada")
    public void retorna_la_informacion_de_las_cuotas_simuladas_y_la_tarjeta_truncada() {
        theActorInTheSpotlight().
                should(
                        seeThat("estado del servicio", VerificaCodigoRespuesta.delServicio(), equalTo(200))
                );

        informacionSimulacion = new ObtenerRespuestaCuotasSimulada().answeredBy(theActorInTheSpotlight()).getSimulationInformation();
        theActorInTheSpotlight()
                .should(seeThat("Valida getCardId", actor -> informacionSimulacion.getCardId(), equalTo(this.cardId)),
                        seeThat("Valida getSimulatedAmount", actor -> informacionSimulacion.getSimulatedAmount(), equalTo(simulation.getAmount() + 0)),
                        seeThat("Valida getCurrency", actor -> informacionSimulacion.getCurrency(), equalTo(simulation.getCurrency())),
                        seeThat("Valida getTea", actor -> informacionSimulacion.getTea(), notNullValue()),
                        seeThat("Valida getCapitalizedInterest", actor -> informacionSimulacion.getCapitalizedInterest(), notNullValue()),
                        seeThat("Valida getDeferredInterest", actor -> informacionSimulacion.getDeferredInterest(), notNullValue()),
                        seeThat("Valida getFinancedAmount", actor -> informacionSimulacion.getFinancedAmount(), notNullValue()),
                        seeThat("Valida getExpirationDate", actor -> informacionSimulacion.getExpirationDate(), notNullValue()),
                        seeThat("Valida getDeferredDays", actor -> informacionSimulacion.getDeferredDays(), notNullValue()),
                        seeThat("Valida getInstallmentAmount", actor -> informacionSimulacion.getInstallmentAmount(), notNullValue()),
                        seeThat("Valida getAmountAvailable", actor -> informacionSimulacion.getAmountAvailable(), notNullValue()),
                        seeThat("Valida getMaximumOffer", actor -> informacionSimulacion.getMaximumOffer(), notNullValue()),
                        seeThat("Valida getFlag", actor -> informacionSimulacion.getFlag(), equalTo("S"))
                );
    }

    @Given("especifica los datos de la tarjeta en formato trucado")
    public void especifica_los_datos_de_la_tarjeta_en_formato_trucado() {
        this.cardId = UtilsTarjeta.truncarPAN(clienteCard);
    }

    @And("el sistema de simulacion retorna el mensaje ERROR EL PAN ESTA INCORRECTO")
    public void elSistemaDeSimulacionRetornaElMensajeERRORELPANESTAINCORRECTO() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0009")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERROR EL PAN ESTA INCORRECTA, VERIFIQUE"))
                );
    }

    @And("indica realizar consulta de simulacion de compra de deuda por PAN truncado mas codigo unico")
    public void indicaRealizarConsultaDeSimulacionDeCompraDeDeudaPorPANTruncadoMasCodigoUnico() {
        this.cardIdtType = "1";
    }

    @Then("el sistema de simulacion retorna el mensaje ERROR EL PAN ESTA INCORRECTA")
    public void el_sistema_de_simulacion_retorna_el_mensaje_error_pan_esta_incorrecta() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0009")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERROR EL PAN ESTA INCORRECTA, VERIFIQUE"))
                );
    }

    @Then("el sistema de simulacion retorna el mensaje ERROR TARJETA NO ESTA ENCRIPTADA")
    public void el_sistema_de_simulacion_retorna_el_mensaje_error_tarjeta_no_esta_encriptada() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0010")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERROR TARJETA NO ESTA ENCRIPTADA, CORRECTAMENTE"))
                );
    }

    @Given("especifica los datos de la tarjeta en formato en claro")
    public void especifica_los_datos_de_la_tarjeta_en_formato_en_claro() {
        this.cardId = clienteCard;
    }

    @Then("el sistema de simulacion retorna el mensaje ERROR TIPO DE DOCUMENTO NO INFORMADO")
    public void el_sistema_de_simulacion_retorna_el_mensaje_error_tipo_de_documento_no_informado() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0007")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERROR TIPO DOCUMENTO NO INFORMADO"))
                );
    }

    @Given("no especifica el tipo de documento de identidad")
    public void no_especifica_el_tipo_de_documento_de_identidad() {
        this.documentType = "";
    }

    @Given("especifica una tarjeta con datos invalidos sin truncar")
    public void especifica_una_tarjeta_con_datos_invalidos_sin_truncar() {
        this.cardId = "9999999999999999";
    }

    @Given("no especifica el codigo unico")
    public void no_especifica_el_codigo_unico() {
        this.referenceId = "";
    }

    @Given("especifica una tarjeta con datos invalidos truncados")
    public void especifica_una_tarjeta_con_datos_invalidos_truncados() {
        this.cardId = "99999*****999999";
    }


    @Then("el sistema de simulacion retorna el mensaje ERROR EL CODIGO UNICO ESTA INCORRECTO")
    public void el_sistema_de_simulacion_retorna_el_mensaje_error_el_codigo_unico_esta_incorrecto() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0006")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERROR EL CODIGO UNICO ESTA INCORRECTO, VERIFIQUE"))
                );
    }

    @Then("el sistema de simulacion retorna el mensaje error tarjeta no existe en la tabla")
    public void el_sistema_de_simulacion_retorna_el_mensaje_error_tarjeta_no_existe_en_la_tabla() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0028")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERROR TARJETA NO EXISTE EN LA TABLA CDDT009"))
                );
    }

    @Then("el sistema de simulacion retorna el mensaje ERROR TARJETA NO ES VISA-MC-AMEX")
    public void el_sistema_de_simulacion_retorna_el_mensaje_error_tarjeta_no_es_visa_mc_amex() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0011")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERROR TARJETA NO ES VISA-MC-AMEX"))
                );
    }

    @Given("no especifica numero de documento de identidad")
    public void no_especifica_numero_de_documento_de_identidad() {
        this.referenceId = "";
    }

    @Then("el sistema de simulacion retorna el mensaje ERROR NUMERO DE DOCUMENTO NO INFORMADO")
    public void el_sistema_de_simulacion_retorna_el_mensaje_error_numero_de_documento_no_informado() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0008")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERROR NUMERO DOCUMENTO NO INFORMADO"))
                );
    }

    @Given("especifica un documento de identidad invalido")
    public void especifica_un_documento_de_identidad_invalido() {
        this.referenceId = "XLX03967";
    }

    @Then("el sistema de simulacion retorna el mensaje ERROR DOCUMENTO NO EXISTE")
    public void el_sistema_de_simulacion_retorna_el_mensaje_error_documento_no_existe() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0018")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("CDIR039: ERROR DOCUMENTO NO EXISTE"))
                );
    }

    @Given("no especifica el numero de contrato de la tarjeta de credito")
    public void no_especifica_el_numero_de_contrato_de_la_tarjeta_de_credito() {
        this.referenceId = "";
    }

    @Then("el sistema de simulacion retorna el mensaje ERROR ENTRADA SIN CUENTA")
    public void el_sistema_de_simulacion_retorna_el_mensaje_error_entrada_sin_cuenta() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0019")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("CDIR039: ERROR ENTRADA SIN CUENTA"))
                );
    }

    @Given("especifica datos invalidos en el contrato de tarjeta de credito")
    public void especifica_datos_invalidos_en_el_contrato_de_tarjeta_de_credito() {
        this.processType = "1";
        this.contractId = "ABC";
        this.referenceId = "";
        this.cardId = UtilsTarjeta.truncarPAN(clienteCard);
    }

    @Then("el sistema de simulacion retorna el mensaje ERROR LA CUENTA ESTA INCORRECTA")
    public void el_sistema_de_simulacion_retorna_el_mensaje_error_la_cuenta_esta_incorrecta() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0003")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERROR LA CUENTA ESTA INCORRECTO, VERIFIQUE"))
                );
    }

    @Given("especifica como tipo de proceso un dato invalido {string}")
    public void especifica_como_tipo_de_proceso_un_dato_invalido(String tipoProceso) {
        this.processType = tipoProceso;
    }

    @Then("el sistema de simulacion retorna el mensaje ERROR TIPO DE PROCESO ES 1 O 2")
    public void el_sistema_de_simulacion_retorna_el_mensaje_error_tipo_de_proceso_es_o() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0002")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERROR TIPO DE PROCESO ES 1 O 2"))
                );
    }

    @Given("no especifica el tipo de proceso")
    public void no_especifica_el_tipo_de_proceso() {
        this.processType = "";
    }

    @Given("especifica como monto de compra de deunda un monto superior a la nueva linea elegida")
    public void especifica_como_monto_de_compra_de_deunda_un_monto_superior_a_la_nueva_linea_elegida() {
        this.maximumAmount = String.valueOf(Double.parseDouble(clienteLineaCredito) + 20000.00);
        this.minimumAmount = String.valueOf(Double.parseDouble(clienteLineaCredito) + 0.00);
        this.amount = String.valueOf(UtilsTarjeta.montoAleatorioRandom(Double.parseDouble(this.minimumAmount), Double.valueOf(this.maximumAmount)));
        this.newAmount = String.valueOf(Double.parseDouble(amount) - 1);
    }

    @Then("el sistema de simulacion retorna el mensaje ERROR CD MAYOR A LA NUEVA LINEA ELEGIDA")
    public void el_sistema_de_simulacion_retorna_el_mensaje_error_cd_mayor_a_la_nueva_linea_elegida() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0046")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERROR CD MAYOR A LA NUEVA LINEA ELEGIDA"))
                );
    }

    @Given("^especifica como plazo de pago un valor no mapeado \"([^\"]*)\"$")
    public void especifica_como_plazo_de_pago_un_valor_no_mapeado(String paymentTerm) {
        this.paymentTerm = paymentTerm;
    }

    @Then("el sistema de simulacion retorna el mensaje ERROR PLAZO INVALIDO")
    public void el_sistema_de_simulacion_retorna_el_mensaje_error_plazo_invalido() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0034")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERROR PLAZO INVALIDO"))
                );
    }

    @Then("el sistema de simulacion retorna el mensaje TASA NO EXISTE EN PARAMETROS")
    public void el_sistema_de_simulacion_retorna_el_mensaje_tasa_no_existe_en_parametros() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0015")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo(" CDQO802 0000TASA NO EXISTE EN PARAMETROS (BD CDDTTECD)"))
                );
    }

    @Given("no especifica el plazo de pago")
    public void no_especifica_el_plazo_de_pago() {
        this.paymentTerm = "";
    }

    @Given("no especifica el termino diferido")
    public void no_especifica_el_termino_diferido() {
        this.deferredTerm = "";
    }

    @Given("^indica un dato invalido en termino diferido \"([^\"]*)\"$")
    public void indica_un_dato_invalido_en_termino_diferido(String deferredTerm) {
        this.deferredTerm = deferredTerm;
    }

    @Then("el sistema de simulacion retorna el mensaje ERROR PLAZO DIFERIDO INVALIDO")
    public void el_sistema_de_simulacion_retorna_el_mensaje_error_plazo_diferido_invalido() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0035")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("BSEX330O  ERROR PLAZO SELECCIONADO ES ZEROS"))
                );
    }

    @Given("no especifica la moneda la compra de deuda a simular")
    public void no_especifica_la_moneda_la_compra_de_deuda_a_simular() {
        this.currency = "";
    }

    @Given("indica como tasa efectiva mensual un valor invalido {string}")
    public void indica_como_tasa_efectiva_mensual_un_valor_invalido(String tem) {
        this.tem = tem;
    }

    @Then("el sistema de simulacion retorna el mensaje CDQO039  CDQO802 0000TASA NO EXISTE EN PARAMETROS")
    public void el_sistema_de_simulacion_retorna_el_mensaje_cdqo039_cdqo802_0000tasa_no_existe_en_parametros() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0086")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo(" CDQO039  CDQO802 0000TASA NO EXISTE EN PARAMETROS (BD CDDTT"))
                );
    }

    @Given("no especifica la tasa efectiva mensual")
    public void no_especifica_la_tasa_efectiva_mensual() {
        this.tem = "";
    }



    @Given("especifica como nueva linea un monto mayor al monto maximo permitido")
    public void especifica_como_nueva_linea_un_monto_mayor_al_monto_maximo_permitido() {
        this.newAmount = String.valueOf(Double.parseDouble(maximumAmount) + 1);
    }

    @When("el sistema de simulacion retorna el mensaje NUEVA LINEA MAYOR AL MAXIMO PERMITIDO")
    public void el_sistema_de_simulacion_retorna_el_mensaje_nueva_linea_mayor_al_maximo_permitido() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0044")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERROR NUEVA LINEA MAYOR AL MAXIMO PERMITIDO"))
                );
    }

    @Given("especifica como monto de compra de deuda un monto menor al minimo permitido")
    public void especifica_como_monto_de_compra_de_deuda_un_monto_menor_al_minimo_permitido() {
        this.amount = String.valueOf(Double.parseDouble(minimumAmount) - 1);
    }
    @When("el sistema de simulacion retorna el mensaje CD ELEGIDA MENOR AL MINIMO PERMITIDO")
    public void el_sistema_de_simulacion_retorna_el_mensaje_cd_elegida_menor_al_minimo_permitido() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0045")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERROR CD ELEGIDA MENOR AL MINIMO PERMITIDO"))
                );
    }

    @Given("no se detalla el usuario que realiza la operacion")
    public void no_se_detalla_el_usuario_que_realiza_la_operacion() {

    }

    @And("cuenta con operaciones realizadas sobre su tarjeta de credito")
    public void cuentaConOperacionesRealizadasSobreSuTarjetaDeCredito() {
        payServicesStepDefs.cliente_realiza_un_consumo_con_la_tarjeta_por_el_monto_en_moneda("BENEFIT",clienteCard, "100", "604");
        System.out.println("Monto usado: " + montoUsado);
    }

}

