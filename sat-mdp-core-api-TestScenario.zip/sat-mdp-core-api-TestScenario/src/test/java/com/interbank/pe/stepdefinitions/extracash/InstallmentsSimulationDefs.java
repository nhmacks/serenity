package com.interbank.pe.stepdefinitions.extracash;

import com.interbank.pe.model.Extracash.SimulacionCuotas.Response.Installment;
import com.interbank.pe.model.Extracash.SimulacionCuotas.Response.SimulacionCuotaResponse;
import com.interbank.pe.model.Extracash.SimulacionCuotas.SimulacionCuotaRequest;
import com.interbank.pe.model.Extracash.ofertaAjusta.OfertaAjustadaResponseError;
import com.interbank.pe.questions.Extracash.ObtenerSimulacionDeCuotas;
import com.interbank.pe.questions.Extracash.OfertaAjustadaMensajeError;
import com.interbank.pe.tasks.extracash.SimulacionCuotas;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.util.EnvironmentVariables;
import org.hamcrest.CoreMatchers;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.interbank.pe.utils.soap.UtilsTarjeta.parseStringToDouble;
import static com.interbank.pe.utils.soap.UtilsTarjeta.truncarPAN;
import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

public class InstallmentsSimulationDefs {
    String pan = theActorInTheSpotlight().recall("pan");
    String montoCampanna = theActorInTheSpotlight().recall("montoCampanna");
    String tipoDocumento = theActorInTheSpotlight().recall("tipoDocumento");

    String codigoCliente = theActorInTheSpotlight().recall("codigoCliente");
    String numeroContratoTC = theActorInTheSpotlight().recall("numeroContratoTC");
    String codMoneda = theActorInTheSpotlight().recall("codMoneda");
    String nroMesesDiferidos = theActorInTheSpotlight().recall("nroMesesDiferidos");

    String fechaCaducidad = theActorInTheSpotlight().recall("fechaCaducidad");
    String numeroDocumento = theActorInTheSpotlight().recall("numeroDocumento");

    Double montoSimular;
    String cardIdType;
    SimulacionCuotaResponse response;
    Installment installment;
    private final SimulacionCuotaRequest simulacionCuotaRequest = new SimulacionCuotaRequest();
    private EnvironmentVariables environmentVariables;

    @And("indica la tarjeta de credito a simular con formato {}")
    public void indicaLaTarjetaDeCreditoASimularConFormatoEnClaro(String formato) {
        if (Objects.equals(formato, "truncado")) {
            simulacionCuotaRequest.setCardId(truncarPAN(this.pan));
        } else if (Objects.equals(formato, "en claro")) {
            simulacionCuotaRequest.setCardId(this.pan);
        }
    }

    @And("indica como monto a simular el monto total de la oferta extracash")
    public void indicaComoMontoASimularElMontoTotalDeLaOfertaExtracash() {
        this.montoSimular = parseStringToDouble(montoCampanna);
        simulacionCuotaRequest.setSimulationAmount(montoSimular);
    }

    @And("indica como plazo de pago a simular {} cuotas")
    public void indicaElPlazoDePagoASimular(Integer plazoSimular) {
        simulacionCuotaRequest.setPayTerm(plazoSimular);
    }

    @And("indica como termino diferido {}")
    public void indicaComoTerminoDiferidoTerminoDiferido(Integer terminoDiferido) {
        simulacionCuotaRequest.setDeferredTerm(terminoDiferido);
    }

    @And("indica como nueva linea {}")
    public void indicaComoNuevaLineaMontoNuevaLinea(Double montoNuevaLinea) {
        simulacionCuotaRequest.setNewLineAmount(montoNuevaLinea);
    }

    @When("el cliente indica realizar simulacion de cuotas por {}")
    public void elClienteIndicaRealizarSimulacionDeCuotasPorPANEnClaro(String cardIdType) {
        if (Objects.equals(cardIdType, "PAN en claro")) {
            this.cardIdType = "0";
        } else if (Objects.equals(cardIdType, "PAN truncado mas codigo unico")) {
            this.cardIdType = "1";
        } else if ((Objects.equals(cardIdType, "PAN truncado mas documento de identidad"))) {
            this.cardIdType = "2";
        } else if ((Objects.equals(cardIdType, "PAN truncado mas numero de cuenta"))) {
            this.cardIdType = "3";
        }
    }

    @And("realiza simulacion de cuotas")
    public void realizaSimulacionDeCuotas() {
        theActorInTheSpotlight().whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")));
        theActorInTheSpotlight().attemptsTo(SimulacionCuotas.extracash(this.cardIdType, simulacionCuotaRequest));
    }

    public String fechaCaducidad(String fechaCaducidad) {
        String primerosDosDigitos = fechaCaducidad.substring(0, 2);
        String segundoDosDigitos = fechaCaducidad.substring(2, 4);
        String annoDosDigitos = fechaCaducidad.substring(4, 6);
        DateFormat formatoEntrada = new SimpleDateFormat("yy");
        DateFormat formatoSalida = new SimpleDateFormat("yyyy");
        try {
            Date fecha = formatoEntrada.parse(annoDosDigitos);
            return formatoSalida.format(fecha) + "" + segundoDosDigitos + "" + primerosDosDigitos;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return primerosDosDigitos;
    }

    public String moneda(String moneda) {
        if (Objects.equals(moneda, "01")) {
            moneda = "604";
        }
        return moneda;
    }

    public BigDecimal numeroRedondeado() {
        Double availableAmount = Double.parseDouble(response.getCapitalizedInterestAmount()) + Double.parseDouble(response.getDeferredInterestAmount());
        BigDecimal numero = new BigDecimal(availableAmount);
        return numero.setScale(2, RoundingMode.HALF_UP);
    }

    public String FinancedAmount() {
        Double financedAmount = Double.parseDouble(response.getDeferredInterestAmount()) + Double.parseDouble(response.getCapitalizedInterestAmount()) + Double.parseDouble(response.getDisbursementAmount());
        BigDecimal numero = new BigDecimal(financedAmount);
        return String.valueOf(numero.setScale(2, RoundingMode.HALF_UP));
    }


    @And("el sistema mostrara el detalle del producto")
    public void elSistemaMostraraElDetalleDelProducto() {
        response = new ObtenerSimulacionDeCuotas().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight().should(seeThat("Tarjeta se muestra nulo: ", actor -> response.getCardId(), equalTo("")));
        theActorInTheSpotlight().should(seeThat("getCampaignDescription se muestra nulo: ", actor -> response.getCampaignDescription(), equalTo("CAMPANA EC MAY    2023")));
        theActorInTheSpotlight().should(seeThat("getCampaignValidityDate se muestra nulo: ", actor -> response.getCampaignValidityDate(), equalTo(fechaCaducidad(this.fechaCaducidad))));
        theActorInTheSpotlight().should(seeThat("getAuthorizedAmount se muestra nulo: ", actor -> response.getAuthorizedAmount(), equalTo(this.montoSimular + "0")));
        theActorInTheSpotlight().should(seeThat("getCurrencyId se muestra nulo: ", actor -> response.getCurrencyId(), equalTo(moneda(this.codMoneda))));
        theActorInTheSpotlight().should(seeThat("getLinePendingAmount se muestra nulo: ", actor -> response.getLinePendingAmount(), equalTo("0.00")));
        theActorInTheSpotlight().should(seeThat("getLinePendingType se muestra nulo: ", actor -> response.getLinePendingType(), equalTo("")));
        theActorInTheSpotlight().should(seeThat("getDisbursementAmount se muestra nulo: ", actor -> response.getDisbursementAmount(), equalTo(this.montoSimular + "0")));
        theActorInTheSpotlight().should(seeThat("getECdisbursementAmount se muestra nulo: ", actor -> response.getECdisbursementAmount(), equalTo(this.montoSimular + "0")));

        theActorInTheSpotlight().should(seeThat("getAnualInterestRate se muestra nulo: ", actor -> response.getAnualInterestRate(), notNullValue()));
        theActorInTheSpotlight().should(seeThat("getMinimumTerm se muestra nulo: ", actor -> response.getMinimumTerm(), notNullValue()));

        theActorInTheSpotlight().should(seeThat("getMaximumTerm se muestra nulo: ", actor -> response.getMaximumTerm(), equalTo(this.nroMesesDiferidos)));

        theActorInTheSpotlight().should(seeThat("getCapitalizedInterestAmount se muestra nulo: ", actor -> response.getCapitalizedInterestAmount(), notNullValue()));
        theActorInTheSpotlight().should(seeThat("getDeferredInterestAmount se muestra nulo: ", actor -> response.getDeferredInterestAmount(), notNullValue()));

        theActorInTheSpotlight().should(seeThat("getFinancedAmount se muestra nulo: ", actor -> response.getFinancedAmount(), equalTo(FinancedAmount())));
        theActorInTheSpotlight().should(seeThat("getNewLineAmount se muestra nulo: ", actor -> response.getNewLineAmount(), equalTo(simulacionCuotaRequest.getNewLineAmount() + "0")));
        theActorInTheSpotlight().should(seeThat("getFirstDueDate se muestra nulo: ", actor -> response.getFirstDueDate(), notNullValue()));
        theActorInTheSpotlight().should(seeThat("getTotalDeferredDays se muestra nulo: ", actor -> response.getTotalDeferredDays(), notNullValue()));
        theActorInTheSpotlight().should(seeThat("getAvailableAmount se muestra nulo: ", actor -> response.getAvailableAmount(), equalTo(String.valueOf(numeroRedondeado()))));
        theActorInTheSpotlight().should(seeThat("getCalculatedOfferAmount se muestra nulo: ", actor -> response.getCalculatedOfferAmount(), notNullValue()));
        theActorInTheSpotlight().should(seeThat("getInsufficientLineFlag se muestra nulo: ", actor -> response.getInsufficientLineFlag(), equalTo("S")));
    }

    @And("los plazos disponibles son {}")
    public void losPlazosDisponiblesSon(String cuotas) {
        String[] elementos = cuotas.split(",");
        List<String> lista = new ArrayList<>(Arrays.asList(elementos));

        for (String element : lista) {
            installment = new ObtenerSimulacionDeCuotas().answeredBy(theActorInTheSpotlight())
                    .getInstallments().stream().filter(x -> Objects.equals(x.getId(), element))
                    .findFirst().orElse(null);
        }
    }

    @And("indica su codigo unico para simular")
    public void indicaSuCodigoUnicoParaSimular() {
        simulacionCuotaRequest.setReferenceId(this.codigoCliente);
    }

    @And("indica su tipo de documento para simular las cuotas")
    public void indicaSuTipoDeDocumentoParaSimularLasCuotas() {
        simulacionCuotaRequest.setDocumentType(this.tipoDocumento);
    }

    @And("indica su documento de identidad para simular las cuotas")
    public void indicaSuDocumentoDeIdentidadParaSimularLasCuotas() {
        simulacionCuotaRequest.setReferenceId(this.numeroDocumento);
    }

    @And("indica su contrato de TC a simular")
    public void indicaSuContratoDeTCASimular() {
        simulacionCuotaRequest.setReferenceId(this.numeroContratoTC);
    }

    @And("el sistema retorna el mensaje ERROR IMPORTE CUOTA MAYOR CEM")
    public void elSistemaRetornaElMensajeERRORIMPORTECUOTAMAYORCEM() {
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight().should(seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), CoreMatchers.equalTo("403")));
        theActorInTheSpotlight().should(seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), CoreMatchers.equalTo("Business error")));
        theActorInTheSpotlight().should(seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), CoreMatchers.equalTo("0059")));
        theActorInTheSpotlight().should(seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), CoreMatchers.equalTo("ERROR IMPORTE CUOTA MAYOR CEM")));

    }

    @And("mostrara el mensaje de error ERROR EL PAN ESTA INCORRECTA, VERIFIQUE")
    public void mostraraElMensajeDeErrorERRORELPANESTAINCORRECTAVERIFIQUE() {
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight().should(seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), CoreMatchers.equalTo("403")));
        theActorInTheSpotlight().should(seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), CoreMatchers.equalTo("Business error")));
        theActorInTheSpotlight().should(seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), CoreMatchers.equalTo("0024")));
        theActorInTheSpotlight().should(seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), CoreMatchers.equalTo("ERROR EL PAN ESTA INCORRECTA, VERIFIQUE")));

    }

    @And("mostrara el mensaje de error ERROR PLAZO INVALIDO")
    public void mostraraElMensajeDeErrorERRORPLAZOINVALIDO() {
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight().should(seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), CoreMatchers.equalTo("403")));
        theActorInTheSpotlight().should(seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), CoreMatchers.equalTo("Business error")));
        theActorInTheSpotlight().should(seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), CoreMatchers.equalTo("0048")));
        theActorInTheSpotlight().should(seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), CoreMatchers.equalTo("ERROR PLAZO INVALIDO")));
    }
}
