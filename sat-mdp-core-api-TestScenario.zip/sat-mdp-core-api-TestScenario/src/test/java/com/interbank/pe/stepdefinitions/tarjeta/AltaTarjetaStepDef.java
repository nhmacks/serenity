package com.interbank.pe.stepdefinitions.tarjeta;

import com.interbank.pe.model.Tarjeta;
import com.interbank.pe.model.cliente.cliente.RequestCrearCliente.Clientes;
import com.interbank.pe.model.tarjeta.altaTarjetaCredito.ResponseErrorMessageAltaTC;
import com.interbank.pe.model.tarjeta.altaTarjetaCredito.RespuestaAltaTarjetaCredito;
import com.interbank.pe.questions.VerificaCodigoRespuesta;
import com.interbank.pe.questions.cliente.Cliente.ListarClientesSinTC;
import com.interbank.pe.questions.tarjeta.AltaTarjetaCredito;
import com.interbank.pe.questions.tarjeta.ErrorMessageAltaTC;
import com.interbank.pe.tasks.account.AnularContrato;
import com.interbank.pe.tasks.card.AltaDeTarjeta;
import com.interbank.pe.tasks.card.ConsultarTarjetaTC;
import com.interbank.pe.tasks.card.GuardarDatosTarjetaCredito;
import com.interbank.pe.tasks.cliente.Cliente.ActualizarDatosCliente;
import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Dado;
import io.cucumber.java.es.Entonces;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.util.EnvironmentVariables;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;

import java.util.List;
import java.util.Objects;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.CoreMatchers.*;

public class AltaTarjetaStepDef {
    public Actor Actor;
    private EnvironmentVariables environmentVariables;
    private String marca;
    private String codMarca;
    private String codTipo;
    private String condEconomica;
    private String monedaTC;
    private String lineaCredito= null;
    private String diaPago = null;
    private String codigoUnicoCliente = null;
    private String customerName = null;
    private String numeroDocumento = null;
    private String productoTC = null;
    LocalDateTime dateTime = LocalDateTime.now();
    LocalDate date_of_today = LocalDate.now();
    Integer cantidadClientes = theActorInTheSpotlight().recall("cantidadClientes");
    @Dado("^el cliente con tipo de documento (.*) se encuentra recien registrado en el sistema$")
    public void el_cliente_con_tipo_de_documento_DNI_se_encuentra_recien_registrado(String tipDocumento) {
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente")
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")));

        List<Clientes> clientesNuevosSinTarjeta = new ListarClientesSinTC().answeredBy(Actor);
        for (Clientes cliente : clientesNuevosSinTarjeta) {
            if (cliente.getTipoDocumento().equals(tipDocumento)) {
                codigoUnicoCliente = cliente.getCodigoCliente();
                customerName = cliente.getPrimerApellido() + "*" + cliente.getPrimerApellido();
                break;
            }
        }
        Actor.should(seeThat("Data de prueba disponible?", actor -> codigoUnicoCliente,notNullValue()));
        Actor.should(seeThat("Verifica Codigo unico del cliente ", act -> codigoUnicoCliente, notNullValue()));
        Actor.should(seeThat("Verifica Nombre de la tarjeta ", act -> customerName, notNullValue()));
    }

    @Dado("^indica como producto de tarjeta de credito \"([^\"]*)\"$")
    public void indicsa_como_producto_de_tarjeta_de_credito (String productoTC) {
        this.productoTC=productoTC;
        if (Objects.equals(productoTC, "Visa Signature")) {      this.marca = "VISA"; this.codMarca = "01"; this.codTipo = "14"; this.condEconomica = "504";
        } else if (Objects.equals(productoTC, "Visa Platinum")) {this.marca = "VISA"; this.codMarca = "01"; this.codTipo = "23"; this.condEconomica = "544";
        } else if (Objects.equals(productoTC, "Visa Oro")) {     this.marca = "VISA"; this.codMarca = "01"; this.codTipo = "02"; this.condEconomica = "545";
        } else if (Objects.equals(productoTC, "Claro Oro")) {    this.marca = "VISA";this.codMarca = "01";this.codTipo = "30";this.condEconomica = "509";
        } else if (Objects.equals(productoTC, "Visa Access")) {  this.marca = "VISA";this.codMarca = "01";this.codTipo = "31";this.condEconomica = "508";
        } else if (Objects.equals(productoTC, "Visa Clasica")) { this.marca = "VISA";this.codMarca = "01";this.codTipo = "01";this.condEconomica = "553";
        } else if (Objects.equals(productoTC, "Visa Infiniti")) {this.marca = "VISA";this.codMarca = "01";this.codTipo = "29";this.condEconomica = "553";
        } else if (Objects.equals(productoTC, "Amex Green")) {this.marca = "AMEX";this.codMarca = "02";this.codTipo = "03";this.condEconomica = "553";
        } else if (Objects.equals(productoTC, "Amex Gold")) {this.marca = "AMEX";this.codMarca = "02";this.codTipo = "04";this.condEconomica = "553";
        } else if (Objects.equals(productoTC, "Amex Blue")) {this.marca = "AMEX";this.codMarca = "02";this.codTipo = "07";this.condEconomica = "553";
        } else if (Objects.equals(productoTC, "Amex Platinum")) {this.marca = "AMEX";this.codMarca = "02";this.codTipo = "08";this.condEconomica = "553";
        } else if (Objects.equals(productoTC, "Amex Black")) {this.marca = "AMEX";this.codMarca = "02";this.codTipo = "09";this.condEconomica = "553";
        } else if (Objects.equals(productoTC, "MC Platinum")) {  this.marca = "MC";  this.codMarca = "04";this.codTipo = "04";this.condEconomica = "544";
        } else if (Objects.equals(productoTC, "MC Oro")) {       this.marca = "MC";  this.codMarca = "04";this.codTipo = "02";this.condEconomica = "545";
        } else if (Objects.equals(productoTC, "MC Clasica")) {   this.marca = "MC";  this.codMarca = "04";this.codTipo = "01";this.condEconomica = "553";
        } else if (Objects.equals(productoTC, "The Platinum Card Amex")) {this.marca = "AMEX";this.codMarca = "02";this.codTipo = "06";this.condEconomica = "501";
        } else if (Objects.equals(productoTC, "PREMIA")) {this.marca = "VISA";this.codMarca = "01";this.codTipo = "17";this.condEconomica = "438";
        }
    }


    @Cuando("^consulta la tarjeta y obtengo los datos necesarios$")
    public void consulta_la_tarjeta_y_obtengo_los_datos_necesarios() {
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente")
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")));

        String tarjeta = Tarjeta.getResponseCollection("tarjeta");
        String codigoUnico = Tarjeta.getResponseCollection("codUnico");
        Actor.attemptsTo(
                ConsultarTarjetaTC.obtenerDatos(tarjeta, codigoUnico)
        );
    }

    @Entonces("^procedo a ejecutar la marcacion online$")
    public void procedo_a_ejecutar_la_marcacion_online() {
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente")
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")));

        String contrato = Tarjeta.getResponseCollection("contrato");

        Actor.attemptsTo(
                AnularContrato.deCuenta(contrato)
        );
    }

    @Cuando("^indica la condicion economica de la tarjeta de credito como \"([^\"]*)\"$")
    public void indica_la_condicion_economica_de_la_tarjeta_de_credito_como(String condicionEconomica) {
        this.condEconomica = condicionEconomica;
    }

    @Dado("^indica la moneda de la tarjeta de credito como \"([^\"]*)\"$")
    public void indica_la_moneda_de_la_tarjeta_de_credito_como(String monedaTC) {
        this.monedaTC = monedaTC;
    }

    @Dado("^indica el monto de linea de la tarjeta de credito en \"([^\"]*)\"$")
    public void indica_el_monto_de_linea_de_la_tarjeta_de_credito_en(String lineaCredito) {
        this.lineaCredito = lineaCredito;
    }

    @Dado("^indica como dia de pago de la tarjeta de credito el \"([^\"]*)\"$")
    public void indica_como_dia_de_pago_de_la_tarjeta_de_credito_el(String diaPago) {
        this.diaPago = diaPago;
    }

    @Cuando("^realiza el alta de contrato de Tarjeta de Credito$")
    public void realiza_el_alta_de_su_contrato_de_Tarjeta_de_Credito() {
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente")
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")));
        List<Clientes> clienteSinTC = new ListarClientesSinTC().answeredBy(Actor);
        System.out.println("cantidad de clientes x adquirir TC: " + clienteSinTC.size());

        int x = 0;
        for (Clientes clientelesOnboarded : clienteSinTC) {
            codigoUnicoCliente = clientelesOnboarded.getCodigoCliente();
            customerName = clientelesOnboarded.getPrimerApellido() + "*" + clientelesOnboarded.getPrimerNombre();
            numeroDocumento = clientelesOnboarded.getNumeroDocumento();

            Actor.attemptsTo(AltaDeTarjeta.DeCredito(codigoUnicoCliente, customerName, codMarca, codTipo, condEconomica, monedaTC, lineaCredito, diaPago));
            Actor.should(seeThat("Respuesta del servicio es 201",VerificaCodigoRespuesta.delServicio(), equalTo(201)));

            RespuestaAltaTarjetaCredito altaTarjetaCredito = new AltaTarjetaCredito().answeredBy(Actor);
            String numeroTarjeta = altaTarjetaCredito.getCardId();
            String fechaCreacionTC = dateTime.toString();
            String contrato = altaTarjetaCredito.getAccountHost();
            if (altaTarjetaCredito.getCardId()!=null) {
                Actor.attemptsTo(ActualizarDatosCliente.nuevos(numeroDocumento, codigoUnicoCliente, numeroTarjeta, fechaCreacionTC, contrato));
                Actor.attemptsTo(GuardarDatosTarjetaCredito.enArchivoCSV(contrato, codigoUnicoCliente, numeroTarjeta, codMarca, codTipo, marca, productoTC, condEconomica, lineaCredito, lineaCredito));
                x++;
                if (x >= this.cantidadClientes){
                    break;
                }
            }

        }
    }



    @Cuando("^realiza el alta de tarjeta de credito$")
    public void realiza_el_alta_de_tarjeta_de_credito() {
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente")
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")));
        Actor.attemptsTo(AltaDeTarjeta.DeCredito(codigoUnicoCliente, customerName,codMarca,codTipo,condEconomica,monedaTC, lineaCredito, diaPago));
    }

    @Cuando("^intenta realizar el alta de tarjeta de credito nuevamente$")
    public void intenta_realiza_el_alta_de_tarjeta_de_credito() {
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente")
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")));
        Actor.attemptsTo(AltaDeTarjeta.DeCredito(codigoUnicoCliente, customerName,codMarca,codTipo,condEconomica,monedaTC, lineaCredito, diaPago));
        Actor.should(seeThat("Estado del servicio igual ", VerificaCodigoRespuesta.delServicio(), equalTo(500)));
    }

    @Entonces("^el sistema genera detalles del alta de tarjeta de credito$")
    public void el_sistema_genera_detalles_del_alta_de_tarjeta_de_credito() {
        RespuestaAltaTarjetaCredito altaTarjetaCredito = new AltaTarjetaCredito().answeredBy(Actor);
        String numeroTarjeta = altaTarjetaCredito.getCardId();
        String fechaCreacionTC = dateTime.toString();
        Actor.should(seeThat("Estado del servicio igual ", VerificaCodigoRespuesta.delServicio(), equalTo(201)));

        String contrato = altaTarjetaCredito.getAccountHost();
        if (altaTarjetaCredito.getCardId()!=null) {
            Actor.attemptsTo(ActualizarDatosCliente.nuevos(numeroDocumento, codigoUnicoCliente, numeroTarjeta, fechaCreacionTC, contrato));
        }
        Actor.should(seeThat("Codigo de cliente no es nulo",actor -> altaTarjetaCredito.getCustomerId(),notNullValue()));
        Actor.should(seeThat("Numero de Tarjeta no es nulo",actor -> altaTarjetaCredito.getCardId(),notNullValue()));
        if (Objects.equals(marca, "Amex")){
            Actor.should(seeThat("Longitud de tarjeta",actor -> altaTarjetaCredito.getCardId().length(),equalTo(15)));
        }else if (Objects.equals(marca,"Visa")){
            Actor.should(seeThat("Longitud de tarjeta",actor -> altaTarjetaCredito.getCardId().length(),equalTo(16)));
        }
        Actor.should(seeThat("Numero de cuenta de cliente no es nulo",actor -> altaTarjetaCredito.getAccountHost(),notNullValue()));
        Actor.should(seeThat("Fecha de alta",actor -> altaTarjetaCredito.getDischargeDate(),containsString(date_of_today.toString())));
        Actor.should(seeThat("Fecha de vencimiento no es nulo",actor -> altaTarjetaCredito.getDueDate(),notNullValue()));
        Actor.should(seeThat("Lista de beneficiarios es null",actor -> altaTarjetaCredito.getBeneficiaries().toString(),equalTo("[]")));
    }

    @Entonces("^el sistema no permite realizar el alta de TC nuevamente$")
    public void elSistemaNoPermiteRealizarElAltaDeTCNuevamente() {
        //MODEL                             =       QUESTION
        ResponseErrorMessageAltaTC response = new ErrorMessageAltaTC().answeredBy(Actor);
        Actor.should(seeThat("Codigo http es 500",actor -> response.getHttpCode(),equalTo("500")));
        Actor.should(seeThat("Message http es",actor -> response.getHttpMessage(),equalTo("Internal Server Error")));
    }

    @Entonces("^mostrara el mensaje de alerta \"([^\"]*)\"$")
    public void mostraraElMensajeDeAlerta(String message){
        ResponseErrorMessageAltaTC responseErrorMessageAltaTC = new ErrorMessageAltaTC().answeredBy(Actor);
        Actor.should(seeThat(actor -> responseErrorMessageAltaTC.getHttpCode(),equalTo("403")));
        Actor.should(seeThat(actor -> responseErrorMessageAltaTC.getHttpMessage(),equalTo("Business error")));
        Actor.should(seeThat(actor -> responseErrorMessageAltaTC.getProviderCode(),equalTo("0020")));
        Actor.should(seeThat(actor -> responseErrorMessageAltaTC.getProviderMessage(),equalTo("MPA0002 - "+message)));
    }
}
