package com.interbank.pe.stepdefinitions.Login;

import com.interbank.pe.questions.VerificaCodigoRespuesta;
import com.interbank.pe.questions.VerificaMensaje;
import com.interbank.pe.tasks.Login.LoginTC;

import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Dado;
import io.cucumber.java.es.Entonces;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.util.EnvironmentVariables;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.equalTo;

public class LoginTCDefs {

    public net.serenitybdd.screenplay.Actor Actor;
    private EnvironmentVariables environmentVariables;
    public static final String MSJCONFORME = "EJECUCION CON EXITO";
    public static final String MSJRECHAZADO = "TARJETA NO OPERATIVA";

    @Dado("^el cliente tiene su tarjeta bloqueada$")
    public void elClienteTieneSuTarjetaBloqueada() {
    }

    @Dado("^el cliente tiene cuenta bloqueada$")
    public void elClienteTieneCuentaBloqueada() {
    }

    @Cuando("^ingresa al canal digital con \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
    public void ingresa_al_canal_digital_con(String tarjeta, String cu, String clave) {
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente").whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri4")));
        Actor.attemptsTo(LoginTC.now(tarjeta, cu, clave));
    }

    @Entonces("^el sistema permitira el acceso$")
    public void elSistemaPermitiraElAcceso() {
        Actor.should(seeThat(VerificaCodigoRespuesta.delServicio(), equalTo(200)));
        Actor.should(seeThat("Mensaje: EJECUCION CON EXITO", VerificaMensaje.ejecucionConExito(), containsString(MSJCONFORME)));
    }

    @Entonces("^el sistema no permitira el ingreso$")
    public void elSistemaNoPermitiraElIngreso() {
        Actor.should(seeThat(VerificaCodigoRespuesta.delServicio(), equalTo(200)));
        Actor.should(seeThat("Mensaje: TARJETA NO OPERATIVA", VerificaMensaje.ejecucionConExito(), containsString(MSJRECHAZADO)));
    }

}
