package com.interbank.pe.stepdefinitions.servicios;

import com.interbank.pe.model.MovimientosTC;
import com.interbank.pe.model.Tarjeta;
import com.interbank.pe.model.cuotas.TransactionInstallment;
import com.interbank.pe.model.tarjeta.ClientesConTarjetaDebito;
import com.interbank.pe.questions.VerificaCodigoRespuesta;
import com.interbank.pe.questions.VerificaMensaje;
import com.interbank.pe.questions.cuotas.VerificaTransaccionEnCuotas;
//import com.interbank.pe.questions.tarjeta.ListarClientesConTD;
import com.interbank.pe.tasks.card.debito.ListaClientesconTD;
import com.interbank.pe.tasks.services.DispocicionDeEfectivo;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Dado;
import io.cucumber.java.es.Entonces;
import io.cucumber.java.es.Y;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.util.EnvironmentVariables;

import java.util.Objects;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorCalled;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.CoreMatchers.notNullValue;

public class DisposicionDeEfectivoDefs {

    String tarjetaDebito, claveWeb, codigoUnico, cargoMoneda, tarjetaCredito, abonoMoneda, abonoCuenta, importeTransferencia, monedaTransferencia;
    String TARJETA = null;
    String CLAVE = null;
    String CU = null;

    String trxCargoMoneda = null;

    String trxCargoCuenta = null;

    String trxAbonoMoneda = null;

    String trxAbonoCuenta = null;

    String trxImporte = null;

    String trxMoneda = null;

    String trxReferenceId = null;

    public Actor Actor;
    private EnvironmentVariables environmentVariables;

    @Dado("^que el cliente realiza una disposicion de efectivo desde canal digital con tarjeta \"([^\"]*)\" clave \"([^\"]*)\" y codigo unico \"([^\"]*)\"$")
    public void que_el_cliente_desea_realizar_una_transferencia_con_tarjeta_clave_y_codigo_unico(String tarjeta, String clave, String cu) {
        TARJETA = tarjeta;
        CLAVE = clave;
        CU = cu;
    }

    @Dado("^selecciona como cuenta de cargo \"([^\"]*)\" \"([^\"]*)\"$")
    public void selecciona_como_cuenta_de_cargo(String cargoMonedaTC, String cargoCuentaTC) {
        Tarjeta.setResponseCollection("cargoMonedaTC", cargoMonedaTC);
        Tarjeta.setResponseCollection("tarjetaCredito", cargoCuentaTC);
    }

    @Dado("^selecciona como cuenta destino \"([^\"]*)\" \"([^\"]*)\"$")
    public void selecciona_como_cuenta_destino(String abonoMonedaTD, String abonoCuentaTD) {
        this.trxAbonoMoneda = abonoMonedaTD;
        this.trxAbonoCuenta = abonoCuentaTD;
    }

    @Dado("^indica el monto \"([^\"]*)\" y moneda a transaccionar \"([^\"]*)\"$")
    public void indica_el_monto_y_moneda_a_transaccionar(String trxImporte, String trxMoneda) {
        this.trxImporte = trxImporte;
        this.trxMoneda = trxMoneda;
    }

    @Cuando("^acepta la disposicion de efectivo$")
    public void realiza_la_disposicion_de_efectivo() {
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente")
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri4")));
        trxCargoMoneda = Tarjeta.getResponseCollection("cargoMonedaTC");
        trxCargoCuenta = Tarjeta.getResponseCollection("tarjetaCredito");

        Actor.attemptsTo(
                DispocicionDeEfectivo.conCargoEnTC(TARJETA, CU, trxCargoMoneda, trxCargoCuenta, trxAbonoMoneda, trxAbonoCuenta, trxReferenceId, trxImporte, trxMoneda, CLAVE)
        );
        Actor.should(
                seeThat(VerificaCodigoRespuesta.delServicio(), equalTo(200)
                ));
    }

    @Entonces("^se autoriza la transaccion en el canal y se valida la transferencia desde NSAT$")
    public void se_genera_y_se_valida_la_transferencia_desde_NSAT() {

    }

    @Entonces("^luego se genera el pase a \"([^\"]*)\" cuotas$")
    public void luego_se_genera_el_pase_a_cuotas(String arg1) {

    }

    @Entonces("^se rechaza la transaccion en el canal$")
    public void se_rechaza_la_transaccion_en_el_canal() {
        Actor.should(
                seeThat(VerificaMensaje.ejecucionConExito(), containsString("LIMITE DE SALDO EXCEDIDO"))
        );
    }

    @Entonces("^verifica el mensaje (.*)$")
    public void verificaElMensajeEjecucionConExito(String mensaje) {
        Actor.should(
                seeThat(VerificaMensaje.ejecucionConExito(), containsString(mensaje))
        );
    }

    @Y("^confirma la operacion dentro de sus movimientos$")
    public void confirmaLaOperacionDentroDeSusMovimientos() {

    }

    @Entonces("^Verifica el nombre del comercio (.*)$")
    public void verificaElNombreDelComercio(String nombreComercio) {
        TransactionInstallment trx = new VerificaTransaccionEnCuotas().answeredBy(Actor);
        Actor.should(
                seeThat("Fecha de Liquidacion Cuota " + trx.getSettlementDate(), actor -> trx.getSettlementDate(), notNullValue()),
                seeThat("Fecha ultimo dia de pago " + trx.getPaymentDate(), actor -> trx.getPaymentDate(), notNullValue()),
                seeThat("El valor de la Cuota es: " + trx.getAmount(), actor -> trx.getAmount(), notNullValue()),
                seeThat("Se valida glosa NSAT " + trx.getCompanyName(), act -> trx.getCompanyName(), containsString(nombreComercio))
        );

    }


    @Y("^monto de la operacion \"([^\"]*)\"$")
    public void montoDeLaOperacion(String importeFactura) throws Throwable {
        trxAbonoMoneda = MovimientosTC.getResponseCollection("importeFactura");
        if (Objects.equals(trxAbonoMoneda, "604")) {
            Actor.should(
                    seeThat("Monto Transferido", actor -> trxAbonoMoneda, equalTo(importeFactura))
            );
        } else {
            Actor.should(
                    seeThat("Monto Transferido", actor -> trxAbonoMoneda, notNullValue())
            );
        }

    }

    @Given("que el {} tiene tarjeta debito")
    public void queElClienteTieneTarjetaDebito(String actor) {
        theActorCalled(actor);
        theActorInTheSpotlight().attemptsTo(ListaClientesconTD.Activado());
        this.tarjetaDebito = theActorInTheSpotlight().recall("tarjetaDebito");
        this.claveWeb = theActorInTheSpotlight().recall("claveWeb");
        this.codigoUnico = theActorInTheSpotlight().recall("codigoUnico");
        this.cargoMoneda = theActorInTheSpotlight().recall("cargoMoneda");
        this.tarjetaCredito = theActorInTheSpotlight().recall("tarjetaCredito");
        this.abonoMoneda = theActorInTheSpotlight().recall("abonoMoneda");
        this.abonoCuenta = theActorInTheSpotlight().recall("abonoCuenta");
        this.importeTransferencia = theActorInTheSpotlight().recall("importeTransferencia");
        this.monedaTransferencia = theActorInTheSpotlight().recall("monedaTransferencia");
    }

    @And("realiza una disposicion de efectivo con su tarjeta de credito")
    public void realizaUnaDisposicionDeEfectivoConSuTarjetaDeCredito() {
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente")
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri4")));

        Actor.attemptsTo(
                DispocicionDeEfectivo.conCargoEnTC(tarjetaDebito, codigoUnico, cargoMoneda, tarjetaCredito, abonoMoneda, abonoCuenta, trxReferenceId, importeTransferencia, monedaTransferencia, claveWeb)
        );
        Actor.should(
                seeThat(VerificaCodigoRespuesta.delServicio(), equalTo(200)
                ));

    }

}

