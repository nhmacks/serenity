package com.interbank.pe.stepdefinitions.tarjeta;

import com.interbank.pe.model.tarjeta.Tarjeta;
import com.interbank.pe.questions.VerificaCodigoRespuesta;
import com.interbank.pe.questions.tarjeta.ListarTarjetasPorActivar;
import com.interbank.pe.tasks.card.ActivarTarjeta;
import com.interbank.pe.tasks.card.ActualizarDatosDeTarjetaNueva;
import io.cucumber.java.es.Dado;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.util.EnvironmentVariables;
import org.joda.time.LocalDateTime;

import java.util.List;

import static org.hamcrest.CoreMatchers.equalTo;

public class ActivarTarjetaStepDef {
    public net.serenitybdd.screenplay.Actor Actor;
    private EnvironmentVariables environmentVariables;

    @Dado("^realiza el endose de la tarjeta de credito$")
    public void realiza_el_endose_de_la_tarjeta_de_credito() {
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente")
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri2")));
        List<Tarjeta> tarjeta = new ListarTarjetasPorActivar().answeredBy(Actor);
        for (Tarjeta TCporActivar : tarjeta) {
                String numTarjeta = TCporActivar.getCard();
                Actor.attemptsTo(ActivarTarjeta.nueva(numTarjeta));
                LocalDateTime dateTime = LocalDateTime.now();
                String fechaActivacion = dateTime.toString();
                if (VerificaCodigoRespuesta.delServicio().equals(equalTo(200)));
                {
                    Actor.attemptsTo(ActualizarDatosDeTarjetaNueva.comoActivada(numTarjeta, fechaActivacion, "1"));
                }
        }


    }
}
