package com.interbank.pe.stepdefinitions.servicios;

import com.interbank.pe.model.MovimientosTC;
import com.interbank.pe.questions.movimientos.ObtenerMovimientos;
import com.interbank.pe.questions.VerificaCodigoRespuesta;
import com.interbank.pe.questions.VerificaMensaje;
import com.interbank.pe.tasks.card.SeleccionarUltimoMovimientosTC;
import com.interbank.pe.tasks.card.ListaLosUltimoMovimientos;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Dado;
import io.cucumber.java.es.Entonces;
import io.cucumber.java.es.Y;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.util.EnvironmentVariables;

import java.util.HashMap;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static org.hamcrest.CoreMatchers.*;

public class ConsultMovementsStepDefs {
    public Actor Actor;
    private String numFilas = "65";

    private EnvironmentVariables environmentVariables;

    public static final String MSJCONFORME = "EJECUCION CON EXITO";

    @Cuando("^consulta los movimientos de su tarjeta$")
    public void consulto_los_movimientos_de_la_tarjeta() {
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente")
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri2")));

        String card = MovimientosTC.getResponseCollection("card");

        Actor.attemptsTo(ListaLosUltimoMovimientos.deTarjeta(card, numFilas));

        Actor.should(seeThat(VerificaCodigoRespuesta.delServicio(), equalTo(200)));
        Actor.should(seeThat("Verifica que el servicio contenga el mensaje ", VerificaMensaje.ejecucionConExito(), containsString(MSJCONFORME)
        ));
    }

    @Cuando("^selecciona el ultimo movimiento realizado$")
    public void selecciona_el_ultimo_movimiento_realizado() {
        Actor.attemptsTo(SeleccionarUltimoMovimientosTC.now());
    }

    @Entonces("^el sistema detallara la operacion realizada (.*)$")
    public void elSistemaDetallaraLaOperacionRealizada(String nombreComercioReducido) {
        String valor = MovimientosTC.getResponseCollection("nombreComercioReducido");
        String fechaFactura = MovimientosTC.getResponseCollection("fechaFactura");
        String horaSIAIDCD = MovimientosTC.getResponseCollection("horaSIAIDCD");
        String importeFactura = MovimientosTC.getResponseCollection("importeFactura");

        Actor.should(
                seeThat("Comercio: ", actor -> valor, equalTo(nombreComercioReducido)),
                seeThat("Fecha de la Operacion: ", actor -> fechaFactura, containsString(fechaFactura)),
                seeThat("Hora de la Operacion: ", actor -> horaSIAIDCD, containsString(horaSIAIDCD)),
                seeThat("Importe: ", actor -> importeFactura, containsString(importeFactura))
        );
    }
//Linea de codigo por operativa de Disposicion Efectivo

    @Entonces("^Verifica que el ultimo movimiento muestre como nombre de comercio (.*)$")
    public void verificaQueElUltimoMovimientoMuestreComoNombreDeComercioDISPEFECTTRDISPEFECTTR(String nombreComercioReducido) {
        String valor = MovimientosTC.getResponseCollection("nombreComercioReducido");

        Actor.should(
                seeThat("Comercio: ", actor -> valor, containsString(nombreComercioReducido))
        );
    }

    //Linea de codigo por operativa de Pago de Tarjeta

    @Y("^nombre de comercio reducido es (.*)$")
    public void nombre_de_comercio_reducido_es_PAGO_CON_TARJ_OTRO_BA(String nombreComercio) {
        HashMap<String, String> consumo = new ObtenerMovimientos().answeredBy(Actor);
        System.out.println("consumo" + consumo);
        Actor.should(
                seeThat("TEST", act -> consumo.get("nombreComercioReducido"), equalTo(nombreComercio))
        );
    }

    // lineas de codigo Feature Consulta Movimientos

    @Dado("^que tiene consumo aterrizado en su \"([^\"]*)\"$")
    public void queTieneConsumoAterrizadoEnSu(String card) throws Throwable {
        MovimientosTC.setResponseCollection("card", card);
    }

    @Dado("^que le realizaron un abono a su tarjeta \"([^\"]*)\"$")
    public void queLeRealizaronUnAbonoASuTarjeta(String card) throws Throwable {
        MovimientosTC.setResponseCollection("card", card);
    }

    @Dado("^que el cliente realizo anteriormente operaciones ecommerce \"([^\"]*)\"$")
    public void queElClienteRealizoAnteriormenteOperacionesEcommerce(String card) throws Throwable {
        MovimientosTC.setResponseCollection("card", card);
    }

    @Y("^al consultar nuevamente sus movimientos la operacion ya no esta disponible$")
    public void alConsultarNuevamenteSusMovimientosElMovimientoYaNoExiste() {
        String card = MovimientosTC.getResponseCollection("card");
        Actor.should(seeThat(VerificaCodigoRespuesta.delServicio(), equalTo(400)));
        Actor.should("El movimiento ya no esta disponible para la tarjeta: " + card);
        System.out.println("El movimiento ya no existe");
    }

    @When("indica la cantidad de {string} movimientos a visualizar")
    public void indicaLaCantidadDeMovimientosAVisualizar(String numFilas) {
        this.numFilas = numFilas;

    }

    @Then("se listara los {string} respectivamente")
    public void seListaraLosRespectivamente(String numFilas) {
    }

    @When("consulta los movimientos de su tarjeta de credito")
    public void consultaLosMovimientosDeSuTarjetaDeCredito() {

        Actor = net.serenitybdd.screenplay.Actor.named("Cliente")
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri2")));

        String card = MovimientosTC.getResponseCollection("card");

        Actor.attemptsTo(ListaLosUltimoMovimientos.deTarjeta(card, numFilas));

        Actor.should(seeThat(VerificaCodigoRespuesta.delServicio(), equalTo(200)));
        Actor.should(seeThat("Verifica que el servicio contenga el mensaje ", VerificaMensaje.ejecucionConExito(), containsString(MSJCONFORME)
        ));
    }
}
