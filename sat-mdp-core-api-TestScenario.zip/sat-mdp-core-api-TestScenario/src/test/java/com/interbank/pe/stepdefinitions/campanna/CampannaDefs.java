package com.interbank.pe.stepdefinitions.campanna;

import com.interbank.pe.model.cliente.cliente.RequestCrearCliente.Clientes;
import com.interbank.pe.model.tarjeta.Tarjeta;
import com.interbank.pe.questions.campanna.ListarTarjetasSinCampanaExtracash;
import com.interbank.pe.questions.cliente.Cliente.ListarClientes;
import com.interbank.pe.tasks.campaign.ActualizarCampanna;
import com.interbank.pe.tasks.campaign.generarTxtCampannaExtracash;
import com.interbank.pe.tasks.campaign.generarTxtCargaMasivaDiariaExtracash;
import io.cucumber.java.es.Dado;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.util.EnvironmentVariables;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Objects;

public class CampannaDefs {
    public Actor Actor;
    private EnvironmentVariables environmentVariables;

    @Dado("^se realiza carga de campaña sobre las nuevas tarjetas$")
    public void se_tiene_una_lista_de_clientes_sin_campana() {
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente")
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")));

        List<Tarjeta> tarjetasSinCampana = new ListarTarjetasSinCampanaExtracash().answeredBy(Actor);
        List<Clientes> clientesNuevos = new ListarClientes().answeredBy(Actor);

        Date fechaHoraActual = new Date();

        SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyyMMdd_HHmmss");
        String fechaHoraFormateada = formatoFecha.format(fechaHoraActual);

        String fileCampannaExtracash = "SBL_CAMPANNA_" + fechaHoraFormateada + "_BOOT" + ".txt";
        for (Tarjeta tarjeta : tarjetasSinCampana) {
            int correlativo = 1;
            for (Clientes cliente : clientesNuevos) {
                if (Objects.equals(cliente.getContrato(), tarjeta.getContrato())) {
                    System.out.println("Tarjeta de cliente: " + cliente.getTarjetaCredito());
                    Actor.attemptsTo(generarTxtCampannaExtracash.porTarjeta(fileCampannaExtracash, cliente.getTipoDocumento(), cliente.getNumeroDocumento(), tarjeta.getCustomerType(), cliente.getPrimerNombre(), cliente.getSegundoNombre(), cliente.getPrimerApellido(), cliente.getSegundoApellido(), tarjeta.getCard(), tarjeta.getMarcaTC(), tarjeta.getTipoTC(), tarjeta.getlineaCredito(), tarjeta.getCondicionEconomica(), tarjeta.getlineaCredito(), String.valueOf(correlativo), tarjeta.getProducto(), tarjeta.getDescription()));
                    Actor.attemptsTo(generarTxtCargaMasivaDiariaExtracash.porTarjeta(cliente.getContrato(), tarjeta.getlineaCredito()));
                    Actor.attemptsTo(ActualizarCampanna.comoActivada(tarjeta.getCard()));
                    correlativo++;
                }
            }
        }
    }
}
