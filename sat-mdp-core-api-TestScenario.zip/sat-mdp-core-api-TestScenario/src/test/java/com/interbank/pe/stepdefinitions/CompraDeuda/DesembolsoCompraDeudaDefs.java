package com.interbank.pe.stepdefinitions.CompraDeuda;

import com.interbank.pe.model.CompraDeDeuda.DesembolsoCompraDeuda.Request.AltaCompraDeuda;
import com.interbank.pe.model.CompraDeDeuda.DesembolsoCompraDeuda.Request.Purchase;
import com.interbank.pe.model.CompraDeDeuda.DesembolsoCompraDeuda.Request.Registration;
import com.interbank.pe.model.CompraDeDeuda.DesembolsoCompraDeuda.Response.ResponseAltaCompraDeuda;
import com.interbank.pe.model.Extracash.ofertaAjusta.OfertaAjustadaResponseError;
import com.interbank.pe.model.tarjeta.EstadoCuentaTarjetaCredito.EstadoCuentaTarjetaCredito;
import com.interbank.pe.questions.Extracash.OfertaAjustadaMensajeError;
import com.interbank.pe.questions.VerificaCodigoRespuesta;
import com.interbank.pe.questions.compraDeuda.ObtenerRespuestaAltaCompraDeuda;
import com.interbank.pe.questions.tarjeta.estadoCuentaTarjetaCredito.EstadoCuentaTC;
import com.interbank.pe.stepdefinitions.servicios.PayServicesStepDefs;
import com.interbank.pe.stepdefinitions.tarjeta.ConsultarTarjetaStepDef;
import com.interbank.pe.tasks.compraDeuda.DesembolsoCompraDeuda;
import com.interbank.pe.utils.soap.UtilsTarjeta;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.util.EnvironmentVariables;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.equalTo;

public class DesembolsoCompraDeudaDefs {
    private EnvironmentVariables environmentVariables;

    String clienteContrato = theActorInTheSpotlight().recall("contrato");
    String clienteCustomerType = theActorInTheSpotlight().recall("customerType");
    String clienteCard = theActorInTheSpotlight().recall("card");

    String clienteLineaCredito = theActorInTheSpotlight().recall("lineaCredito");

    String clienteTipoDocumento = theActorInTheSpotlight().recall("tipoDocumento");
    String clienteNumeroDocumento = theActorInTheSpotlight().recall("numeroDocumento");

    AltaCompraDeuda requestAltaCD = new AltaCompraDeuda();
    Purchase purchase = new Purchase();
    List<Purchase> purchaseList = new ArrayList<>();
    Registration registration = new Registration();
    String documentType;
    String referenceId;
    String registrationProcessType;
    String registrationContractId;
    String registrationCardId;
    String registrationTypeLine;
    String registrationTypeDebt;
    String registrationNewLine;
    String registrationItemNumber;
    String purchaseInstitutionCode;
    String purchasesCardId;
    String purchaseAmountDebtSoles;
    String purchaseAmountDebtDolares;
    String registrationSeller;
    String registrationCurrencyCode;
    String registrationInstallmentNumber;
    String registrationConsolidatedRate;
    String registrationCatcherBranch;
    String registrationDebtAmount;
    String registrationGraceMonth;
    String registrationCustomerId;
    String registrationOfferedRate;
    String registrationUser;
    String headerCardIdType = "";

    @Steps
    PayServicesStepDefs payServicesStepDefs;
    @Steps
    ConsultarTarjetaStepDef consultarTarjetaStepDef;
    EstadoCuentaTarjetaCredito estadoCuentaTarjetaCredito;

    @Given("^indica realizar desembolso de compra de deuda por \"([^\"]*)\"$")
    public void indica_realizar_desembolso_de_compra_de_deuda_por(String flujo) {
        System.out.println("flujo: " + flujo);
        if (Objects.equals(flujo, "PAN en claro")) {
            this.headerCardIdType = "0";
            this.registrationCardId = clienteCard;
        } else if (Objects.equals(flujo, "PAN truncado mas codigo unico")) {
            this.headerCardIdType = "1";
            this.referenceId = clienteCustomerType;
            this.registrationCardId = UtilsTarjeta.truncarPAN(clienteCard);
        } else if ((Objects.equals(flujo, "PAN truncado mas documento de identidad"))) {
            this.headerCardIdType = "2";
            this.documentType = clienteTipoDocumento;
            this.referenceId = clienteNumeroDocumento;
            this.registrationCardId = UtilsTarjeta.truncarPAN(clienteCard);
        } else if ((Objects.equals(flujo, "PAN truncado mas numero de cuenta"))) {
            this.headerCardIdType = "3";
            this.referenceId = clienteContrato;
            this.registrationCardId = UtilsTarjeta.truncarPAN(clienteCard);
        }
        this.registrationProcessType = "2";
        this.registrationTypeLine = "R";
        this.registrationTypeDebt = "D";
        this.registrationNewLine = clienteLineaCredito;
        this.registrationItemNumber = "1";
        this.registrationSeller = "9080";
        this.registrationCurrencyCode = "1";
        this.registrationInstallmentNumber = "06";
        this.registrationConsolidatedRate = "6.04";
        this.registrationCatcherBranch = "100";
        this.registrationDebtAmount = String.valueOf(Double.parseDouble(clienteLineaCredito) - (Double.parseDouble(clienteLineaCredito) * 0.2));
        this.registrationGraceMonth = "00";
        this.registrationCustomerId = clienteCustomerType;
        this.registrationOfferedRate = "0.49";
        this.registrationUser = "X11658";
        this.purchaseInstitutionCode = "009";
        this.purchasesCardId = "4221424123951342";
        this.purchaseAmountDebtSoles = String.valueOf(Double.parseDouble(clienteLineaCredito) - (Double.parseDouble(clienteLineaCredito) * 0.2));
        this.purchaseAmountDebtDolares = "";
    }

    @When("realiza desembolso de compra de deuda")
    public void realizaDesembolsoDeCompraDeDeuda() {

        requestAltaCD.setDocumentType(documentType);
        requestAltaCD.setReferenceId(referenceId);

        registration.setProcessType(registrationProcessType);
        registration.setContractId(registrationContractId);
        registration.setCardId(registrationCardId);
        registration.setTypeLine(registrationTypeLine);
        registration.setTypeDebt(registrationTypeDebt);
        registration.setNewLine(registrationNewLine);
        registration.setItemNumber(registrationItemNumber);
        registration.setSeller(registrationSeller);
        registration.setCurrencyCode(registrationCurrencyCode);
        registration.setInstallmentNumber(registrationInstallmentNumber);
        registration.setConsolidatedRate(registrationConsolidatedRate);
        registration.setCatcherBranch(registrationCatcherBranch);
        registration.setDebtAmount(registrationDebtAmount);
        registration.setGraceMonth(registrationGraceMonth);
        registration.setCustomerId(registrationCustomerId);
        registration.setOfferedRate(registrationOfferedRate);
        registration.setUser(registrationUser);

        purchase.setInstitutionCode(purchaseInstitutionCode);
        purchase.setCardId(purchasesCardId);
        purchase.setAmountDebtSoles(purchaseAmountDebtSoles);
        purchase.setAmountDebtDolares(purchaseAmountDebtDolares);

        purchaseList.add(purchase);
        registration.setPurchases(purchaseList);
        requestAltaCD.setRegistration(registration);


        theActorInTheSpotlight()
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")))
                .attemptsTo(DesembolsoCompraDeuda.deCliente(requestAltaCD, headerCardIdType));
    }

    @And("el sistema retornara la aprobacion del alta de compra de deuda realizado")
    public void elSistemaRetornaraLaAprobacionDelAltaDeCompraDeDeudaRealizado() {
        ResponseAltaCompraDeuda responseAltaCompraDeuda = new ObtenerRespuestaAltaCompraDeuda().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat("Valida getCardId", actor -> responseAltaCompraDeuda.getAuthorizationNumber(), equalTo("1")),
                        seeThat("Valida getCurrentLine", actor -> responseAltaCompraDeuda.getMaximumAmount(), equalTo("0.00"))
                );
    }

    @And("especifica realizar un incremento de linea")
    public void especificaRealizarUnIncrementoDeLinea() {
        this.registrationNewLine = String.valueOf(Double.parseDouble(clienteLineaCredito) + 1);
    }

    @And("especifica como tarjeta de credito una tarjeta invalida")
    public void especificaComoTarjetaDeCreditoUnaTarjetaInvalida() {
        registrationCardId = "999999*****9999";
    }

    @And("el sistema de desembolso de compra de deuda retorna el mensaje ERROR EL PAN ESTA INCORRECTO")
    public void elSistemaDeDesembolsoDeCompraDeDeudaRetornaElMensajeERRORELPANESTAINCORRECTO() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0024")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERROR EL PAN ESTA INCORRECTA, VERIFIQUE"))
                );
    }

    @And("especifica como tarjeta de credito una tarjeta desencriptada")
    public void especificaComoTarjetaDeCreditoUnaTarjetaDesencriptada() {
        this.registrationCardId = clienteCard;
    }

    @And("el sistema de desembolso de compra de deuda retorna el mensaje TARJETA NO ESTA ENCRIPTADA CORRECTAMENTE")
    public void elSistemaDeDesembolsoDeCompraDeDeudaRetornaElMensajeTARJETANOESTAENCRIPTADACORRECTAMENTE() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0023")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERROR TARJETA NO ESTA ENCRIPTADA CORRECTAMENTE"))
                );
    }


    @And("no especifica su tipo de documento de identidad")
    public void noEspecificaSuTipoDeDocumentoDeIdentidad() {
        this.documentType = "";
    }

    @And("el sistema de desembolso de compra de deuda retorna el mensaje ERROR TIPO DE DOCUMENTO NO INFORMADO")
    public void elSistemaDeDesembolsoDeCompraDeDeudaRetornaElMensajeERRORTIPODEDOCUMENTONOINFORMADO() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0018")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERROR TIPO DOCUMENTO NO INFORMADO"))
                );
    }

    @And("no especifica su codigo de cliente")
    public void noEspecificaSuCodigoDeCliente() {
        this.referenceId = "";
    }

    @And("el sistema de desembolso de compra de deuda retorna el mensaje ERROR EL CODIGO UNICO ESTA INCORRECTO")
    public void elSistemaDeDesembolsoDeCompraDeDeudaRetornaElMensajeERRORELCODIGOUNICOESTAINCORRECTO() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0017")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERROR EL CODIGO UNICO ESTA INCORRECTO, VERIFIQUE"))
                );
    }

    @And("no especifica su numero de documento de identidad")
    public void noEspecificaSuNumeroDeDocumentoDeIdentidad() {
        this.referenceId = "";
    }

    @And("el sistema de desembolso de compra de deuda retorna el mensaje ERROR NUMERO DOCUMENTO NO INFORMADO")
    public void elSistemaDeDesembolsoDeCompraDeDeudaRetornaElMensajeERRORNUMERODOCUMENTONOINFORMADO() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0019")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERROR NUMERO DOCUMENTO NO INFORMADO"))
                );
    }

    @And("especifica como numero de documento de identidad datos invalidos")
    public void especificaComoNumeroDeDocumentoDeIdentidadUnDatoInvalido() {
        this.referenceId = "99999999QW";
    }

    @And("el sistema de desembolso de compra de deuda retorna el mensaje ERROR DOCUMENTO NO EXISTE")
    public void elSistemaDeDesembolsoDeCompraDeDeudaRetornaElMensajeERRORDOCUMENTONOEXISTE() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0093")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("CDIR039: ERROR DOCUMENTO NO EXISTE"))
                );
    }

    @And("no especifica su codigo unico de cliente")
    public void noEspecificaSuCodigoUnicoDeCliente() {
        this.referenceId = "";
    }

    @And("el sistema de desembolso de compra de deuda retorna el mensaje ERROR ENTRADA SIN CUENTA")
    public void elSistemaDeDesembolsoDeCompraDeDeudaRetornaElMensajeERRORENTRADASINCUENTA() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0094")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("CDIR039: ERROR ENTRADA SIN CUENTA"))
                );
    }

    @And("no especifica el codigo de contrato de tarjeta")
    public void noEspecificaElCodigoDeContratoDeTarjeta() {
        this.registrationProcessType = "1";
        this.registrationContractId = "";
    }

    @And("el sistema de desembolso de compra de deuda retorna el mensaje ERROR CUENTA INVALIDA")
    public void elSistemaDeDesembolsoDeCompraDeDeudaRetornaElMensajeERRORCUENTAINVALIDA() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0027")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERROR CUENTA INVALIDA"))
                );
    }

    @And("especifica como tipo de proceso de alta de compra de deuda un dato invalido {string}")
    public void especificaComoTipoDeProcesoDeAltaDeCompraDeDeudaUnDatoInvalidoString(String tipoProceso) {
        this.registrationProcessType = tipoProceso;
    }

    @And("el sistema de desembolso de compra de deuda retorna el mensaje ERROR TIPO DE PROCESO ES 1 O 2")
    public void elSistemaDeDesembolsoDeCompraDeDeudaRetornaElMensajeERRORTIPODEPROCESOESO() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0029")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERROR TIPO DE PROCESO ES 1 O 2"))
                );
    }

    @And("no especifica datos en el tipo de proceso de alta de compra de deuda")
    public void noEspecificaDatosEnElTipoDeProcesoDeAltaDeCompraDeDeuda() {
        this.registrationProcessType = "";
    }

    @And("especifica como nueva linea de credito un monto menor a su linea de credito")
    public void especificaComoNuevaLineaDeCreditoUnMontoMenorASuLineaDeCredito() {
        this.registrationNewLine = String.valueOf(Double.parseDouble(clienteLineaCredito) - 1);
    }

    @And("el sistema de desembolso de compra de deuda retorna el mensaje NVA LINEA MENOR")
    public void elSistemaDeDesembolsoDeCompraDeDeudaRetornaElMensajeNVALINEAMENOR() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0020")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), containsString(" CDQO039 LINEA MENOR A LA LINEA DEL CONTRATO"))
                );
    }

    @And("especifica como institucion financiera un codigo invalido")
    public void especificaComoInstitucionFinancieraUnCodigoInvalido() {
        this.purchaseInstitutionCode = "99A";
    }

    @And("el sistema de desembolso de compra de deuda retorna el mensaje INSTITUCION FINANCIERA NO ENCONTRADA")
    public void elSistemaDeDesembolsoDeCompraDeDeudaRetornaElMensajeINSTITUCIONFINANCIERANOENCONTRADA() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0020")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERR. INST. FINANCIERA. NO ENCONTRADA"))
                );
    }

    @And("no especifica codigo de institucion de banco")
    public void noEspecificaCodigoDeInstitucionDeBanco() {
        this.purchaseInstitutionCode = "";
    }

    @And("el sistema de desembolso de compra de deuda retorna el mensaje NUMERO DE ITEMS VALOR INCORRECTO")
    public void elSistemaDeDesembolsoDeCompraDeDeudaRetornaElMensajeNUMERODEITEMSVALORINCORRECTO() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0020")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERR. NUMERO ITEMS. VALOR INCORRECTO"))
                );
    }

    @And("especifica como tarjeta de banco a comprar deuda datos invalidos")
    public void especificaComoTarjetaDeBancoAComprarDeudaDatosInvalidos() {
        this.purchasesCardId = "9999999999999999";
    }

    @And("el sistema de desembolso de compra de deuda retorna el mensaje ERROR EN NUMERO DE TARJETA")
    public void elSistemaDeDesembolsoDeCompraDeDeudaRetornaElMensajeERRORENNUMERODETARJETA() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0020")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERR. NUMERO DE TARJETA O/BANCO - O/ENTIDAD"))
                );
    }

    @And("no especifica tarjeta de banco a comprar deuda")
    public void noEspecificaTarjetaDeBancoAComprarDeuda() {
        this.purchasesCardId = "";
    }

    @And("el sistema de desembolso de compra de deuda retorna el mensaje ERROR NUMERO DE ITEMS VALOR INCORRECTO")
    public void elSistemaDeDesembolsoDeCompraDeDeudaRetornaElMensajeERRORNUMERODEITEMSVALORINCORRECTO() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0020")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERR. NUMERO ITEMS. VALOR INCORRECTO"))
                );
    }

    @And("especifica como monto debito soles un monto superior a la nueva linea de credito")
    public void especificaComoMontoDebitoSolesUnMontoSuperiorALaNuevaLineaDeCredito() {
        this.purchaseAmountDebtSoles = String.valueOf(Double.parseDouble(registrationNewLine) + 1);
    }

    @And("el sistema de desembolso de compra de deuda retorna el mensaje SALDO INSUFICIENTE")
    public void elSistemaDeDesembolsoDeCompraDeDeudaRetornaElMensajeSALDOINSUFICIENTE() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0020")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), containsString("SOLICITADO")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), containsString("OFERTA MAXIMA"))
                );
    }

    @And("especifica como monto debito dolares un monto superior a la nueva linea de credito")
    public void especificaComoMontoDebitoDolaresUnMontoSuperiorALaNuevaLineaDeCredito() {
        this.purchaseAmountDebtSoles = "";
        this.purchaseAmountDebtDolares = String.valueOf(Double.parseDouble(registrationNewLine) + 1);
    }

    @And("no especifica valor en rama receptor")
    public void noEspecificaValorEnRamaReceptor() {
        this.registrationCatcherBranch = "";
    }

    @And("especifica numero de cuotas de pago un dato invalido {string}")
    public void especificaNumeroDeCuotasDePagoUnDatoInvalido(String plazoPago) {
        this.registrationInstallmentNumber = plazoPago;
    }

    @And("el sistema de desembolso de compra de deuda retorna el mensaje TASA NO EXISTE EN PARAMETROS")
    public void elSistemaDeDesembolsoDeCompraDeDeudaRetornaElMensajeTASANOEXISTEENPARAMETROS() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0020")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), containsString("TASA NO EXISTE EN PARAMETROS (BD CDDTTECD)"))
                );
    }

    @And("^especifica un dato invalido como tipo de linea \"([^\"]*)\"$")
    public void especificaUnDatoInvalidoComoTipoDeLinea(String tipoLinea) {
        this.registrationTypeLine = tipoLinea;
    }

    @And("el sistema de desembolso de compra de deuda retorna el mensaje ERROR TIPO DE LINEA")
    public void elSistemaDeDesembolsoDeCompraDeDeudaRetornaElMensajeERRORTIPODELINEA() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0020")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), containsString("ERR. TIPO DE LINEA. VALOR VALIDO R"))
                );
    }

    @And("^indica como codigo de moneda un valor invalido \"([^\"]*)\"$")
    public void indicaComoCodigoDeMonedaUnValorInvalido(String codigoMoneda) {
        this.registrationCurrencyCode = codigoMoneda;
    }

    @And("el sistema de desembolso de compra de deuda retorna el mensaje ERROR CODIGO MONEDA VALOR INVALIDO")
    public void elSistemaDeDesembolsoDeCompraDeDeudaRetornaElMensajeERRORCODIGOMONEDAVALORINVALIDO() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0020")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), containsString("ERR. CODIGO MONEDA. VALOR INVALIDO (1,2)"))
                );
    }

    @And("^indica como mes de gracia un dato invalido \"([^\"]*)\"$")
    public void indicaComoMesDeGraciaUnDatoInvalido(String mesGracia) {
        this.registrationGraceMonth = mesGracia;
    }

    @And("no especifica usuario de registro")
    public void noEspecificaUsuarioDeRegistro() {
        this.registrationUser = "";
    }

    @And("el sistema de desembolso de compra de deuda retorna el mensaje ERROR USUARIO EN BLANCO")
    public void elSistemaDeDesembolsoDeCompraDeDeudaRetornaElMensajeERRORUSUARIOENBLANCO() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0020")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), containsString("ERROR USUARIO EN BLANCO"))
                );
    }

    @And("especifica como codigo de cliente un codigo invalido")
    public void especificaComoCodigoDeClienteUnCodigoInvalido() {
        this.registrationCustomerId = "999999999";
    }

    @And("el sistema de desembolso de compra de deuda retorna el mensaje ERR. CODIGO UNICO. VALOR INVALIDO")
    public void elSistemaDeDesembolsoDeCompraDeDeudaRetornaElMensajeERRCODIGOUNICOVALORINVALIDO() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0020")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), containsString("ERR. CODIGO UNICO. VALOR INVALIDO"))
                );
    }

    @And("el cliente realizo un desembolso de compra de deuda el mismo dia")
    public void elClienteRealizoUnDesembolsoDeCompraDeDeudaElMismoDia() {
        indica_realizar_desembolso_de_compra_de_deuda_por("PAN en claro");
        realizaDesembolsoDeCompraDeDeuda();
    }


    @And("el sistema de desembolso de compra de deuda retorna el mensaje ERR. CODIGO MONEDA. VALOR CERO")
    public void elSistemaDeDesembolsoDeCompraDeDeudaRetornaElMensajeERRCODIGOMONEDAVALORCERO() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0020")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), containsString("ERR. CODIGO MONEDA. VALOR CERO"))
                );
    }

    @And("el sistema de desembolso de compra de deuda retorna el mensaje PLAZO CON VALOR EN 0")
    public void elSistemaDeDesembolsoDeCompraDeDeudaRetornaElMensajePLAZOCONVALOREN() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0020")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), containsString("ERR. PLAZO. VALOR EN 0"))
                );
    }

    @And("el sistema de desembolso de compra de deuda retorna el mensaje ERR. MESES DE GRACIA. NO NUMERICO")
    public void elSistemaDeDesembolsoDeCompraDeDeudaRetornaElMensajeERRMESESDEGRACIANONUMERICO() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0020")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), containsString("ERR. MESES DE GRACIA. NO NUMERICO"))
                );
    }

    @And("especifica como tipo de linea {string}")
    public void especificaComoTipoDeLinea(String tipoLinea) {
        this.registrationTypeLine = tipoLinea;
    }

    @And("especifica como tipo de deuda {string}")
    public void especificaComoTipoDeDeuda(String tipoDeuda) {
        this.registrationTypeDebt = tipoDeuda;
    }

    @And("especifica la cantidad de cuotas {string}")
    public void especificaLaCantidadDeCuotas(String numeroCuotas) {
        this.registrationInstallmentNumber = numeroCuotas;
    }

    @And("especifica como periodo de liquidacion {string}")
    public void especificaComoPeriodoDeLiquidacion(String periodoLiquidacion) {
        this.registrationGraceMonth = periodoLiquidacion;
    }

    @And("especifica realizar un incremento de linea por monto mayor a {string}")
    public void especificaRealizarUnIncrementoDeLineaPorMontoMayorA(String montoIncLinea) {
        this.registrationNewLine = Double.parseDouble(clienteLineaCredito) + montoIncLinea;
    }

    @And("no cuenta con saldo disponible en su tarjeta de credito")
    public void noCuentaConSaldoEnSuTarjetaDeCredito() {
        payServicesStepDefs.cliente_realiza_un_consumo_con_la_tarjeta_por_el_monto_en_moneda("BENEFIT", this.clienteCard, clienteLineaCredito, "604");
        int tarjetaCredito = Integer.parseInt(clienteCustomerType);
        System.out.println("Tarjeta: " + tarjetaCredito);
        consultarTarjetaStepDef.el_cliente_revisa_el_saldo_disponible_de_su_tarjeta_de_credito_antes_de_transaccionar(this.clienteCard, Integer.toString(tarjetaCredito));
        estadoCuentaTarjetaCredito = new EstadoCuentaTC().answeredBy(theActorInTheSpotlight());
        System.out.println("Monto usado: " + estadoCuentaTarjetaCredito.getCreditLine().getUsed().getAmount());
    }

    @And("especifica realizar un incremento de linea por monto mayor al doble de su linea de credito")
    public void especificaRealizarUnIncrementoDeLineaPorMontoMayorAlDobleDeSuLineaDeCredito() {
        this.registrationNewLine = String.valueOf(Double.parseDouble(clienteLineaCredito) * 2);
        System.out.println("monto" + Double.parseDouble(clienteLineaCredito) * 2);
    }
}
