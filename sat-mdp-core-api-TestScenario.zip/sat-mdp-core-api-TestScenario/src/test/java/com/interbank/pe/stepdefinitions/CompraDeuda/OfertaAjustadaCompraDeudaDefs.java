package com.interbank.pe.stepdefinitions.CompraDeuda;

import com.interbank.pe.model.CompraDeDeuda.OfertaAjustada.Request.OfertaAjustadaCompraDeudaRequest;
import com.interbank.pe.model.CompraDeDeuda.OfertaAjustada.Response.OfferInformation;
import com.interbank.pe.model.Extracash.ofertaAjusta.OfertaAjustadaResponseError;
import com.interbank.pe.model.ResponseGeneric;
import com.interbank.pe.model.cliente.cliente.RequestCrearCliente.ClienteConTarjeta;
import com.interbank.pe.model.tarjeta.EstadoCuentaTarjetaCredito.EstadoCuentaTarjetaCredito;
import com.interbank.pe.questions.Extracash.OfertaAjustadaMensajeError;
import com.interbank.pe.questions.ObtenerRespuestaGenerica;
import com.interbank.pe.questions.VerificaCodigoRespuesta;
import com.interbank.pe.questions.compraDeuda.RespuestaOfertaAjustada;
import com.interbank.pe.questions.tarjeta.ListarClientesConTC;
import com.interbank.pe.questions.tarjeta.estadoCuentaTarjetaCredito.EstadoCuentaTC;
import com.interbank.pe.stepdefinitions.servicios.PayServicesStepDefs;
import com.interbank.pe.stepdefinitions.tarjeta.ConsultarTarjetaStepDef;
import com.interbank.pe.tasks.card.ActualizarDataTarjetaUtilizada;
import com.interbank.pe.tasks.compraDeuda.OfertaAjustadaCompraDeuda;
import com.interbank.pe.utils.soap.UtilsTarjeta;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.util.EnvironmentVariables;

import java.text.DecimalFormat;
import java.util.Random;

import static com.interbank.pe.utils.soap.UtilsTarjeta.truncarPAN;
import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorCalled;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;

public class OfertaAjustadaCompraDeudaDefs {
    public ClienteConTarjeta clienteConTarjeta;
    public OfertaAjustadaCompraDeudaRequest ofertaAjustadaCompraDeudaRequest = new OfertaAjustadaCompraDeudaRequest();
    private EnvironmentVariables environmentVariables;
    @Steps
    PayServicesStepDefs payServicesStepDefs;
    @Steps
    ConsultarTarjetaStepDef consultarTarjetaStepDef;
    Double maximumAmount = 16000.00;
    Double minimumAmount = 50.00;
    Double percentageAvaible = 0.30;
    Double interesRate = 0.49;
    Double montoCompraDeuda;
    String cardIdType = "0";
    String tarjeta;
    String procesType = "2";
    String montoUsado;
    EstadoCuentaTarjetaCredito estadoCuentaTarjetaCredito;

    @Given("que el {} cuenta con tarjeta de credito activa")
    public void queElClienteCuentaConTarjetaDeCreditoActiva(String actor) {
        theActorCalled(actor);
        clienteConTarjeta = new ListarClientesConTC().answeredBy(theActorInTheSpotlight());
        this.tarjeta = clienteConTarjeta.getCard();
        this.montoCompraDeuda = 0.00;
        theActorInTheSpotlight().remember("contrato", clienteConTarjeta.getContrato());
        theActorInTheSpotlight().remember("customerType", clienteConTarjeta.getCustomerType());
        theActorInTheSpotlight().remember("card", clienteConTarjeta.getCard());
        theActorInTheSpotlight().remember("marcaTC", clienteConTarjeta.getMarcaTC());
        theActorInTheSpotlight().remember("tipoTC", clienteConTarjeta.getTipoTC());
        theActorInTheSpotlight().remember("producto", clienteConTarjeta.getProducto());
        theActorInTheSpotlight().remember("description", clienteConTarjeta.getDescription());
        theActorInTheSpotlight().remember("condicionEconomica", clienteConTarjeta.getCondicionEconomica());
        theActorInTheSpotlight().remember("lineaCredito", clienteConTarjeta.getLineaCredito());
        theActorInTheSpotlight().remember("lineaCreditoMax", clienteConTarjeta.getLineaCreditoMax());
        theActorInTheSpotlight().remember("tipoDocumento", clienteConTarjeta.getTipoDocumento());
        theActorInTheSpotlight().remember("numeroDocumento", clienteConTarjeta.getNumeroDocumento());
        theActorInTheSpotlight().remember("primerNombre", clienteConTarjeta.getPrimerNombre());
        theActorInTheSpotlight().remember("segundoNombre", clienteConTarjeta.getSegundoNombre());
        theActorInTheSpotlight().remember("primerApellido", clienteConTarjeta.getPrimerApellido());
        theActorInTheSpotlight().remember("segundoApellido", clienteConTarjeta.getSegundoApellido());

        theActorInTheSpotlight().attemptsTo(ActualizarDataTarjetaUtilizada.now(clienteConTarjeta.getCard()));
    }

    @When("realiza consulta de compra de deuda por PAN en claro")
    public void realizaConsultaDeCompraDeDeudaPorPANEnClaro() {

        this.montoCompraDeuda = montoAleatorioRandom(Double.parseDouble(clienteConTarjeta.getLineaCredito()), maximumAmount);

        ofertaAjustadaCompraDeudaRequest.setProcessType(this.procesType);
        ofertaAjustadaCompraDeudaRequest.setCardId(clienteConTarjeta.getCard());
        ofertaAjustadaCompraDeudaRequest.setAmount(montoCompraDeuda);
        ofertaAjustadaCompraDeudaRequest.setMode(2);
        ofertaAjustadaCompraDeudaRequest.setMaximumAmount(String.valueOf(maximumAmount));
        ofertaAjustadaCompraDeudaRequest.setMinimumAmount(String.valueOf(minimumAmount));
        ofertaAjustadaCompraDeudaRequest.setPercentageAvailable(String.valueOf(percentageAvaible));
        ofertaAjustadaCompraDeudaRequest.setInterestRate(String.valueOf(interesRate));
        theActorInTheSpotlight()
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")))
                .attemptsTo(OfertaAjustadaCompraDeuda.deCliente(ofertaAjustadaCompraDeudaRequest, "0"));
    }

    @Then("el servicio de compra de deuda retorna mensaje de confirmacion sin datos de la tarjeta")
    public void elServicioDeCompraDeDeudaRetornaMensajeDeConfirmacion() {
        theActorInTheSpotlight().
                should(
                        seeThat("estado del servicio", VerificaCodigoRespuesta.delServicio(), equalTo(200))
                );

        OfferInformation offerInformation = new RespuestaOfertaAjustada().answeredBy(theActorInTheSpotlight()).getOfferInformation();
        theActorInTheSpotlight()
                .should(seeThat("Valida getCardId", actor -> offerInformation.getCardId(), equalTo("")),
                        seeThat("Valida getCurrentLine", actor -> offerInformation.getCurrentLine(), equalTo(clienteConTarjeta.getLineaCredito())),
                        seeThat("Valida getUsedSign", actor -> offerInformation.getUsedSign(), equalTo("+")),
                        seeThat("Valida getLineUses", actor -> offerInformation.getLineUses(), equalTo("0.00")),
                        seeThat("Valida getLineAvailable", actor -> offerInformation.getLineAvailable(), equalTo(clienteConTarjeta.getLineaCredito())),
                        seeThat("Valida getAvailableCalculated", actor -> offerInformation.getAvailableCalculated(), equalTo(disponibleCalculado(Double.parseDouble(offerInformation.getLineAvailable()), this.percentageAvaible) + "0")),
                        seeThat("Valida getFactorAvailable", actor -> offerInformation.getFactorAvailable(), notNullValue()),
                        seeThat("Valida getTea", actor -> offerInformation.getTea(), notNullValue()),
                        seeThat("Valida getCapitalizedDays", actor -> offerInformation.getCapitalizedDays(), notNullValue()),
                        seeThat("Valida getMinimumOffer", actor -> offerInformation.getMinimumOffer(), notNullValue()),
                        seeThat("Valida getInterestMinimumOffer", actor -> offerInformation.getInterestMinimumOffer(), notNullValue()),
                        seeThat("Valida getOfferIncreaseLine", actor -> offerInformation.getOfferIncreaseLine(), notNullValue()),
                        seeThat("Valida getAvailableOfferIncreaseLine", actor -> offerInformation.getAvailableOfferIncreaseLine(), notNullValue()),
                        seeThat("Valida getInterestOfferIncreaseLine", actor -> offerInformation.getInterestOfferIncreaseLine(), notNullValue()),
                        seeThat("Valida getOfferWithoutLineIncrease", actor -> offerInformation.getOfferWithoutLineIncrease(), notNullValue()),
                        seeThat("Valida getAvailableOfferWithoutLineIncrease", actor -> offerInformation.getAvailableOfferWithoutLineIncrease(), notNullValue()),
                        seeThat("Valida getInterestOfferWithoutLineIncrease", actor -> offerInformation.getInterestOfferWithoutLineIncrease(), notNullValue())
                );
    }


    @When("realiza consulta de compra de deuda por PAN truncado mas codigo unico")
    public void realizaConsultaDeCompraDeDeudaPorPANTruncadoMasCodigoUnico() {
        //this.montoCompraDeuda = montoAleatorioRandom(Double.parseDouble(clienteConTarjeta.getLineaCredito()), maximumAmount);
        System.out.println("Monto Minimo" + minimumAmount);
        System.out.println("Monto Maximo" + maximumAmount);
        this.montoCompraDeuda = (UtilsTarjeta.montoAleatorioRandom(this.minimumAmount, this.maximumAmount));
        ofertaAjustadaCompraDeudaRequest.setDocumentType("");
        ofertaAjustadaCompraDeudaRequest.setReferenceId(clienteConTarjeta.getCustomerType());
        ofertaAjustadaCompraDeudaRequest.setProcessType(this.procesType);
        ofertaAjustadaCompraDeudaRequest.setCardId(truncarPAN(clienteConTarjeta.getCard()));
        ofertaAjustadaCompraDeudaRequest.setAmount(montoCompraDeuda);
        ofertaAjustadaCompraDeudaRequest.setMode(2);
        ofertaAjustadaCompraDeudaRequest.setMaximumAmount(String.valueOf(maximumAmount));
        ofertaAjustadaCompraDeudaRequest.setMinimumAmount(String.valueOf(minimumAmount));
        ofertaAjustadaCompraDeudaRequest.setPercentageAvailable(String.valueOf(percentageAvaible));
        ofertaAjustadaCompraDeudaRequest.setInterestRate(String.valueOf(interesRate));

        theActorInTheSpotlight()
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")))
                .attemptsTo(OfertaAjustadaCompraDeuda.deCliente(ofertaAjustadaCompraDeudaRequest, "1"));
    }

    @When("realiza consulta de compra de deuda por PAN truncado mas documento de identidad")
    public void realizaConsultaDeCompraDeDeudaPorPANTruncadoMasDocumentoDeIdentidad() {
        this.montoCompraDeuda = montoAleatorioRandom(Double.parseDouble(clienteConTarjeta.getLineaCredito()), maximumAmount);

        ofertaAjustadaCompraDeudaRequest.setDocumentType(clienteConTarjeta.getTipoDocumento());
        ofertaAjustadaCompraDeudaRequest.setReferenceId(clienteConTarjeta.getNumeroDocumento());
        ofertaAjustadaCompraDeudaRequest.setProcessType(this.procesType);
        ofertaAjustadaCompraDeudaRequest.setCardId(truncarPAN(clienteConTarjeta.getCard()));
        ofertaAjustadaCompraDeudaRequest.setAmount(montoCompraDeuda);
        ofertaAjustadaCompraDeudaRequest.setMode(2);
        ofertaAjustadaCompraDeudaRequest.setMaximumAmount(String.valueOf(maximumAmount));
        ofertaAjustadaCompraDeudaRequest.setMinimumAmount(String.valueOf(minimumAmount));
        ofertaAjustadaCompraDeudaRequest.setPercentageAvailable(String.valueOf(percentageAvaible));
        ofertaAjustadaCompraDeudaRequest.setInterestRate(String.valueOf(interesRate));

        theActorInTheSpotlight()
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")))
                .attemptsTo(OfertaAjustadaCompraDeuda.deCliente(ofertaAjustadaCompraDeudaRequest, "2"));
    }

    @When("realiza consulta de compra de deuda por PAN truncado mas numero de cuenta")
    public void realizaConsultaDeCompraDeDeudaPorPANTruncadoMasNumeroDeCuenta() {
        this.montoCompraDeuda = montoAleatorioRandom(Double.parseDouble(clienteConTarjeta.getLineaCredito()), maximumAmount);

        ofertaAjustadaCompraDeudaRequest.setDocumentType("");
        ofertaAjustadaCompraDeudaRequest.setReferenceId(clienteConTarjeta.getContrato());
        ofertaAjustadaCompraDeudaRequest.setProcessType(this.procesType);
        ofertaAjustadaCompraDeudaRequest.setCardId("");
        ofertaAjustadaCompraDeudaRequest.setCardId(truncarPAN(clienteConTarjeta.getCard()));
        ofertaAjustadaCompraDeudaRequest.setAmount(montoCompraDeuda);
        ofertaAjustadaCompraDeudaRequest.setMode(2);
        ofertaAjustadaCompraDeudaRequest.setMaximumAmount(String.valueOf(maximumAmount));
        ofertaAjustadaCompraDeudaRequest.setMinimumAmount(String.valueOf(minimumAmount));
        ofertaAjustadaCompraDeudaRequest.setPercentageAvailable(String.valueOf(percentageAvaible));
        ofertaAjustadaCompraDeudaRequest.setInterestRate(String.valueOf(interesRate));

        theActorInTheSpotlight()
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")))
                .attemptsTo(OfertaAjustadaCompraDeuda.deCliente(ofertaAjustadaCompraDeudaRequest, "3"));
    }

    @Then("el servicio de compra de deuda retorna mensaje de confirmacion con datos de la Tarjeta")
    public void elServicioDeCompraDeDeudaRetornaMensajeDeConfirmacionConDatosDeLaTarjeta() {
        theActorInTheSpotlight().
                should(
                        seeThat("estado del servicio", VerificaCodigoRespuesta.delServicio(), equalTo(200))
                );

        OfferInformation offerInformation = new RespuestaOfertaAjustada().answeredBy(theActorInTheSpotlight()).getOfferInformation();
        theActorInTheSpotlight()
                .should(seeThat("Valida getCardId", actor -> offerInformation.getCardId(), equalTo(truncarPAN(clienteConTarjeta.getCard()))),
                        seeThat("Valida getCurrentLine", actor -> offerInformation.getCurrentLine(), equalTo(clienteConTarjeta.getLineaCredito())),
                        seeThat("Valida getUsedSign", actor -> offerInformation.getUsedSign(), equalTo("+")),
                        seeThat("Valida getLineUses", actor -> offerInformation.getLineUses(), equalTo("0.00")),
                        seeThat("Valida getLineAvailable", actor -> offerInformation.getLineAvailable(), equalTo(clienteConTarjeta.getLineaCredito())),
                        seeThat("Valida getAvailableCalculated", actor -> offerInformation.getAvailableCalculated(), equalTo(disponibleCalculado(Double.parseDouble(offerInformation.getLineAvailable()), this.percentageAvaible) + "0")),
                        seeThat("Valida getFactorAvailable", actor -> offerInformation.getFactorAvailable(), notNullValue()),
                        seeThat("Valida getTea", actor -> offerInformation.getTea(), notNullValue()),
                        seeThat("Valida getCapitalizedDays", actor -> offerInformation.getCapitalizedDays(), notNullValue()),
                        seeThat("Valida getMinimumOffer", actor -> offerInformation.getMinimumOffer(), notNullValue()),
                        seeThat("Valida getInterestMinimumOffer", actor -> offerInformation.getInterestMinimumOffer(), notNullValue()),
                        seeThat("Valida getOfferIncreaseLine", actor -> offerInformation.getOfferIncreaseLine(), notNullValue()),
                        seeThat("Valida getAvailableOfferIncreaseLine", actor -> offerInformation.getAvailableOfferIncreaseLine(), notNullValue()),
                        seeThat("Valida getInterestOfferIncreaseLine", actor -> offerInformation.getInterestOfferIncreaseLine(), notNullValue()),
                        seeThat("Valida getOfferWithoutLineIncrease", actor -> offerInformation.getOfferWithoutLineIncrease(), notNullValue()),
                        seeThat("Valida getAvailableOfferWithoutLineIncrease", actor -> offerInformation.getAvailableOfferWithoutLineIncrease(), notNullValue()),
                        seeThat("Valida getInterestOfferWithoutLineIncrease", actor -> offerInformation.getInterestOfferWithoutLineIncrease(), notNullValue())
                );
    }


    public Double montoAleatorioRandom(Double ini, Double fin) {
        DecimalFormat df = new DecimalFormat("#.##");

        Random random = new Random();

        int numeroAleatorio = (int) (random.nextInt((int) (fin - ini + 1)) + ini);

        String valorFormateadoStr = df.format(numeroAleatorio);
        return Double.parseDouble(valorFormateadoStr);
    }

    public Double disponibleCalculado(Double saldoDisponible, Double percentageAvailable) {
        DecimalFormat df = new DecimalFormat("#.##");
        Double x = saldoDisponible * percentageAvailable;
        String valorFormateadoStr = df.format(x);
        return Double.parseDouble(valorFormateadoStr);
    }


    @Given("indica realizar consulta de compra de deuda por PAN en claro")
    public void indica_realizar_consulta_de_compra_de_deuda_por_pan_en_claro() {
        this.cardIdType = "0";
    }

    @Given("indica los datos de la tarjeta de credito en trucando")
    public void indica_los_datos_de_la_tarjeta_de_credito_en_trucando() {
        this.tarjeta = truncarPAN(clienteConTarjeta.getCard());
    }

    @When("ejecuta la simulacion de la compra de deuda")
    public void ejecuta_la_simulacion_de_la_compra_de_deuda() {

        ofertaAjustadaCompraDeudaRequest.setDocumentType("");
        ofertaAjustadaCompraDeudaRequest.setReferenceId(this.clienteConTarjeta.getContrato());
        ofertaAjustadaCompraDeudaRequest.setProcessType(this.procesType);
        ofertaAjustadaCompraDeudaRequest.setCardId(this.tarjeta);
        ofertaAjustadaCompraDeudaRequest.setAmount(this.montoCompraDeuda);
        ofertaAjustadaCompraDeudaRequest.setMode(2);
        ofertaAjustadaCompraDeudaRequest.setMaximumAmount(String.valueOf(this.maximumAmount));
        ofertaAjustadaCompraDeudaRequest.setMinimumAmount(String.valueOf(this.minimumAmount));
        ofertaAjustadaCompraDeudaRequest.setPercentageAvailable(String.valueOf(this.percentageAvaible));
        ofertaAjustadaCompraDeudaRequest.setInterestRate(String.valueOf(this.interesRate));

        theActorInTheSpotlight()
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")))
                .attemptsTo(OfertaAjustadaCompraDeuda.deCliente(ofertaAjustadaCompraDeudaRequest, this.cardIdType));
    }

    @Then("el sistema retorna el mensaje ERROR EL PAN ESTA INCORRECTO")
    public void el_sistema_retorna_el_mensaje_error_el_pan_esta_incorrecto() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0024")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERROR EL PAN ESTA INCORRECTA, VERIFIQUE"))
                );
    }

    @Given("indica como oferta maxima de compra de deuda un monto menor a la linea de la tarjeta de credito")
    public void indica_como_oferta_maxima_de_compra_de_deuda_un_monto_menor_a_la_linea_de_la_tarjeta_de_credito() {
        this.maximumAmount = Double.parseDouble(clienteConTarjeta.getLineaCredito()) - 1.0;
        this.minimumAmount = 50.00;
        System.out.println("MaximunAmount" + maximumAmount);
    }

    @Given("indica como oferta minima de compra de deuda un monto mayor al monto maximo")
    public void indica_como_oferta_minima_de_compra_de_deuda_un_monto_mayor_al_monto_maximo() {
        this.maximumAmount = Double.parseDouble(clienteConTarjeta.getLineaCredito()) + 5000.00;
        this.minimumAmount = Double.parseDouble(clienteConTarjeta.getLineaCredito()) - 5000.00;
    }

    @Then("el sistema retorna el mensaje LINEA MAXIMA RECIBIDA ES MENOR A LINEA ACTUAL")
    public void el_sistema_retorna_el_mensaje_linea_maxima_recibida_es_menor_a_linea_actual() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0047")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("LINEA MAXIMA RECIBIDA ES MENOR A LINEA ACTUAL"))
                );
    }

    @Then("el sistema retorna el mensaje IMPORTE LINEA MINIMA RECIBIDA INVALIDA")
    public void el_sistema_retorna_el_mensaje_importe_linea_minima_recibida_invalida() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0042")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERROR IMPORTE LINEA MINIMA RECIBIDA INVALIDA"))
                );
    }

    @Given("indica como monto de compra de deuda un monto superior al maximo")
    public void indica_como_monto_de_compra_de_deuda_un_monto_superior_al_maximo() {
        this.montoCompraDeuda = Double.parseDouble(clienteConTarjeta.getLineaCredito()) * 3;
        this.maximumAmount = Double.parseDouble(clienteConTarjeta.getLineaCredito()) + 5000;
        this.minimumAmount = Double.parseDouble(clienteConTarjeta.getLineaCredito());
    }

    @Then("el sistema de oferta ajustada retorna el mensaje IMPORTE DE NUEVA LINEA SUPERA EL MAXIMO")
    public void el_sistema_de_oferta_ajustada_retorna_el_mensaje_importe_de_nueva_linea_supera_el_maximo() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0018")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("IMPORTE DE NUEVA LINEA SUPERA EL MAXIMO"))
                );
    }

    @Given("indica como tipo de proceso el valor {string}")
    public void indica_como_tipo_de_proceso_el_valor(String procesType) {
        this.procesType = procesType;
    }

    @Given("no indica valores en el campo tipo de proceso de compra de deuda")
    public void no_indica_valores_en_el_campo_tipo_de_proceso_de_compra_de_deuda() {
        this.procesType = "";
    }

    @Then("el sistema de oferta ajustada retorna el mensaje ERROR TIPO DE PROCESO ES 1 O 2")
    public void el_sistema_de_oferta_ajustada_retorna_el_mensaje_error_tipo_de_proceso_es_o() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0029")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERROR TIPO DE PROCESO ES 1 O 2"))
                );
    }

    @Then("el sistema retornara mensaje generico")
    public void el_sistema_retornara_mensaje_generico() {
        ResponseGeneric responseGeneric = new ObtenerRespuestaGenerica().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> responseGeneric.getHttpCode(), equalTo("400")),
                        seeThat(actor -> responseGeneric.getHttpMessage(), equalTo("Bad Request"))
                );
    }

    @Given("no especifica los datos de su tarjeta de credito en la compra de deuda")
    public void no_especifica_los_datos_de_su_tarjeta_de_credito_en_la_compra_de_deuda() {
        this.tarjeta = "";
    }

    @Then("el sistema de oferta ajustada retorna el mensaje ERROR EL PAN ESTA INCORRECTA")
    public void el_sistema_de_oferta_ajustada_retorna_el_mensaje_error_el_pan_esta_incorrecta() {
        theActorInTheSpotlight().should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(theActorInTheSpotlight());
        theActorInTheSpotlight()
                .should(
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")),
                        seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0024")),
                        seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERROR EL PAN ESTA INCORRECTA, VERIFIQUE"))
                );
    }

    @And("cuenta con movimientos realizados en su tarjeta de credito")
    public void cuentaConMovimientosRealizadosEnSuTarjetaDeCredito() {
        payServicesStepDefs.cliente_realiza_un_consumo_con_la_tarjeta_por_el_monto_en_moneda("BENEFIT",this.tarjeta, "100", "604");
        consultarTarjetaStepDef.el_cliente_revisa_el_saldo_disponible_de_su_tarjeta_de_credito_antes_de_transaccionar(clienteConTarjeta.getCard(), clienteConTarjeta.getCustomerType());
        estadoCuentaTarjetaCredito = new EstadoCuentaTC().answeredBy(theActorInTheSpotlight());
        this.montoUsado = estadoCuentaTarjetaCredito.getCreditLine().getUsed().getAmount();
        System.out.println("Monto usado: " + montoUsado);
    }
}
