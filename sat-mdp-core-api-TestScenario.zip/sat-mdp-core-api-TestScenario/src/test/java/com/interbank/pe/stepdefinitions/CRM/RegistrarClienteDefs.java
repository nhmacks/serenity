package com.interbank.pe.stepdefinitions.CRM;

import com.interbank.pe.questions.VerificaCodigoRespuesta;
import com.interbank.pe.tasks.cliente.Cliente.GuardarDatosCliente;
import com.interbank.pe.tasks.crm.registrarCliente;
import io.cucumber.java.en.Given;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.util.EnvironmentVariables;

import java.util.Objects;

import static net.serenitybdd.screenplay.GivenWhenThen.*;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.CoreMatchers.equalTo;

public class RegistrarClienteDefs {
    public net.serenitybdd.screenplay.Actor Actor;
    private EnvironmentVariables environmentVariables;
    private String tipoDocumento;
    int cantidadClientes;

    @Given("que el {actor} cuenta con tipo de documento {string}")
    public void que_el_cliente_cuenta_con_documento_de_identidad_CE(Actor actor, String tipoDocumento) {
        if (Objects.equals(tipoDocumento, "DNI")) {
            this.tipoDocumento = "1";
        } else if (Objects.equals(tipoDocumento, "CE")) {
            this.tipoDocumento = "3";
        }
    }

    @Given("^realiza el alta de \"([^\"]*)\" clientes$")
    public void que_cliente_se_registra_en_el_sistema(Integer cantidadClientes) {
        int i = 1;
        int x = 0;
        theActorInTheSpotlight().remember("cantidadClientes", cantidadClientes);
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente")
                .whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri2")));
        while (i <= cantidadClientes) {
            Actor.attemptsTo(registrarCliente.nuevo(this.tipoDocumento));
            String responseMessage = String.valueOf(SerenityRest.lastResponse().getBody().jsonPath().get("MessageResponse.Header.HeaderResponse.status.busResponseMessage").toString());
            if (Objects.equals(responseMessage, "EJECUCION CON EXITO")) {
                Actor.attemptsTo(GuardarDatosCliente.enArchivoCSV());
                i++;
            }else {
                x++;
                if (x>=3){
                    Actor.should(seeThat("Respuesta del servicio es 201", VerificaCodigoRespuesta.delServicio(), equalTo(201)));
                    break;
                }
            }
        }
    }




}
