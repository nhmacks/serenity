package com.interbank.pe.stepdefinitions.extracash;

import com.interbank.pe.model.Extracash.ofertaAjusta.OfertaAjustadaRequest;
import com.interbank.pe.model.Extracash.ofertaAjusta.OfertaAjustadaResponseError;
import com.interbank.pe.model.Extracash.ofertaAjusta.OfertaAjustadaResponseOk;
import com.interbank.pe.model.cliente.cliente.RequestCrearCliente.ClienteConCampanna;
import com.interbank.pe.model.cliente.cliente.RequestCrearCliente.Clientes;
import com.interbank.pe.model.tarjeta.Tarjeta;
import com.interbank.pe.questions.Extracash.OfertaAjustadaMensajeError;
import com.interbank.pe.questions.Extracash.OfertaAjustadaMensajeOk;
import com.interbank.pe.questions.VerificaCodigoRespuesta;
import com.interbank.pe.questions.cliente.Cliente.ListarClienteConCampanna;
import com.interbank.pe.questions.cliente.Cliente.ListarClientes;
import com.interbank.pe.questions.tarjeta.ListarTarjetas;
import com.interbank.pe.tasks.extracash.OfertaAjustada;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.util.EnvironmentVariables;

import java.util.List;
import java.util.Objects;

import static com.interbank.pe.utils.soap.UtilsTarjeta.truncarPAN;
import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorCalled;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;

public class OfertaAjustadaDefs {
    public Actor Actor;
    private EnvironmentVariables environmentVariables;
    private String pan;
    private String montoCampanna;
    private String cardIdType;
    private String tipoDocumento;
    private String lineaCreditoTC;
    private String porcentajeConsumo;
    private String codigoCliente;
    private String pilotoCampanna;
    private final OfertaAjustadaRequest ofertaAjustadaRequest = new OfertaAjustadaRequest();


    @And("indica como monto de incremento de linea un monto menor a la linea de credito de la tarjeta de credito")

    public void indicaComoLineaDeExtractUnMontoMenorALaLineaDeCreditoDeLaTarjetaDeCredito() {
        this.montoCampanna = String.valueOf((Double.parseDouble(this.montoCampanna) / 2) - 100);
        ofertaAjustadaRequest.setAmount(Double.parseDouble(montoCampanna));
    }

    @When("indica como incremento de linea un monto superior a la oferta de extracash")
    public void indicaComoLineaDeExtracashUnMontoSuperiorALaOfertaDeExtracash() {
        montoCampanna = String.valueOf(Double.parseDouble(montoCampanna) * 3);
        ofertaAjustadaRequest.setAmount(Double.parseDouble(montoCampanna));
    }

    @Given("que la tarjeta del cliente no cuenta con campanna extracash")
    public void queLaTarjetaDelClienteNoCuentaConCampannaExtracash() {
        List<Tarjeta> tarjetas = new ListarTarjetas().answeredBy(Actor);
        List<Clientes> clientes = new ListarClientes().answeredBy(Actor);
        for (Tarjeta tarjeta : tarjetas) {
            if (Objects.equals(tarjeta.getFlagCampanaExtracash(), "") | tarjeta.getFlagCampanaExtracash() == null) {
                for (Clientes clientes1 : clientes) {
                    pan = tarjeta.getCard();
                    codigoCliente = clientes1.getCodigoCliente();
                    montoCampanna = tarjeta.getlineaCreditoMax();
                    tipoDocumento = clientes1.getTipoDocumento();
                    break;
                }
                break;
            }
        }
    }

    @When("indica como incremento de linea un monto ideal")
    public void indicaComoLineaDeExtracashUnMontoIdeal() {
        ofertaAjustadaRequest.setAmount(Double.parseDouble(montoCampanna) + 0);
    }

    @When("indica como numero de tarjeta de credito una tarjeta invalida")
    public void indicaComoNumeroDeTarjetaDeCreditoUnaTarjetaInvalida() {
        ofertaAjustadaRequest.setCardId("9999999999999999");
    }

    @Then("el servicio de oferta ajustada retorna un mensaje de confirmacion")
    public void elServicioDeOfertaAjustadaRetornaUnMensajeDeConfirmacion() {
        Actor.should(seeThat("Status code del servicio = 200", VerificaCodigoRespuesta.delServicio(), equalTo(200)));
        OfertaAjustadaResponseOk ofertaAjustada = new OfertaAjustadaMensajeOk().answeredBy(Actor);
        if (Objects.equals(cardIdType, "0")) {
            Actor.should(seeThat("Valida CardId", actor -> ofertaAjustada.getCardId(), equalTo("")));
        } else if (Objects.equals(cardIdType, "1")) {
            Actor.should(seeThat("Valida CardId", actor -> ofertaAjustada.getCardId(), equalTo(ofertaAjustadaRequest.getCardId())));
        }
        Actor.should(seeThat("Valida CurrentAmount", actor -> ofertaAjustada.getLineCurrentAmount(), equalTo(this.lineaCreditoTC)));   //OK LINEA DE CREDITO DEL CONTRATO
        Actor.should(seeThat("Valida LineUsedSign", actor -> ofertaAjustada.getLineUsedSign(), equalTo("+")));
        Actor.should(seeThat("Valida LineUsedAmount", actor -> ofertaAjustada.getLineUsedAmount(), equalTo("0.00")));          // Monto de linea utilizado = suma de todos los movimientos
        Actor.should(seeThat("Valida LineAvaibleAmount", actor -> ofertaAjustada.getLineAvailableAmount(), equalTo(this.lineaCreditoTC)));   // Monto de linea disponible por utilizar = Linea de credito de TC - Monto linea utilizado
        Actor.should(seeThat("Valida PendingAmount", actor -> ofertaAjustada.getLinePendingAmount(), equalTo("0.00"))); // Movimientos pendientes por aprobar
        Actor.should(seeThat("Valida PendingType", actor -> ofertaAjustada.getLinePendingType(), equalTo("")));   //
        Actor.should(seeThat("Valida AnualInterestRate", actor -> ofertaAjustada.getAnualInterestRate(), notNullValue()));  //Solo validar que contenga algun valor
        Actor.should(seeThat("Valida NoLineIncrementOfferAmount", actor -> ofertaAjustada.getNoLineIncrementOfferAmount(), equalTo("0.00")));
        Actor.should(seeThat("Valida NoLineIncrementAvaibleAmount", actor -> ofertaAjustada.getNoLineIncrementAvailableAmount(), equalTo("0.00")));
        Actor.should(seeThat("Valida LineIncrementFlag", actor -> ofertaAjustada.getLineIncrementFlag(), equalTo("S")));
        Actor.should(seeThat("Valida LineIncrementRequiredFlag", actor -> ofertaAjustada.getLineIncrementRequiredFlag(), equalTo("S")));
        if (ofertaAjustadaRequest.getMode() == 1) {
            Actor.should(seeThat("Valida LineIncrementOfferAmount", actor -> ofertaAjustada.getLineIncrementOfferAmount(), equalTo(lineaCreditoTC)));
            Actor.should(seeThat("Valida LineIncrementAmount", actor -> ofertaAjustada.getLineIncrementAmount(), equalTo(montoCampanna + "0")));
            Actor.should(seeThat("Valida IncrementAmount", actor -> ofertaAjustada.getIncrementAmount(), equalTo(lineaCreditoTC)));
        } else if (ofertaAjustadaRequest.getMode() == 2) {
            Actor.should(seeThat("Valida LineIncrementOfferAmount", actor -> ofertaAjustada.getLineIncrementOfferAmount(), equalTo(ofertaAjustadaRequest.getAmount() + "0")));
            Actor.should(seeThat("Valida LineIncrementAmount", actor -> ofertaAjustada.getLineIncrementAmount(), equalTo(Double.parseDouble(lineaCreditoTC) + ofertaAjustadaRequest.getAmount() + "0")));
            Actor.should(seeThat("Valida IncrementAmount", actor -> ofertaAjustada.getIncrementAmount(), equalTo(ofertaAjustadaRequest.getAmount() + "0")));
        }


        Actor.should(seeThat("Valida LineIncrementAvailableAmount", actor -> ofertaAjustada.getLineIncrementAvailableAmount(), notNullValue()));

        Actor.should(seeThat("Valida MaxLineAmount", actor -> ofertaAjustada.getMaxLineAmount(), equalTo(montoCampanna + "0")));
        Actor.should(seeThat("Valida AvailablePercentage", actor -> ofertaAjustada.getAvailablePercentage(), equalTo(porcentajeConsumo.charAt(0) + "." + porcentajeConsumo.substring(1, 5))));
        Actor.should(seeThat("Valida NoLineIncrementCapitalizedInterestAmount", actor -> ofertaAjustada.getNoLineIncrementCapitalizedInterestAmount(), equalTo("0.00")));
        Actor.should(seeThat("Valida LineIncrementCapitalizedInterestAmount", actor -> ofertaAjustada.getLineIncrementCapitalizedInterestAmount(), notNullValue()));
    }

    @When("indica la tarjeta de credito con formato {}")
    public void indicaLaTarjetaDeCreditoFormatoClaro(String formato) {
        if (Objects.equals(formato, "truncado")) {
            ofertaAjustadaRequest.setCardId(truncarPAN(this.pan));
        } else if (Objects.equals(formato, "en claro")) {
            ofertaAjustadaRequest.setCardId(this.pan);
        }
    }

    @When("realiza consulta oferta ajustada")
    public void realizaConsultaOfertaAjustada() {
        Actor = net.serenitybdd.screenplay.Actor.named("Cliente").whoCan(CallAnApi.at(environmentVariables.getProperty("api.rest.baseUri")));
        Actor.attemptsTo(OfertaAjustada.OfertaAjustada(cardIdType, ofertaAjustadaRequest));
    }

    @When("indica como modo de consulta {}")
    public void indicaRealizarConsultaIncrementoDeLinea(String modoConsulta) {
        if (Objects.equals(modoConsulta, "incremento de linea")) {
            ofertaAjustadaRequest.setMode(1);
        } else if (Objects.equals(modoConsulta, "Extracash")) {
            ofertaAjustadaRequest.setMode(2);
        }
    }

    @When("indica realizar busqueda por {}")
    public void indicaRealizarBusquedaPorPANTruncadoMasCodigoUnico(String cardIdType) {
        if (Objects.equals(cardIdType, "PAN en claro")) {
            this.cardIdType = "0";
        } else if (Objects.equals(cardIdType, "PAN truncado mas codigo unico")) {
            this.cardIdType = "1";
        } else if ((Objects.equals(cardIdType, "PAN truncado mas documento de identidad"))) {
            this.cardIdType = "2";
        } else if ((Objects.equals(cardIdType, "PAN truncado mas numero de cuenta"))) {
            this.cardIdType = "3";
        }
    }

    @Then("el sistema retorna el mensaje NUEVA LINEA MENOR A LA DEL CONTRATO")
    public void elSistemaRetornaElMensajeNUEVALINEAMENORALADELCONTRATO() {
        Actor.should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(Actor);
        Actor.should(seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")));
        Actor.should(seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")));
        Actor.should(seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0037")));
        Actor.should(seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("CDIO035  NUEVA LINEA MENOR A LA DEL CONTRATO")));
    }

    @Then("el sistema retorna el mensaje TC NO ESTA EN CAMPANA")
    public void elSistemaRetornaElMensajeTCNOESTAENCAMPANA() {
        Actor.should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(Actor);
        Actor.should(seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")));
        Actor.should(seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")));
        Actor.should(seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0004")));
        Actor.should(seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("TC NO ESTA EN CAMPANA")));
    }
    @Then("el sistema retorna el mensaje ERROR TARJETA NO EXISTE")
    public void elSistemaRetornaElMensajeERRORTARJETANOEXISTE() {
        Actor.should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(Actor);
        Actor.should(seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")));
        Actor.should(seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")));
        Actor.should(seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0001")));
        Actor.should(seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("ERROR TARJETA NO EXISTE")));
    }

    @Then("el sistema retorna el mensaje IMPORTE DE NUEVA LINEA SUPERA EL MAXIMO")
    public void elSistemaRetornaElMensajeIMPORTEDENUEVALINEASUPERAELMAXIMO() {
        Actor.should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(Actor);
        Actor.should(seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")));
        Actor.should(seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")));
        Actor.should(seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0015")));
        Actor.should(seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("IMPORTE DE NUEVA LINEA SUPERA EL MAXIMO")));
    }

    @And("indica el codigo de cliente")
    public void indicaElCodigoDeCliente() {
        ofertaAjustadaRequest.setReferenceId(this.codigoCliente);
        ofertaAjustadaRequest.setDocumentType(this.tipoDocumento);
    }

    @And("indica como monto de extracash un monto ideal")
    public void indicaComoMontoDeExtracashUnMontoIdeal() {
        ofertaAjustadaRequest.setAmount(300.00);
    }

    @And("indica como monto de extracash el monto {}")
    public void indicaComoMontoDeExtracashElMonto(Double monto) {
        ofertaAjustadaRequest.setAmount(monto);
    }

    @Then("el sistema retorna el mensaje OFERTA MENOR AL MINIMO")
    public void elSistemaRetornaElMensajeOFERTAMENORALMINIMO() {
        Actor.should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(Actor);
        Actor.should(seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")));
        Actor.should(seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")));
        Actor.should(seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0015")));
        Actor.should(seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("OFERTA MENOR AL MINIMO")));
    }

    @Then("el sistema retorna el mensaje IMPORTE MAYOR AL MAX.OFERTA")
    public void elSistemaRetornaElMensajeIMPORTEMAYORALMAXOFERTA() {
        Actor.should(seeThat("Status code del servicio = 403", VerificaCodigoRespuesta.delServicio(), equalTo(403)));
        OfertaAjustadaResponseError ofertaAjustadaResponseError = new OfertaAjustadaMensajeError().answeredBy(Actor);
        Actor.should(seeThat(actor -> ofertaAjustadaResponseError.getHttpCode(), equalTo("403")));
        Actor.should(seeThat(actor -> ofertaAjustadaResponseError.getHttpMessage(), equalTo("Business error")));
        Actor.should(seeThat(actor -> ofertaAjustadaResponseError.getProviderCode(), equalTo("0006")));
        Actor.should(seeThat(actor -> ofertaAjustadaResponseError.getProviderMessage(), equalTo("IMPORTE MAYOR AL MAX.OFERTA")));
    }

    @Given("que el {} cuenta con campaña extracash por monto de {string}")
    public void queElClienteCuentaConCampannaExtracashPorMontoDe(String actor, String montoCampanna) {
        theActorCalled(actor);
        this.montoCampanna = montoCampanna;
    }

    @And("^el indicador de piloto de la campaña es \"([^\"]*)\"$")
    public void elIndicadorDePilotoDeLaCampannaEs(String pilotoCampanna) {
        this.pilotoCampanna = pilotoCampanna;
    }

    @And("el porcentaje disponible de consumo es {string}")
    public void elPorcentajeDisponibleDeConsumoEs(String porcentajeConsumo) {
        this.porcentajeConsumo = porcentajeConsumo;
        ClienteConCampanna clienteConCampanna = new ListarClienteConCampanna(pan, montoCampanna, tipoDocumento, lineaCreditoTC, porcentajeConsumo, pilotoCampanna).answeredBy(Actor);
        this.pan = clienteConCampanna.getPan();
        this.montoCampanna = clienteConCampanna.getMontoCampanna();
        this.cardIdType = clienteConCampanna.getCarIdType();
        this.tipoDocumento = clienteConCampanna.getTipoDocumento();
        this.lineaCreditoTC = clienteConCampanna.getLineaCreditoTC();
        this.porcentajeConsumo = clienteConCampanna.getPorcentajeConsumo();
        this.codigoCliente = clienteConCampanna.getCodigoCliente();
        this.pilotoCampanna = clienteConCampanna.getPilotoCampanna();

        System.out.println("Tarjeta Example: " + pan);
        theActorInTheSpotlight().remember("pan", clienteConCampanna.getPan());
        theActorInTheSpotlight().remember("montoCampanna", clienteConCampanna.getMontoCampanna());
        theActorInTheSpotlight().remember("tipoDocumento", clienteConCampanna.getTipoDocumento());
        theActorInTheSpotlight().remember("lineaCreditoTC", clienteConCampanna.getLineaCreditoTC());
        theActorInTheSpotlight().remember("porcentajeConsumo", clienteConCampanna.getPorcentajeConsumo());
        theActorInTheSpotlight().remember("codigoCliente", clienteConCampanna.getCodigoCliente());
        theActorInTheSpotlight().remember("pilotoCampanna", clienteConCampanna.getPilotoCampanna());
        theActorInTheSpotlight().remember("numeroContratoTC", clienteConCampanna.getNumeroContratoTC());
        theActorInTheSpotlight().remember("codMoneda", clienteConCampanna.getCodMoneda());
        theActorInTheSpotlight().remember("importeExtracash", clienteConCampanna.getImporteExtracash());
        theActorInTheSpotlight().remember("tasaExtracash", clienteConCampanna.getTasaExtracash());
        theActorInTheSpotlight().remember("nroMesesDiferidos", clienteConCampanna.getNroMesesDiferidos());
        theActorInTheSpotlight().remember("indicadorControlPlazo", clienteConCampanna.getIndicadorControlPlazo());
        theActorInTheSpotlight().remember("indicadorSeguroEfectivo", clienteConCampanna.getIndicadorSeguroEfectivo());
        theActorInTheSpotlight().remember("importeCem", clienteConCampanna.getImporteCem());
        theActorInTheSpotlight().remember("indicadorPiloto", clienteConCampanna.getIndicadorPiloto());
        theActorInTheSpotlight().remember("indicadorIncrementoLinea", clienteConCampanna.getIndicadorIncrementoLinea());
        theActorInTheSpotlight().remember("lineaCreditoOrigin", clienteConCampanna.getLineaCreditoTC());
        theActorInTheSpotlight().remember("lineaCreditoMaxima", clienteConCampanna.getLineaCreditoMaxima());
        theActorInTheSpotlight().remember("fechaCaducidad", clienteConCampanna.getFechaCaducidad());
        theActorInTheSpotlight().remember("numeroDocumento", clienteConCampanna.getNumeroDocumento());

    }

    @And("cuenta con una linea de credito de {string}")
    public void queElClienteCuentaConUnaLineaDeCreditoDe(String lineaCreditoTC) {
        this.lineaCreditoTC = lineaCreditoTC;
    }
}
