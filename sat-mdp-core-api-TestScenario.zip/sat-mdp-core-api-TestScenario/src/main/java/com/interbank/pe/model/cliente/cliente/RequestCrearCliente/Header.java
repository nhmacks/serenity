package com.interbank.pe.model.cliente.cliente.RequestCrearCliente;

public class Header {
    private HeaderRequest HeaderRequest;
    public HeaderRequest getHeaderRequest() {
        return HeaderRequest;
    }
    public void setHeaderRequest(HeaderRequest HeaderRequest) {
        this.HeaderRequest = HeaderRequest;
    }
}