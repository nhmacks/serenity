package com.interbank.pe.tasks.crm;

import com.interbank.pe.model.Tarjeta;
import com.interbank.pe.model.cliente.cliente.RequestCrearCliente.*;
import io.restassured.mapper.ObjectMapperType;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Post;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static com.interbank.pe.utils.soap.UtilsNumeroDeDocumento.DNI;
import static com.interbank.pe.utils.soap.UtilsNumeroDeDocumento.randomText;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class registrarCliente implements Task {
    private final String tipoDocumento;

    public registrarCliente(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public static registrarCliente nuevo(String tipoDocumento){
        return instrumented(registrarCliente.class, tipoDocumento);
    }


    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Post.to("ibk/srv/rest/MPO/CRM/cliente.crearCliente/v1.0")
                        .with(
                                requestSpecification ->
                                        requestSpecification
                                                .relaxedHTTPSValidation().and().auth().preemptive().basic("uBseWbpACon", "Ibkubspacon16+")
                                                .header("Host", "dpiuat.grupoib.local:7200")
                                                .header("Accept-Encoding", "gzip,deflate")
                                                .header("Content-Type", "application/json;charset=UTF-8")
                                                .body(request(tipoDocumento), ObjectMapperType.GSON)
                        )
        );
    }

    private Object request(String tipoDocumento) {
        Root root = new Root();
        MessageRequest messageRequest = new MessageRequest();
        Header header = new Header();
        HeaderRequest headerRequest = new HeaderRequest();

        Request request = new Request();
        request.setServiceId("SRM");
        request.setConsumerId("WBP");
        request.setModuleId("orquestadorpepper");
        request.setChannelCode("06");
        request.setMessageId("TESTORQPEPPER12");
        request.setTimestamp("2023-03-20T17:57:48");
        request.setCountryCode("PE");
        request.setGroupMember("G0003");
        request.setReferenceNumber("01153");

        Identity identity = new Identity();
        identity.setNetId("BI");
        identity.setUserId("BPIB0000");
        identity.setSupervisorId("BPIB0000");
        identity.setDeviceId("10.10.26.154");
        identity.setServerId("XT726710AW7");
        identity.setBranchCode("898");

        Body body = new Body();
        CrearCliente crearCliente = new CrearCliente();
        crearCliente.setTipoDocumento(tipoDocumento);

        if (Objects.equals(tipoDocumento, "3")) {
            crearCliente.setNumeroDocumento(DNI());
            crearCliente.setNumeroPasaporte("PERU00000");
            crearCliente.setCodigoPaisNacimiento("4030");
            crearCliente.setCodigoPaisResidencia("4030");
            crearCliente.setCodigoPaisNacionalidad("4030");
            crearCliente.setTipoNacionalidad("1");

        } else if (Objects.equals(tipoDocumento,"1")){
            crearCliente.setNumeroDocumento(DNI());
            crearCliente.setNumeroPasaporte(null);
            crearCliente.setCodigoPaisNacimiento("4028");
            crearCliente.setCodigoPaisResidencia("4028");
            crearCliente.setCodigoPaisNacionalidad("4028");
            crearCliente.setTipoNacionalidad("0");

        }
        Tarjeta.setResponseCollection("tipoDocumento", crearCliente.getTipoDocumento());
        Tarjeta.setResponseCollection("NumeroDocumento", crearCliente.getNumeroDocumento());
        crearCliente.setFechaNacimiento("1991-10-27");
        crearCliente.setApellidoPaterno(randomText());
        Tarjeta.setResponseCollection("primerApellido", crearCliente.getApellidoPaterno());
        crearCliente.setApellidoMaterno(randomText());
        Tarjeta.setResponseCollection("segundoApellido", crearCliente.getApellidoMaterno());
        crearCliente.setPrimerNombre(randomText());
        Tarjeta.setResponseCollection("primerNombre", crearCliente.getPrimerNombre());
        crearCliente.setSegundoNombre(randomText());
        Tarjeta.setResponseCollection("segundoNombre", crearCliente.getSegundoNombre());
        crearCliente.setSexo("M");
        crearCliente.setEstadoCivil("U");

        crearCliente.setTipoVia("AV");
        crearCliente.setNombreVia("TACNA");
        crearCliente.setNumeroCalle("111");
        crearCliente.setIdManzana("A");
        crearCliente.setIdLote("8");
        crearCliente.setIdInterior("102");
        crearCliente.setNombreUrbanizacion("LOS CONDORES");
        crearCliente.setReferenciaUbicacion("AL FRENTE DE HOSPITAL CENTRAL");
        crearCliente.setDepartamento("LIMA");
        crearCliente.setProvincia("LIMA");
        crearCliente.setDistrito("LIMA");
        crearCliente.setTipoEmail("P");
        crearCliente.setEmail("mnunez@encora.com");
        crearCliente.setCodigoCIIU(null);
        crearCliente.setNombreEmpresa(null);
        crearCliente.setCodigoOcupacion(null);

        ListaTelefonos listaTelefonos = new ListaTelefonos();
        List<Telefono> telefonos = new ArrayList<>();
        Telefono telefono = new Telefono();
        telefono.setTipoTelefono("C");
        telefono.setTelediscado("051");
        telefono.setNumeroTelefono("985716010");
        telefonos.add(telefono);
        root.setMessageRequest(messageRequest);
        messageRequest.setHeader(header);
        header.setHeaderRequest(headerRequest);
        headerRequest.setRequest(request);
        headerRequest.setIdentity(identity);
        messageRequest.setBody(body);
        body.setCrearCliente(crearCliente);
        crearCliente.setListaTelefonos(listaTelefonos);
        listaTelefonos.setTelefono(telefonos);
        return root;
    }
}
