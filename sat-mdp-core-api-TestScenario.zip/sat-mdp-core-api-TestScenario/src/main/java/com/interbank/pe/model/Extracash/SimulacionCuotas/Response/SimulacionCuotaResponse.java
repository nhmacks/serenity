package com.interbank.pe.model.Extracash.SimulacionCuotas.Response;

import java.util.ArrayList;
import java.util.List;

public class SimulacionCuotaResponse {
    private String cardId;
    private String campaignDescription;
    private String campaignValidityDate;
    private String authorizedAmount;
    private String currencyId;
    private String linePendingAmount;
    private String linePendingType;
    private String disbursementAmount;
    private String ECdisbursementAmount;
    private String anualInterestRate;
    private String minimumTerm;
    private String maximumTerm;
    private String capitalizedInterestAmount;
    private String deferredInterestAmount;
    private String financedAmount;
    private String newLineAmount;
    private String firstDueDate;
    private String totalDeferredDays;
    private List<Installment> installments = new ArrayList<Installment>();
    private String availableAmount;
    private String calculatedOfferAmount;
    private String insufficientLineFlag;

    public String getCardId() {
        return cardId;
    }

    public void setCardId(String cardId) {
        this.cardId = cardId;
    }

    public String getCampaignDescription() {
        return campaignDescription;
    }

    public void setCampaignDescription(String campaignDescription) {
        this.campaignDescription = campaignDescription;
    }

    public String getCampaignValidityDate() {
        return campaignValidityDate;
    }

    public void setCampaignValidityDate(String campaignValidityDate) {
        this.campaignValidityDate = campaignValidityDate;
    }

    public String getAuthorizedAmount() {
        return authorizedAmount;
    }

    public void setAuthorizedAmount(String authorizedAmount) {
        this.authorizedAmount = authorizedAmount;
    }

    public String getCurrencyId() {
        return currencyId;
    }

    public void setCurrencyId(String currencyId) {
        this.currencyId = currencyId;
    }

    public String getLinePendingAmount() {
        return linePendingAmount;
    }

    public void setLinePendingAmount(String linePendingAmount) {
        this.linePendingAmount = linePendingAmount;
    }

    public String getLinePendingType() {
        return linePendingType;
    }

    public void setLinePendingType(String linePendingType) {
        this.linePendingType = linePendingType;
    }

    public String getDisbursementAmount() {
        return disbursementAmount;
    }

    public void setDisbursementAmount(String disbursementAmount) {
        this.disbursementAmount = disbursementAmount;
    }

    public String getECdisbursementAmount() {
        return ECdisbursementAmount;
    }

    public void setECdisbursementAmount(String ECdisbursementAmount) {
        this.ECdisbursementAmount = ECdisbursementAmount;
    }

    public String getAnualInterestRate() {
        return anualInterestRate;
    }

    public void setAnualInterestRate(String anualInterestRate) {
        this.anualInterestRate = anualInterestRate;
    }

    public String getMinimumTerm() {
        return minimumTerm;
    }

    public void setMinimumTerm(String minimumTerm) {
        this.minimumTerm = minimumTerm;
    }

    public String getMaximumTerm() {
        return maximumTerm;
    }

    public void setMaximumTerm(String maximumTerm) {
        this.maximumTerm = maximumTerm;
    }

    public String getCapitalizedInterestAmount() {
        return capitalizedInterestAmount;
    }

    public void setCapitalizedInterestAmount(String capitalizedInterestAmount) {
        this.capitalizedInterestAmount = capitalizedInterestAmount;
    }

    public String getDeferredInterestAmount() {
        return deferredInterestAmount;
    }

    public void setDeferredInterestAmount(String deferredInterestAmount) {
        this.deferredInterestAmount = deferredInterestAmount;
    }

    public String getFinancedAmount() {
        return financedAmount;
    }

    public void setFinancedAmount(String financedAmount) {
        this.financedAmount = financedAmount;
    }

    public String getNewLineAmount() {
        return newLineAmount;
    }

    public void setNewLineAmount(String newLineAmount) {
        this.newLineAmount = newLineAmount;
    }

    public String getFirstDueDate() {
        return firstDueDate;
    }

    public void setFirstDueDate(String firstDueDate) {
        this.firstDueDate = firstDueDate;
    }

    public String getTotalDeferredDays() {
        return totalDeferredDays;
    }

    public void setTotalDeferredDays(String totalDeferredDays) {
        this.totalDeferredDays = totalDeferredDays;
    }

    public List<Installment> getInstallments() {
        return installments;
    }

    public void setInstallments(List<Installment> installments) {
        this.installments = installments;
    }

    public String getAvailableAmount() {
        return availableAmount;
    }

    public void setAvailableAmount(String availableAmount) {
        this.availableAmount = availableAmount;
    }

    public String getCalculatedOfferAmount() {
        return calculatedOfferAmount;
    }

    public void setCalculatedOfferAmount(String calculatedOfferAmount) {
        this.calculatedOfferAmount = calculatedOfferAmount;
    }

    public String getInsufficientLineFlag() {
        return insufficientLineFlag;
    }

    public void setInsufficientLineFlag(String insufficientLineFlag) {
        this.insufficientLineFlag = insufficientLineFlag;
    }
}