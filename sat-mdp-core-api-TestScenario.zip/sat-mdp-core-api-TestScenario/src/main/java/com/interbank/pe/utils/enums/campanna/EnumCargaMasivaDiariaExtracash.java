package com.interbank.pe.utils.enums.campanna;

public enum EnumCargaMasivaDiariaExtracash {
    CODIGO_MONEDA("01"),
    COD_CAMPANNA_SIEBEL("   1-1RM"),
    IMPORTE_CEM("002500");
    private final String valor;
    EnumCargaMasivaDiariaExtracash(String valor){
        this.valor=valor;
    }

    public String getValor(){
        return valor;
    }
}
