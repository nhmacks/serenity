package com.interbank.pe.model.cliente.cliente.RequestCrearCliente;

public class Clientes {
    private String tipoDocumento;
    private String numeroDocumento;
    private String primerNombre;
    private String segundoNombre;
    private String primerApellido;
    private String segundoApellido;
    private String codigoCliente;
    private String fechaCreacionCodClient;
    private String tarjetaCredito;
    private String fechaCreacionTC;
    private String contrato;
    private String fechaActivacionTC;

    public Clientes(String tipoDocumento, String numeroDocumento, String primerNombre, String segundoNombre, String primerApellido, String segundoApellido, String codigoCliente, String fechaCreacionCodClient, String tarjetaCredito, String fechaCreacionTC, String contrato, String fechaActivacionTC) {
        this.tipoDocumento = tipoDocumento;
        this.numeroDocumento = numeroDocumento;
        this.primerNombre = primerNombre;
        this.segundoNombre = segundoNombre;
        this.primerApellido = primerApellido;
        this.segundoApellido = segundoApellido;
        this.codigoCliente = codigoCliente;
        this.fechaCreacionCodClient = fechaCreacionCodClient;
        this.tarjetaCredito = tarjetaCredito;
        this.fechaCreacionTC = fechaCreacionTC;
        this.contrato = contrato;
        this.fechaActivacionTC = fechaActivacionTC;
    }


    public void setTipoDocumento(String tipoDocumento){
        this.tipoDocumento= tipoDocumento;
    }
    public void setNumeroDocumento(String numeroDocumento) {
        this.numeroDocumento = numeroDocumento;
    }

    public void setPrimerNombre(String primerNombre) {
        this.primerNombre = primerNombre;
    }

    public void setSegundoNombre(String segundoNombre) {
        this.segundoNombre = segundoNombre;
    }

    public void setPrimerApellido(String primerApellido) {
        this.primerApellido = primerApellido;
    }

    public void setSegundoApellido(String segundoApellido) {
        this.segundoApellido = segundoApellido;
    }

    public void setFechaCreacionCodClient(String fechaCreacionCodClient) {
        this.fechaCreacionCodClient = fechaCreacionCodClient;
    }

    public void setTarjetaCredito(String tarjetaCredito) {
        this.tarjetaCredito = tarjetaCredito;
    }

    public void setFechaCreacionTC(String fechaCreacionTC) {
        this.fechaCreacionTC = fechaCreacionTC;
    }

    public void setContrato(String contrato) {
        this.contrato = contrato;
    }

    public void setFechaActivacionTC(String fechaActivacionTC) {
        this.fechaActivacionTC = fechaActivacionTC;
    }

public String getTipoDocumento(){
        return tipoDocumento;
}
    public String getNumeroDocumento() {
        return numeroDocumento;
    }

    public String getPrimerNombre() {
        return primerNombre;
    }

    public String getSegundoNombre() {
        return segundoNombre;
    }

    public String getPrimerApellido() {
        return primerApellido;
    }

    public String getSegundoApellido() {
        return segundoApellido;
    }

    public String getCodigoCliente() {
        return codigoCliente;
    }

    public String getFechaCreacionCodClient() {
        return fechaCreacionCodClient;
    }

    public String getTarjetaCredito() {
        return tarjetaCredito;
    }

    public String getFechaCreacionTC() {
        return fechaCreacionTC;
    }

    public String getContrato() {
        return contrato;
    }

    public String getFechaActivacionTC() {
        return fechaActivacionTC;
    }

    @Override
    public String toString() {
        return "ListaClientesOnbordeados{" +
                "tipoDocumento='" + tipoDocumento + '\'' +
                "numeroDocumento='" + numeroDocumento + '\'' +
                ", primerNombre='" + primerNombre + '\'' +
                ", segundoNombre='" + segundoNombre + '\'' +
                ", primerApellido='" + primerApellido + '\'' +
                ", segundoApellido='" + segundoApellido + '\'' +
                ", codigoCliente='" + codigoCliente + '\'' +
                ", fechaCreacionCodClient='" + fechaCreacionCodClient + '\'' +
                ", tarjetaCredito='" + tarjetaCredito + '\'' +
                ", fechaCreacionTC='" + fechaCreacionTC + '\'' +
                ", contrato='" + contrato + '\'' +
                ", fechaActivacionTC='"+fechaActivacionTC + '\'' +
                '}';
    }
}
