package com.interbank.pe.tasks.account;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Post;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class AnularContrato implements Task {
    private final String contrato;

    public AnularContrato(String contrato) {
        this.contrato = contrato;
    }

    public static AnularContrato deCuenta(String contrato) {
        return instrumented(AnularContrato.class, contrato);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Post.to("/ibk/uat/api/credit-account/v1/" + contrato + "/annulation")
                        .with(
                                requestSpecification ->
                                        requestSpecification
                                                .relaxedHTTPSValidation()
                                                .header("X-INT-Device-Id", "127.0.0.1")
                                                .header("X-INT-Timestamp", "2020-08-12T17:57:48")
                                                .header("X-INT-Net-Id", "BI")
                                                .header("X-IBM-Client-Id", "87529776-e9cd-4ae3-abf0-1c8858ee2e1d")
                                                .header("X-INT-Service-Id", "APA")
                                                .header("X-INT-CardId-Type", "0")
                                                .header("X-INT-Supervisor-Id", "APPA0001")
                                                .header("X-INT-Branch-Id", "898")
                                                .header("X-INT-Consumer-Id", "APP")
                                                .header("X-INT-Message-Id", "CADS_200920211740")
                                                .header("X-INT-User-Id", "APPA0001")
                                                .header("Authorization", "Basic dUJzZUFBREFBZG06YjFBQUoyWURL")
                                                .header("Content-Type", "application/json")
                                                .body("{\n" +
                                                        "\t\"processType\": 1,                                    \n" +
                                                        "\t\"application\": \"AAD\",                                       \n" +
                                                        "\t\"documentType\": \"1\",                                        \n" +
                                                        "\t\"referenceId\": \"" + contrato + "\"\n" +
                                                        "}")
                        )
        );
    }
}
