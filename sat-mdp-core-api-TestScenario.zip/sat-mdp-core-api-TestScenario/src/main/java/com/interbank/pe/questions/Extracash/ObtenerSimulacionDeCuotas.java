package com.interbank.pe.questions.Extracash;

import com.interbank.pe.model.Extracash.SimulacionCuotas.Response.SimulacionCuotaResponse;
import io.restassured.mapper.ObjectMapperType;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class ObtenerSimulacionDeCuotas implements Question {
    @Override
    public SimulacionCuotaResponse answeredBy(Actor actor) {
        return SerenityRest.lastResponse().as(SimulacionCuotaResponse.class,ObjectMapperType.GSON);
    }
}
