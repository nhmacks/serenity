package com.interbank.pe.questions;

import com.interbank.pe.model.ResponseGeneric;
import io.restassured.mapper.ObjectMapperType;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class ObtenerRespuestaGenerica implements Question<ResponseGeneric> {

    @Override
    public ResponseGeneric answeredBy(Actor actor) {
        return SerenityRest.lastResponse().as(ResponseGeneric.class, ObjectMapperType.GSON);
    }
}
