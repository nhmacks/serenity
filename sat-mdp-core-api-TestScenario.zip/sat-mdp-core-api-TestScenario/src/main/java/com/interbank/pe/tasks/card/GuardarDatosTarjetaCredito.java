package com.interbank.pe.tasks.card;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.joda.time.LocalDateTime;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import static com.interbank.pe.utils.soap.EnumRequestSoap.CLIENTE_TARJETA;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class GuardarDatosTarjetaCredito implements Task {
    private final String contrato;
    private final String card;
    private final String marca;
    private final String tipo;
    private final String producto;
    private final String descripcionProducto;
    private final String condEconomica;
    private final String creditline;
    private final String lineaMaxima;
    private final String customerTipe;

    public GuardarDatosTarjetaCredito(String contrato, String customerTipe, String card, String marca, String tipo, String producto, String descripcionProducto, String condEconomica, String creditline, String lineaMaxima) {
        this.contrato = contrato;
        this.customerTipe = customerTipe;
        this.card = card;
        this.marca = marca;
        this.tipo = tipo;
        this.producto = producto;
        this.condEconomica=condEconomica;
        this.descripcionProducto = descripcionProducto;
        this.creditline = creditline;
        this.lineaMaxima = lineaMaxima;
    }

    public static GuardarDatosTarjetaCredito enArchivoCSV(String contrato, String customerTipe, String card, String marca, String tipo, String producto, String descripcionProducto, String condEconomica, String creditline, String lineaMaxima) {
        return instrumented(GuardarDatosTarjetaCredito.class, contrato, customerTipe, card, marca, tipo, producto, descripcionProducto, condEconomica, creditline, lineaMaxima);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        String filePath = CLIENTE_TARJETA.getPathArchivo();
        try {
            File csvFile = new File(filePath);
            FileReader csvReader = new FileReader(csvFile);
            CSVParser parser = new CSVParser(csvReader, CSVFormat.DEFAULT);
            FileWriter csvWriter = new FileWriter(csvFile, true);
            CSVPrinter printer = new CSVPrinter(csvWriter, CSVFormat.DEFAULT);
            LocalDateTime dateTime = LocalDateTime.now();
            List<String> newData = Arrays.asList(contrato, customerTipe, card, marca, tipo, producto, descripcionProducto, condEconomica, creditline, lineaMaxima, dateTime.toString());
            printer.printRecord(newData);
            parser.close();
            printer.close();
            csvReader.close();
            csvWriter.close();
            System.out.println("CSV file created successfully! - TC registrado");
        } catch (IOException e) {
            System.out.println("Error creating CSV file: " + e.getMessage());
        }
        ;
    }
}
