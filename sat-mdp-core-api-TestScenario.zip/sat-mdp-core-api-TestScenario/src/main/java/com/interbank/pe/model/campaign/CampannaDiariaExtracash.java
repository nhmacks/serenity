package com.interbank.pe.model.campaign;

public class CampannaDiariaExtracash {
    private String numeroCuenta;
    private String codigoMoneda;
    private String importeLineaExtracash;
    private String tasaExtracash;
    private String mesesDiferido;
    private String indicadorControlPlazo;
    private String indicadorSeguroEfectivo;
    private String codigoCampannaSiebel;
    private String importeCEM;
    private String indicadorPiloto;
    private String indicadorIncrementoLinea;
    private String porcentajeDisponibleConsumo;
    private String lineaCreditoOrigen;
    private String lineaCreditoMaxima;
    private String fechaCaducidad;
    private String filler;
    private String fechaCreacionCampanna;
    private String flagCampannaDiaria;

    public CampannaDiariaExtracash(String numeroCuenta, String codigoMoneda, String importeLineaExtracash, String tasaExtracash, String mesesDiferido, String indicadorControlPlazo, String indicadorSeguroEfectivo, String codigoCampannaSiebel, String importeCEM, String indicadorPiloto, String indicadorIncrementoLinea, String porcentajeDisponibleConsumo, String lineaCreditoOrigen, String lineaCreditoMaxima, String fechaCaducidad, String filler, String fechaCreacionCampanna, String flagCampannaDiaria) {
        this.numeroCuenta = numeroCuenta;
        this.codigoMoneda = codigoMoneda;
        this.importeLineaExtracash = importeLineaExtracash;
        this.tasaExtracash = tasaExtracash;
        this.mesesDiferido = mesesDiferido;
        this.indicadorControlPlazo = indicadorControlPlazo;
        this.indicadorSeguroEfectivo = indicadorSeguroEfectivo;
        this.codigoCampannaSiebel = codigoCampannaSiebel;
        this.importeCEM = importeCEM;
        this.indicadorPiloto = indicadorPiloto;
        this.indicadorIncrementoLinea = indicadorIncrementoLinea;
        this.porcentajeDisponibleConsumo = porcentajeDisponibleConsumo;
        this.lineaCreditoOrigen = lineaCreditoOrigen;
        this.lineaCreditoMaxima = lineaCreditoMaxima;
        this.fechaCaducidad = fechaCaducidad;
        this.filler = filler;
        this.fechaCreacionCampanna = fechaCreacionCampanna;
        this.flagCampannaDiaria = flagCampannaDiaria;
    }

    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public String getCodigoMoneda() {
        return codigoMoneda;
    }

    public void setCodigoMoneda(String codigoMoneda) {
        this.codigoMoneda = codigoMoneda;
    }

    public String getImporteLineaExtracash() {
        return importeLineaExtracash;
    }

    public void setImporteLineaExtracash(String importeLineaExtracash) {
        this.importeLineaExtracash = importeLineaExtracash;
    }

    public String getTasaExtracash() {
        return tasaExtracash;
    }

    public void setTasaExtracash(String tasaExtracash) {
        this.tasaExtracash = tasaExtracash;
    }

    public String getMesesDiferido() {
        return mesesDiferido;
    }

    public void setMesesDiferido(String mesesDiferido) {
        this.mesesDiferido = mesesDiferido;
    }

    public String getIndicadorControlPlazo() {
        return indicadorControlPlazo;
    }

    public void setIndicadorControlPlazo(String indicadorControlPlazo) {
        this.indicadorControlPlazo = indicadorControlPlazo;
    }

    public String getIndicadorSeguroEfectivo() {
        return indicadorSeguroEfectivo;
    }

    public void setIndicadorSeguroEfectivo(String indicadorSeguroEfectivo) {
        this.indicadorSeguroEfectivo = indicadorSeguroEfectivo;
    }

    public String getCodigoCampannaSiebel() {
        return codigoCampannaSiebel;
    }

    public void setCodigoCampannaSiebel(String codigoCampannaSiebel) {
        this.codigoCampannaSiebel = codigoCampannaSiebel;
    }

    public String getImporteCEM() {
        return importeCEM;
    }

    public void setImporteCEM(String importeCEM) {
        this.importeCEM = importeCEM;
    }

    public String getIndicadorPiloto() {
        return indicadorPiloto;
    }

    public void setIndicadorPiloto(String indicadorPiloto) {
        this.indicadorPiloto = indicadorPiloto;
    }

    public String getIndicadorIncrementoLinea() {
        return indicadorIncrementoLinea;
    }

    public void setIndicadorIncrementoLinea(String indicadorIncrementoLinea) {
        this.indicadorIncrementoLinea = indicadorIncrementoLinea;
    }

    public String getPorcentajeDisponibleConsumo() {
        return porcentajeDisponibleConsumo;
    }

    public void setPorcentajeDisponibleConsumo(String porcentajeDisponibleConsumo) {
        this.porcentajeDisponibleConsumo = porcentajeDisponibleConsumo;
    }

    public String getLineaCreditoOrigen() {
        return lineaCreditoOrigen;
    }

    public void setLineaCreditoOrigen(String lineaCreditoOrigen) {
        this.lineaCreditoOrigen = lineaCreditoOrigen;
    }

    public String getLineaCreditoMaxima() {
        return lineaCreditoMaxima;
    }

    public void setLineaCreditoMaxima(String lineaCreditoMaxima) {
        this.lineaCreditoMaxima = lineaCreditoMaxima;
    }

    public String getFechaCaducidad() {
        return fechaCaducidad;
    }

    public void setFechaCaducidad(String fechaCaducidad) {
        this.fechaCaducidad = fechaCaducidad;
    }

    public String getFiller() {
        return filler;
    }

    public void setFiller(String filler) {
        this.filler = filler;
    }

    public String getFechaCreacionCampanna() {
        return fechaCreacionCampanna;
    }

    public void setFechaCreacionCampanna(String fechaCreacionCampanna) {
        this.fechaCreacionCampanna = fechaCreacionCampanna;
    }

    public String getFlagCampannaDiaria() {
        return flagCampannaDiaria;
    }

    public void setFlagCampannaDiaria(String flagCampannaDiaria) {
        this.flagCampannaDiaria = flagCampannaDiaria;
    }
}
