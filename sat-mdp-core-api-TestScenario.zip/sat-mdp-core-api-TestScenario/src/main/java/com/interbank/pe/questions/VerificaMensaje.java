package com.interbank.pe.questions;

import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class VerificaMensaje implements Question<String> {

    public static VerificaMensaje ejecucionConExito (){
        return new VerificaMensaje();
    }
    @Override
    public String answeredBy(Actor actor) {
        return SerenityRest.lastResponse().getBody().asString();
    }
}
