package com.interbank.pe.model.tarjeta.InformacionTC.Response;

import java.util.ArrayList;
import java.util.List;

public class ResponseListaTCAdicional {
    private String items;
    private List<Card> card = new ArrayList<Card>();

    public String getItems() {
        return items;
    }
    public void setItems(String items) {
        this.items = items;
    }
    public List<Card> getCard() {
        return card;
    }
    public void setCard(List<Card> card) {
        this.card = card;
    }
}
