package com.interbank.pe.model.tarjeta.InformacionTC.Response;

public class Card {
    private String number;
    private String truncated;
    private String name;
    private String brandCode;
    private String brand;
    private String typeCode;
    private String type;
    private String participate;
    private String situationCode;
    private String situation;
    private String status;
    private Blocked blocked;
    private String last;
    private String entryDate;
    private String approvedCredit;
    private String currency;
    private Owner owner;
    public String getNumber() {
        return number;
    }
    public void setNumber(String number) {
        this.number = number;
    }
    public String getTruncated() {
        return truncated;
    }
    public void setTruncated(String truncated) {
        this.truncated = truncated;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getBrandCode() {
        return brandCode;
    }
    public void setBrandCode(String brandCode) {
        this.brandCode = brandCode;
    }
    public String getBrand() {
        return brand;
    }
    public void setBrand(String brand) {
        this.brand = brand;
    }
    public String getTypeCode() {
        return typeCode;
    }
    public void setTypeCode(String typeCode) {
        this.typeCode = typeCode;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public String getParticipate() {
        return participate;
    }
    public void setParticipate(String participate) {
        this.participate = participate;
    }
    public String getSituationCode() {
        return situationCode;
    }
    public void setSituationCode(String situationCode) {
        this.situationCode = situationCode;
    }
    public String getSituation() {
        return situation;
    }
    public void setSituation(String situation) {
        this.situation = situation;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public Blocked getBlocked() {
        return blocked;
    }
    public void setBlocked(Blocked blocked) {
        this.blocked = blocked;
    }
    public String getLast() {
        return last;
    }
    public void setLast(String last) {
        this.last = last;
    }
    public String getEntryDate() {
        return entryDate;
    }
    public void setEntryDate(String entryDate) {
        this.entryDate = entryDate;
    }
    public String getApprovedCredit() {
        return approvedCredit;
    }
    public void setApprovedCredit(String approvedCredit) {
        this.approvedCredit = approvedCredit;
    }
    public String getCurrency() {
        return currency;
    }
    public void setCurrency(String currency) {
        this.currency = currency;
    }
    public Owner getOwner() {
        return owner;
    }
    public void setOwner(Owner owner) {
        this.owner = owner;
    }
}

