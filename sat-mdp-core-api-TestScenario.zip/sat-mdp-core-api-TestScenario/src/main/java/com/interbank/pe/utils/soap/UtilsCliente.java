package com.interbank.pe.utils.soap;

import java.util.Objects;

public class UtilsCliente {
    public static String obtenerTipoDocumento(String tipoDocumento) {
        String x = "";
        if ((Objects.equals(tipoDocumento, "1"))) {
            x = "DNI";
        } else if ((Objects.equals(tipoDocumento, "3"))) {
            x = "CE";
        }
        return x;
    }
}
