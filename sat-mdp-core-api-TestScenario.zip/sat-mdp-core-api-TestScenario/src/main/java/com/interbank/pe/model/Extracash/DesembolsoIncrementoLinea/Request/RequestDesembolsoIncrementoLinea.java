package com.interbank.pe.model.Extracash.DesembolsoIncrementoLinea.Request;

public class RequestDesembolsoIncrementoLinea {
    private CommonData commonData;
    private String cardId;
    private String referenceId;
    private String documentType;
    private Double disbursementAmount;
    private Integer payTerm;
    private Double installmentAmount;
    private String minimumTerm;
    private String maximumTerm;
    private Double deferredInterestAmount;
    private Double financedAmount;
    private String firstDueDate;
    private Double insuranceAmount;
    private String insuranceFlag;
    private Double newLineAmount;
    private Integer cellphone;
    private String systemType;

    public CommonData getCommonData() {
        return commonData;
    }

    public void setCommonData(CommonData commonData) {
        this.commonData = commonData;
    }

    public String getCardId() {
        return cardId;
    }

    public void setCardId(String cardId) {
        this.cardId = cardId;
    }

    public String getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(String referenceId) {
        this.referenceId = referenceId;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public Double getDisbursementAmount() {
        return disbursementAmount;
    }

    public void setDisbursementAmount(Double disbursementAmount) {
        this.disbursementAmount = disbursementAmount;
    }

    public Integer getPayTerm() {
        return payTerm;
    }

    public void setPayTerm(Integer payTerm) {
        this.payTerm = payTerm;
    }

    public Double getInstallmentAmount() {
        return installmentAmount;
    }

    public void setInstallmentAmount(Double installmentAmount) {
        this.installmentAmount = installmentAmount;
    }

    public String getMinimumTerm() {
        return minimumTerm;
    }

    public void setMinimumTerm(String minimumTerm) {
        this.minimumTerm = minimumTerm;
    }

    public String getMaximumTerm() {
        return maximumTerm;
    }

    public void setMaximumTerm(String maximumTerm) {
        this.maximumTerm = maximumTerm;
    }

    public Double getDeferredInterestAmount() {
        return deferredInterestAmount;
    }

    public void setDeferredInterestAmount(Double deferredInterestAmount) {
        this.deferredInterestAmount = deferredInterestAmount;
    }

    public Double getFinancedAmount() {
        return financedAmount;
    }

    public void setFinancedAmount(Double financedAmount) {
        this.financedAmount = financedAmount;
    }

    public String getFirstDueDate() {
        return firstDueDate;
    }

    public void setFirstDueDate(String firstDueDate) {
        this.firstDueDate = firstDueDate;
    }

    public Double getInsuranceAmount() {
        return insuranceAmount;
    }

    public void setInsuranceAmount(Double insuranceAmount) {
        this.insuranceAmount = insuranceAmount;
    }

    public String getInsuranceFlag() {
        return insuranceFlag;
    }

    public void setInsuranceFlag(String insuranceFlag) {
        this.insuranceFlag = insuranceFlag;
    }

    public Double getNewLineAmount() {
        return newLineAmount;
    }

    public void setNewLineAmount(Double newLineAmount) {
        this.newLineAmount = newLineAmount;
    }

    public Integer getCellphone() {
        return cellphone;
    }

    public void setCellphone(Integer cellphone) {
        this.cellphone = cellphone;
    }

    public String getSystemType() {
        return systemType;
    }

    public void setSystemType(String systemType) {
        this.systemType = systemType;
    }
}