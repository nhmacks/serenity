package com.interbank.pe.model.cliente.cliente.ResponseCrearCliente;

public class Status {
    private String responseType;
    private String busResponseCode;
    private String busResponseMessage;
    private String srvResponseCode;
    private String srvResponseMessage;
    private String messageIdRes;
    public String getResponseType() {
        return responseType;
    }
    public void setResponseType(String responseType) {
        this.responseType = responseType;
    }
    public String getBusResponseCode() {
        return busResponseCode;
    }
    public void setBusResponseCode(String busResponseCode) {
        this.busResponseCode = busResponseCode;
    }
    public String getBusResponseMessage() {
        return busResponseMessage;
    }
    public void setBusResponseMessage(String busResponseMessage) {
        this.busResponseMessage = busResponseMessage;
    }
    public String getSrvResponseCode() {
        return srvResponseCode;
    }
    public void setSrvResponseCode(String srvResponseCode) {
        this.srvResponseCode = srvResponseCode;
    }
    public String getSrvResponseMessage() {
        return srvResponseMessage;
    }
    public void setSrvResponseMessage(String srvResponseMessage) {
        this.srvResponseMessage = srvResponseMessage;
    }
    public String getMessageIdRes() {
        return messageIdRes;
    }
    public void setMessageIdRes(String messageIdRes) {
        this.messageIdRes = messageIdRes;
    }
}