package com.interbank.pe.model.tarjeta.EstadoCuentaTarjetaCredito;

public class ParallelLineList {
    private String name;
    private String solesAmount;
    private String dollarsAmount;
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getSolesAmount() {
        return solesAmount;
    }
    public void setSolesAmount(String solesAmount) {
        this.solesAmount = solesAmount;
    }
    public String getDollarsAmount() {
        return dollarsAmount;
    }
    public void setDollarsAmount(String dollarsAmount) {
        this.dollarsAmount = dollarsAmount;
    }
}
