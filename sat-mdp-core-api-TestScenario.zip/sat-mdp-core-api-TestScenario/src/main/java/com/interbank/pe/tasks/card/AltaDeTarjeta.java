package com.interbank.pe.tasks.card;


import com.interbank.pe.model.Tarjeta;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Post;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class AltaDeTarjeta implements Task {

    private final String codigoUnico;
    private final String customerName;
    private final String marca;
    private final String tipo;
    private final String condEconomica;
    private final String monedeTC;
    private final String lineaCredito;
    private final String diaPago;

    public AltaDeTarjeta(String codigoUnico, String customerName, String marca, String tipo, String condEconomica, String monedeTC, String lineaCredito, String diaPago) {
        this.codigoUnico = codigoUnico;
        this.customerName = customerName;
        this.marca = marca;
        this.tipo = tipo;
        this.condEconomica = condEconomica;
        this.monedeTC = monedeTC;
        this.lineaCredito = lineaCredito;
        this.diaPago = diaPago;
    }

    public static AltaDeTarjeta DeCredito(String codigoUnico, String customerName, String marca, String tipo, String condEconomica, String monedeTC, String lineaCredito, String diaPago) {
        return instrumented(AltaDeTarjeta.class, codigoUnico, customerName, marca, tipo, condEconomica, monedeTC, lineaCredito, diaPago);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Post.to("ibk/uat/api/credit-card/v1")
                        .with(
                                request ->
                                        request
                                                .relaxedHTTPSValidation()
                                                .header("X-IBM-Client-Id", "9e48c834-31ba-4849-82e3-bada86634d22")
                                                .header("X-INT-User-Id", "XT8116")
                                                .header("X-INT-Consumer-Id", "ASI")
                                                .header("X-INT-Net-Id", "AV")
                                                .header("X-INT-Service-Id", "SRM")
                                                .header("Authorization", "Basic dUJzZUFzaUFBZG06SWJrYWRtMTgr")
                                                .header("Content-Type", "application/json")
                                                .body("{\"processId\": \"1\",\n" +
                                                        "\"customerId\": \"" + codigoUnico + "\",\n" +
                                                        "\"customerType\": \"" + condEconomica + "\",\n" +
                                                        "\"customerName\": \"" + customerName + "\",\n" +
                                                        "\"cardBrand\": \"" + marca + "\",\n" +
                                                        "\"cardType\": \"" + tipo + "\",\n" +
                                                        "\"currencyId\": \"" + monedeTC + "\",\n" +
                                                        "\"creditLine\": \""+lineaCredito+"\",\n" +
                                                        "\"payday\": "+diaPago+",\n" +
                                                        "\"vendorId\": \"X10860\",\n" +
                                                        "\"captureBranchId\": \"100\",\n" +
                                                        "\"managementBranchId\": \"100\",\n" +
                                                        "\"isDoubleCurrency\": false,\n" +
                                                        "\"paymentMethod\": \"03\",\n" +
                                                        "\"validateCustomerId\": true,\n" +
                                                        "\"managementType\": \"0\",\n" +
                                                        "\"hasGuarantee\": false,\n" +
                                                        "\"correspondenseId\": \"PRINCI\",\n" +
                                                        "\"originCampaignId\": \"1-330472831\"}")
                        )
        );
        Tarjeta.setResponseCollection("codUnico", SerenityRest.lastResponse().jsonPath().getJsonObject("customerId"));
        Tarjeta.setResponseCollection("tarjeta", SerenityRest.lastResponse().jsonPath().getJsonObject("cardId"));
        Tarjeta.setResponseCollection("contrato", SerenityRest.lastResponse().jsonPath().getJsonObject("accountHost"));
    }
}
