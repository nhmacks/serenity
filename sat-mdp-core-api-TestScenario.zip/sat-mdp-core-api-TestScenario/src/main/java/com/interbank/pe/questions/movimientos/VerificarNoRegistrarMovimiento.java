package com.interbank.pe.questions.movimientos;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class VerificarNoRegistrarMovimiento implements Question<Boolean> {

    private String message;
    //CONSTRUCTOR
    public VerificarNoRegistrarMovimiento(String menssage) {
        this.message = menssage;
    }

    public static VerificarNoRegistrarMovimiento enCuotas(String menssage){
        return new VerificarNoRegistrarMovimiento(menssage);
    }
    @Override
    public Boolean answeredBy(Actor actor) {
        String cuerpoDeRespuesta = String.valueOf(0);

        return cuerpoDeRespuesta.isEmpty();
    }


}
