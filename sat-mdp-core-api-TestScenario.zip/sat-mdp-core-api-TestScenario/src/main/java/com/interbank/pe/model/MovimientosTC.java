package com.interbank.pe.model;

import java.util.HashMap;

public class MovimientosTC {
    private String flagEnVuelo;
    private String numeroExtracto;
    private String numeroMovimientoExtracto;
    private String monedaMovimiento;
    private String fechaFactura;
    private String horaSIAIDCD;
    private String vueloSIAIDCD;
    private String fechaProceso;
    private String signoImporte;
    private String importeFactura;
    private String codigoComercio;
    private String nombreComercioReducido;
    private String indicadorConversionCuotas;
    private String indicadorExtractoPendiente;
    private String codigoActividad;

    public MovimientosTC(String flagEnVuelo, String numeroExtracto, String numeroMovimientoExtracto, String monedaMovimiento,
                         String fechaFactura, String horaSIAIDCD, String vueloSIAIDCD, String fechaProceso, String signoImporte, String importeFactura,
                         String codigoComercio, String nombreComercioReducido, String indicadorConversionCuotas,
                         String indicadorExtractoPendiente, String codigoActividad) {
        this.flagEnVuelo = flagEnVuelo;
        this.numeroExtracto = numeroExtracto;
        this.numeroMovimientoExtracto = numeroMovimientoExtracto;
        this.monedaMovimiento = monedaMovimiento;
        this.fechaFactura = fechaFactura;
        this.horaSIAIDCD = horaSIAIDCD;
        this.vueloSIAIDCD = vueloSIAIDCD;
        this.fechaProceso = fechaProceso;
        this.signoImporte = signoImporte;
        this.importeFactura = importeFactura;
        this.codigoComercio = codigoComercio;
        this.nombreComercioReducido = nombreComercioReducido;
        this.indicadorConversionCuotas = indicadorConversionCuotas;
        this.indicadorExtractoPendiente = indicadorExtractoPendiente;
        this.codigoActividad = codigoActividad;
    }

    public String getFlagEnVuelo() {
        return flagEnVuelo;
    }

    public String getnumeroExtracto() {
        return numeroExtracto;
    }

    public String getnumeroMovimientoExtracto() {
        return numeroMovimientoExtracto;
    }

    public String getmonedaMovimiento() {
        return monedaMovimiento;
    }

    public String getfechaFactura() {
        return fechaFactura;
    }

    public String gethoraSIAIDCD() {
        return horaSIAIDCD;
    }

    public String getvueloSIAIDCD() {
        return vueloSIAIDCD;
    }

    public String getfechaProceso() {
        return fechaProceso;
    }

    public String getsignoImporte() {
        return signoImporte;
    }

    public String getimporteFactura() {
        return importeFactura;
    }

    public String getcodigoComercio() {
        return codigoComercio;
    }

    public String getnombreComercioReducido() {
        return nombreComercioReducido;
    }

    public String getindicadorConversionCuotas() {
        return indicadorConversionCuotas;
    }

    public String getindicadorExtractoPendiente() {
        return indicadorExtractoPendiente;
    }

    public String getcodigoActividad() {
        return codigoActividad;
    }


    public static HashMap<String, String> responseCollection = new HashMap<String, String>();

    public static String getResponseCollection(String key) {
        return responseCollection.get(key);
    }

    public static void setResponseCollection(String key, String value) {
        responseCollection.put(key, value);
    }
}
