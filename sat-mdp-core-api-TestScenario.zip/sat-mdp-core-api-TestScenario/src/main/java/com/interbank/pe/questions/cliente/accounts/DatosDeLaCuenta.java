package com.interbank.pe.questions.cliente.accounts;

import com.interbank.pe.model.cliente.cuentas.response.ResponseAccount;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class DatosDeLaCuenta implements Question<ResponseAccount> {
    @Override
    public ResponseAccount answeredBy(Actor actor) {
        return SerenityRest.lastResponse().as(ResponseAccount.class);
    }
}
