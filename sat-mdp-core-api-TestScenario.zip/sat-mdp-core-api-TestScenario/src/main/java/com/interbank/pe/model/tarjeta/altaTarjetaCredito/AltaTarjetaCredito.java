package com.interbank.pe.model.tarjeta.altaTarjetaCredito;

public class AltaTarjetaCredito {
    private String processId;
    private String customerId;
    private String customerType;
    private String customerName;
    private String cardBrand;
    private String cardType;
    private String currencyId;
    private String creditLine;
    private Integer payday;
    private String vendorId;
    private String captureBranchId;
    private String managementBranchId;
    private Boolean isDoubleCurrency;
    private String paymentMethod;
    private Boolean validateCustomerId;
    private String managementType;
    private Boolean hasGuarantee;
    private String correspondenseId;
    private String originCampaignId;
    public String getProcessId() {
        return processId;
    }
    public void setProcessId(String processId) {
        this.processId = processId;
    }
    public String getCustomerId() {
        return customerId;
    }
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }
    public String getCustomerType() {
        return customerType;
    }
    public void setCustomerType(String customerType) {
        this.customerType = customerType;
    }
    public String getCustomerName() {
        return customerName;
    }
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }
    public String getCardBrand() {
        return cardBrand;
    }
    public void setCardBrand(String cardBrand) {
        this.cardBrand = cardBrand;
    }
    public String getCardType() {
        return cardType;
    }
    public void setCardType(String cardType) {
        this.cardType = cardType;
    }
    public String getCurrencyId() {
        return currencyId;
    }
    public void setCurrencyId(String currencyId) {
        this.currencyId = currencyId;
    }
    public String getCreditLine() {
        return creditLine;
    }
    public void setCreditLine(String creditLine) {
        this.creditLine = creditLine;
    }
    public Integer getPayday() {
        return payday;
    }
    public void setPayday(Integer payday) {
        this.payday = payday;
    }
    public String getVendorId() {
        return vendorId;
    }
    public void setVendorId(String vendorId) {
        this.vendorId = vendorId;
    }
    public String getCaptureBranchId() {
        return captureBranchId;
    }
    public void setCaptureBranchId(String captureBranchId) {
        this.captureBranchId = captureBranchId;
    }
    public String getManagementBranchId() {
        return managementBranchId;
    }
    public void setManagementBranchId(String managementBranchId) {
        this.managementBranchId = managementBranchId;
    }
    public Boolean getIsDoubleCurrency() {
        return isDoubleCurrency;
    }
    public void setIsDoubleCurrency(Boolean isDoubleCurrency) {
        this.isDoubleCurrency = isDoubleCurrency;
    }
    public String getPaymentMethod() {
        return paymentMethod;
    }
    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }
    public Boolean getValidateCustomerId() {
        return validateCustomerId;
    }
    public void setValidateCustomerId(Boolean validateCustomerId) {
        this.validateCustomerId = validateCustomerId;
    }
    public String getManagementType() {
        return managementType;
    }
    public void setManagementType(String managementType) {
        this.managementType = managementType;
    }
    public Boolean getHasGuarantee() {
        return hasGuarantee;
    }
    public void setHasGuarantee(Boolean hasGuarantee) {
        this.hasGuarantee = hasGuarantee;
    }
    public String getCorrespondenseId() {
        return correspondenseId;
    }
    public void setCorrespondenseId(String correspondenseId) {
        this.correspondenseId = correspondenseId;
    }
    public String getOriginCampaignId() {
        return originCampaignId;
    }
    public void setOriginCampaignId(String originCampaignId) {
        this.originCampaignId = originCampaignId;
    }
}