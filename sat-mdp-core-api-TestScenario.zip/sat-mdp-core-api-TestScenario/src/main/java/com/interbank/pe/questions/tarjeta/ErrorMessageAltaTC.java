package com.interbank.pe.questions.tarjeta;

import com.interbank.pe.model.tarjeta.altaTarjetaCredito.ResponseErrorMessageAltaTC;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class ErrorMessageAltaTC implements Question {

    @Override
    public ResponseErrorMessageAltaTC answeredBy(Actor actor) {
        return SerenityRest.lastResponse().as(ResponseErrorMessageAltaTC.class);
    }
}
