package com.interbank.pe.utils.enums.campanna;

public enum EnumCampannaExtracash {
    CODIGO_CAMPANNA("1-305750771"),
    TIENDA_SECTORIZADA("100"),
    CODIGO_TRATAMIENTO("1-305750805"),
    VALOR_01("Aprobado"),
    TIPO_OFERTA("11"),
    ID_MONEDA("01"),
    TASA1("26.68"),
    TASA2("26.68"),
    CEM("1100"),
    PLAZO_MAXIMO("48"),
    MERCHANDISING("190911000001"),
    CAMPO_LIBRE_1("52"),
    CAMPO_LIBRE_3("0"),
    CAMPO_LIBRE_4("0"),
    CAMPO_LIBRE_5("0"),
    RENTA("1100"),
    FLUJO_INGRESO("101"),
    FLAG_REGISTRO("N"),
    SIMBOLO_MONEDA("S/."),
    DESCRIPCION_MONEDA("Soles"),
    PRIORIDAD_CANAL_PRESENCIAL("1"),
    PRIORIDAD_CANAL("ASI=1"),
    SEGMENTO_CP("1A"),
    FLAG_AM("N");
    private final String valor;

    EnumCampannaExtracash(String valor) {
        this.valor = valor;
    }

    public String getValor() {
        return valor;
    }
}
