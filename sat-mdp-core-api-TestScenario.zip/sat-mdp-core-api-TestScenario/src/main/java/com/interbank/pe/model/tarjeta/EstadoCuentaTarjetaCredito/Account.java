package com.interbank.pe.model.tarjeta.EstadoCuentaTarjetaCredito;
public class Account {
    private String contractNumber;
    private String status;
    private String currencyCode;
    private String isDoubleCurrency;
    public String getContractNumber() {
        return contractNumber;
    }
    public void setContractNumber(String contractNumber) {
        this.contractNumber = contractNumber;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getCurrencyCode() {
        return currencyCode;
    }
    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }
    public String getIsDoubleCurrency() {
        return isDoubleCurrency;
    }
    public void setIsDoubleCurrency(String isDoubleCurrency) {
        this.isDoubleCurrency = isDoubleCurrency;
    }
}