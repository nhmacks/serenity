package com.interbank.pe.model.CompraDeDeuda.DesembolsoCompraDeuda.Response;

public class ResponseAltaCompraDeuda {
    private String authorizationNumber;
    private String maximumAmount;

    public String getAuthorizationNumber() {
        return authorizationNumber;
    }

    public void setAuthorizationNumber(String authorizationNumber) {
        this.authorizationNumber = authorizationNumber;
    }

    public String getMaximumAmount() {
        return maximumAmount;
    }

    public void setMaximumAmount(String maximumAmount) {
        this.maximumAmount = maximumAmount;
    }
}
