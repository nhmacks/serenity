package com.interbank.pe.utils.soap;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Random;

public class UtilsCampanna {
    public static String tasaExtracash() {
        String[] opciones = {"01", "02", "03"};
        Random rand = new Random();
        int index = rand.nextInt(opciones.length);
        return opciones[index];
    }

    public static String nroMesesDiferidos() {
        String[] opciones = {"00","01", "02", "03"};
        Random rand = new Random();
        int index = rand.nextInt(opciones.length);
        return opciones[index];
    }

    public static String aleatorioDisponibleConsumo(){
        String[] opciones = {"10000","09000", "08000", "07000","06000","05000","04000","03000","02000","01000","00000"};
        Random rand = new Random();
        int index = rand.nextInt(opciones.length);
        return opciones[index];
    }
    public static String verdad() {
        String[] opciones = {"S","N"};
        Random rand = new Random();
        int index = rand.nextInt(opciones.length);
        return opciones[index];
    }

    public static String ultimoDiaMesformatddMMyy() {
        Calendar calendario = Calendar.getInstance();
        int ultimoDiaDelMes = calendario.getActualMaximum(Calendar.DAY_OF_MONTH);
        int mesActual = calendario.get(Calendar.MONTH) + 1;
        int anioActual = calendario.get(Calendar.YEAR);
        return String.format("%02d%02d%02d", ultimoDiaDelMes, mesActual, anioActual % 100);
    }

    public static String fechaActual() {
        LocalDate fechaActual = LocalDate.now();
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        return fechaActual.format(formato);
    }

    public static String espacios(int cantidadEspacios) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < cantidadEspacios; i++) {
            sb.append(" ");
        }
        return sb.toString();
    }

}
