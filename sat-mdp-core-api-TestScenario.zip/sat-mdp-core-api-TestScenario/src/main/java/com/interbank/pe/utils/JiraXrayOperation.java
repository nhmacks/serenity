package com.interbank.pe.utils;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import net.serenitybdd.core.environment.EnvironmentSpecificConfiguration;
import net.thucydides.core.util.EnvironmentVariables;
import net.thucydides.core.environment.SystemEnvironmentVariables;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public class JiraXrayOperation {

    private static final String API_XRAY_AUTHENTICATE = "https://xray.cloud.getxray.app/api/v1/authenticate";
    private static final String API_XRAY_IMPORT_CUCUMBER_RESULT = "https://xray.cloud.getxray.app/api/v2/import/execution/cucumber";

    private static final EnvironmentVariables envs = SystemEnvironmentVariables.createEnvironmentVariables();

    public static void importCucumberResult(String cucumberJsonFile) {

        String jsonContent = getCucumberJsonContentAsString(cucumberJsonFile);

        String authenticateToken = getAuthenticateToken();

        RestAssured.useRelaxedHTTPSValidation();
        Response response = RestAssured.given()
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + authenticateToken)
                .body(jsonContent)
                .when().log().all()
                .post(API_XRAY_IMPORT_CUCUMBER_RESULT);
        response.prettyPeek();
        response.then().assertThat().statusCode(200);
    }

    private static String getAuthenticateToken() {

        String clientId =  EnvironmentSpecificConfiguration.from(envs)
                .getProperty("environments.jira.xray.client-id");
        String secretId =  EnvironmentSpecificConfiguration.from(envs)
                .getProperty("environments.jira.xray.client-secret");

        String authenticateBody = "{\n" +
                "  \"client_id\": \""+clientId+"\",\n" +
                "  \"client_secret\": \""+secretId+"\"\n" +
                "}";

        Response response = RestAssured.given()
                .header("Content-Type", "application/json")
                .body(authenticateBody)
                .when().log().all()
                .post(API_XRAY_AUTHENTICATE);
        response.prettyPeek();
        response.then().assertThat().statusCode(200);
        return response.asString().replace("\"", "");
    }

    private static String getCucumberJsonContentAsString(String cucumberJsonFile) {
        Path cucumberPath = Path.of(System.getProperty("user.dir") + cucumberJsonFile);
        try {
            return Files.readString(cucumberPath, StandardCharsets.UTF_8);
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Something went wrong");
        }
    }
}