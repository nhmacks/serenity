package com.interbank.pe.model.cliente.cuentas.request;

import java.util.ArrayList;
import java.util.List;

public class Customer {
    private String id;
    private IdentityDocument identityDocument;
    private List<Email> email = new ArrayList<Email>();
    private List<Phone> phone = new ArrayList<Phone>();
    private Boolean titular;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public IdentityDocument getIdentityDocument() {
        return identityDocument;
    }

    public void setIdentityDocument(IdentityDocument identityDocument) {
        this.identityDocument = identityDocument;
    }

    public List<Email> getEmail() {
        return email;
    }

    public void setEmail(List<Email> email) {
        this.email = email;
    }

    public List<Phone> getPhone() {
        return phone;
    }

    public void setPhone(List<Phone> phone) {
        this.phone = phone;
    }

    public Boolean getTitular() {
        return titular;
    }

    public void setTitular(Boolean titular) {
        this.titular = titular;
    }
}