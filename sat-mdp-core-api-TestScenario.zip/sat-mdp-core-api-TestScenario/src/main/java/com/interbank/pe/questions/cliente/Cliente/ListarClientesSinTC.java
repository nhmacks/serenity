package com.interbank.pe.questions.cliente.Cliente;

import com.interbank.pe.model.cliente.cliente.RequestCrearCliente.Clientes;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import static com.interbank.pe.utils.soap.EnumRequestSoap.CLIENTE;
import static com.interbank.pe.utils.soap.UtilsTarjeta.existsValue;

public class ListarClientesSinTC implements Question {

    @Override
    public List<Clientes> answeredBy(Actor actor) {
        String filePath = CLIENTE.getPathArchivo();
        String line = "";
        String cvsSplitBy = ",";
        LocalTime horaPrimerBatch = LocalTime.of(13, 0);
        LocalTime horaSegundoBath = LocalTime.of(17,0);
        List<Clientes> clientesList = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            while ((line = br.readLine()) != null) {
                String[] data = line.split(cvsSplitBy);
                if (Objects.isNull((existsValue(data, 9) ? data[9] : "")) || Objects.equals(existsValue(data, 9) ? data[9] : "", "")&(data.length>=7)) {
                    Clientes clientes = new Clientes(
                            existsValue(data, 0) ? data[0] : "",
                            existsValue(data, 1) ? data[1] : "",
                            existsValue(data, 2) ? data[2] : "",
                            existsValue(data, 3) ? data[3] : "",
                            existsValue(data, 4) ? data[4] : "",
                            existsValue(data, 5) ? data[5] : "",
                            existsValue(data, 6) ? data[6] : "",
                            existsValue(data, 7) ? data[7] : "",
                            existsValue(data, 8) ? data[8] : "",
                            existsValue(data, 9) ? data[9] : "",
                            existsValue(data, 10) ? data[10] : "",
                            existsValue(data, 11) ? data[11] : ""
                            );

                    String cadenaFechaCreacionCodCliente = clientes.getFechaCreacionCodClient();
                    LocalDateTime fechaHora = LocalDateTime.parse(cadenaFechaCreacionCodCliente);
                    LocalTime horaCreacionCliente = LocalTime.of(fechaHora.getHour(), fechaHora.getMinute());
                    LocalDateTime fechaHoraHoy = LocalDateTime.now();
                    LocalTime horaHoy = LocalTime.of(fechaHoraHoy.getHour(), fechaHoraHoy.getMinute());

                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    Date fechaCreacionCliente = dateFormat.parse(cadenaFechaCreacionCodCliente);

                    LocalDateTime dateTime = LocalDateTime.now();
                    Date fechaActual = dateFormat.parse(dateTime.toString());
                    if (fechaCreacionCliente.equals(fechaActual)){
                        if (horaCreacionCliente.isBefore(horaPrimerBatch) && horaHoy.isAfter(horaPrimerBatch)) {

                            clientesList.add(clientes);
                        } else if (horaCreacionCliente.isBefore(horaSegundoBath) && horaHoy.isAfter(horaSegundoBath)) {

                            clientesList.add(clientes);
                        }
                    }else {
                            clientesList.add(clientes);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        return clientesList;
    }


}
