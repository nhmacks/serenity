package com.interbank.pe.model.Transaccion.TransaccionCuotas;

import java.util.ArrayList;
import java.util.List;

public class TransaccionCuotas {
    private String rowsNumber;
    private String currency;
    private String operationFigPag;
    private String operationEndDate;
    private String continueFlag;
    private String beneficiaryType;
    private String accountHost;
    private String office;
    private String identityId;
    private String cardId;
    private List<Installment> installments = new ArrayList<Installment>();
    public String getRowsNumber() {
        return rowsNumber;
    }
    public void setRowsNumber(String rowsNumber) {
        this.rowsNumber = rowsNumber;
    }
    public String getCurrency() {
        return currency;
    }
    public void setCurrency(String currency) {
        this.currency = currency;
    }
    public String getOperationFigPag() {
        return operationFigPag;
    }
    public void setOperationFigPag(String operationFigPag) {
        this.operationFigPag = operationFigPag;
    }
    public String getOperationEndDate() {
        return operationEndDate;
    }
    public void setOperationEndDate(String operationEndDate) {
        this.operationEndDate = operationEndDate;
    }
    public String getContinueFlag() {
        return continueFlag;
    }
    public void setContinueFlag(String continueFlag) {
        this.continueFlag = continueFlag;
    }
    public String getBeneficiaryType() {
        return beneficiaryType;
    }
    public void setBeneficiaryType(String beneficiaryType) {
        this.beneficiaryType = beneficiaryType;
    }
    public String getAccountHost() {
        return accountHost;
    }
    public void setAccountHost(String accountHost) {
        this.accountHost = accountHost;
    }
    public String getOffice() {
        return office;
    }
    public void setOffice(String office) {
        this.office = office;
    }
    public String getIdentityId() {
        return identityId;
    }
    public void setIdentityId(String identityId) {
        this.identityId = identityId;
    }
    public String getCardId() {
        return cardId;
    }
    public void setCardId(String cardId) {
        this.cardId = cardId;
    }
    public List<Installment> getInstallments() {
        return installments;
    }
    public void setInstallments(List<Installment> installments) {
        this.installments = installments;
    }
}