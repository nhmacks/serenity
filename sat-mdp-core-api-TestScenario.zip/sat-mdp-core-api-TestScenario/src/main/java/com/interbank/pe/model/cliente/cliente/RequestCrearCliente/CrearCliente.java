package com.interbank.pe.model.cliente.cliente.RequestCrearCliente;

public class CrearCliente {
    private String tipoDocumento;
    private String numeroDocumento;
    private Object numeroPasaporte;
    private String fechaNacimiento;
    private String apellidoPaterno;
    private String apellidoMaterno;
    private String primerNombre;
    private String segundoNombre;
    private String sexo;
    private String estadoCivil;
    private String tipoNacionalidad;
    private String codigoPaisNacimiento;
    private String codigoPaisResidencia;
    private String codigoPaisNacionalidad;
    private String tipoVia;
    private String nombreVia;
    private String numeroCalle;
    private String idManzana;
    private String idLote;
    private String idInterior;
    private String nombreUrbanizacion;
    private String referenciaUbicacion;
    private String departamento;
    private String provincia;
    private String distrito;
    private ListaTelefonos listaTelefonos;
    private String tipoEmail;
    private String email;
    private Object codigoCIIU;
    private Object nombreEmpresa;
    private Object codigoOcupacion;
    public String getTipoDocumento() {
        return tipoDocumento;
    }
    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }
    public String getNumeroDocumento() {
        return numeroDocumento;
    }
    public void setNumeroDocumento(String numeroDocumento) {
        this.numeroDocumento = numeroDocumento;
    }
    public Object getNumeroPasaporte() {
        return numeroPasaporte;
    }
    public void setNumeroPasaporte(Object numeroPasaporte) {
        this.numeroPasaporte = numeroPasaporte;
    }
    public String getFechaNacimiento() {
        return fechaNacimiento;
    }
    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }
    public String getApellidoPaterno() {
        return apellidoPaterno;
    }
    public void setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }
    public String getApellidoMaterno() {
        return apellidoMaterno;
    }
    public void setApellidoMaterno(String apellidoMaterno) {
        this.apellidoMaterno = apellidoMaterno;
    }
    public String getPrimerNombre() {
        return primerNombre;
    }
    public void setPrimerNombre(String primerNombre) {
        this.primerNombre = primerNombre;
    }
    public String getSegundoNombre() {
        return segundoNombre;
    }
    public void setSegundoNombre(String segundoNombre) {
        this.segundoNombre = segundoNombre;
    }
    public String getSexo() {
        return sexo;
    }
    public void setSexo(String sexo) {
        this.sexo = sexo;
    }
    public String getEstadoCivil() {
        return estadoCivil;
    }
    public void setEstadoCivil(String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }
    public String getTipoNacionalidad() {
        return tipoNacionalidad;
    }
    public void setTipoNacionalidad(String tipoNacionalidad) {
        this.tipoNacionalidad = tipoNacionalidad;
    }
    public String getCodigoPaisNacimiento() {
        return codigoPaisNacimiento;
    }
    public void setCodigoPaisNacimiento(String codigoPaisNacimiento) {
        this.codigoPaisNacimiento = codigoPaisNacimiento;
    }
    public String getCodigoPaisResidencia() {
        return codigoPaisResidencia;
    }
    public void setCodigoPaisResidencia(String codigoPaisResidencia) {
        this.codigoPaisResidencia = codigoPaisResidencia;
    }
    public String getCodigoPaisNacionalidad() {
        return codigoPaisNacionalidad;
    }
    public void setCodigoPaisNacionalidad(String codigoPaisNacionalidad) {
        this.codigoPaisNacionalidad = codigoPaisNacionalidad;
    }
    public String getTipoVia() {
        return tipoVia;
    }
    public void setTipoVia(String tipoVia) {
        this.tipoVia = tipoVia;
    }
    public String getNombreVia() {
        return nombreVia;
    }
    public void setNombreVia(String nombreVia) {
        this.nombreVia = nombreVia;
    }
    public String getNumeroCalle() {
        return numeroCalle;
    }
    public void setNumeroCalle(String numeroCalle) {
        this.numeroCalle = numeroCalle;
    }
    public String getIdManzana() {
        return idManzana;
    }
    public void setIdManzana(String idManzana) {
        this.idManzana = idManzana;
    }
    public String getIdLote() {
        return idLote;
    }
    public void setIdLote(String idLote) {
        this.idLote = idLote;
    }
    public String getIdInterior() {
        return idInterior;
    }
    public void setIdInterior(String idInterior) {
        this.idInterior = idInterior;
    }
    public String getNombreUrbanizacion() {
        return nombreUrbanizacion;
    }
    public void setNombreUrbanizacion(String nombreUrbanizacion) {
        this.nombreUrbanizacion = nombreUrbanizacion;
    }
    public String getReferenciaUbicacion() {
        return referenciaUbicacion;
    }
    public void setReferenciaUbicacion(String referenciaUbicacion) {
        this.referenciaUbicacion = referenciaUbicacion;
    }
    public String getDepartamento() {
        return departamento;
    }
    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }
    public String getProvincia() {
        return provincia;
    }
    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }
    public String getDistrito() {
        return distrito;
    }
    public void setDistrito(String distrito) {
        this.distrito = distrito;
    }
    public ListaTelefonos getListaTelefonos() {
        return listaTelefonos;
    }
    public void setListaTelefonos(ListaTelefonos listaTelefonos) {
        this.listaTelefonos = listaTelefonos;
    }
    public String getTipoEmail() {
        return tipoEmail;
    }
    public void setTipoEmail(String tipoEmail) {
        this.tipoEmail = tipoEmail;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public Object getCodigoCIIU() {
        return codigoCIIU;
    }
    public void setCodigoCIIU(Object codigoCIIU) {
        this.codigoCIIU = codigoCIIU;
    }
    public Object getNombreEmpresa() {
        return nombreEmpresa;
    }
    public void setNombreEmpresa(Object nombreEmpresa) {
        this.nombreEmpresa = nombreEmpresa;
    }
    public Object getCodigoOcupacion() {
        return codigoOcupacion;
    }
    public void setCodigoOcupacion(Object codigoOcupacion) {
        this.codigoOcupacion = codigoOcupacion;
    }
}