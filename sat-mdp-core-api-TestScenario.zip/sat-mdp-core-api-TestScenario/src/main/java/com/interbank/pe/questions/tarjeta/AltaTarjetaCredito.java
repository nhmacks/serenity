package com.interbank.pe.questions.tarjeta;

import com.interbank.pe.model.tarjeta.altaTarjetaCredito.RespuestaAltaTarjetaCredito;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class AltaTarjetaCredito implements Question {

    @Override
    public RespuestaAltaTarjetaCredito answeredBy(Actor actor) {
        return SerenityRest.lastResponse().as(RespuestaAltaTarjetaCredito.class);
    }
}
