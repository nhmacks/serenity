package com.interbank.pe.questions.tarjeta;

import com.interbank.pe.model.tarjeta.ListaTarjetasDisponible;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.interbank.pe.utils.soap.EnumRequestSoap.DATA_TARJETA_DISPONIBLE;
import static com.interbank.pe.utils.soap.UtilsTarjeta.existsValue;

public class ListarTarjetasDisponiblesParaPruebas implements Question {

    @Override
    public List<ListaTarjetasDisponible> answeredBy(Actor actor) {
        String filePath = DATA_TARJETA_DISPONIBLE.getPathArchivo();
        String line = "";
        String cvsSplitBy = ",";
        List<ListaTarjetasDisponible> tarjeta = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            int contador = 0;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(cvsSplitBy);
                if (data.length >= 1 & contador > 0) {
                    ListaTarjetasDisponible tarjeta1 = new ListaTarjetasDisponible(
                            existsValue(data, 0) ? data[0] : "",
                            existsValue(data, 1) ? data[1] : ""
                    );
                    tarjeta.add(tarjeta1);
                }
                contador++;
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return tarjeta;
    }
}

