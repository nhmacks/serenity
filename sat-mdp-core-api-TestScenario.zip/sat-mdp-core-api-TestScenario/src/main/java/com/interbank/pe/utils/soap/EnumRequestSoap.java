package com.interbank.pe.utils.soap;

public enum EnumRequestSoap {
    REALIZAR_CONSUMO("src\\test\\resources\\data\\services\\realizaConsumo.xml"),
    CORECSALEASING("src\\test\\resources\\data\\services\\CORECSALEASING.xml"),
    DonacionTomas("src\\test\\resources\\data\\services\\DonacionTomas.xml"),
    DonacionFeyAlegria("src\\test\\resources\\data\\services\\DonacionFeyAlegria.xml"),
    CONSULTAR_MOVIMIENTO("src\\test\\resources\\data\\services\\consultarMovimientos.xml"),
    DISPOSICION_EFECTIVO("src\\test\\resources\\data\\services\\requestDisposicionEfectivo.xml"),
    PASARELLA_ABONAR("src\\test\\resources\\data\\services\\PasarellaAbonar.xml"),
    PREMIA("src\\test\\resources\\data\\services\\PremiaAbonar.xml"),
    GIRU("src\\test\\resources\\data\\services\\GiruAbonar.xml"),
    APP_ABONAR("src\\test\\resources\\data\\services\\AbonoAPP.xml"),
    CLIENTE("D:\\DATA\\cliente.csv"),
    CLIENTE_TARJETA("D:\\DATA\\clienteTarjeta.csv"),
    DATA_TARJETA_DISPONIBLE("D:\\DATA\\DataTarjetaUtilizada.csv"),
    DATA_DISPOSCIONEFECTIVO("D:\\DATA\\DataDispEfectivo.csv"),
    CLIENTE_CUENTA_AHORRO("D:\\DATA\\clienteCuentaAhorro.csv"),
    CAMPANNA_EXTRACASH_TC_TXT("D:\\DATA\\campannaExtracash\\"),
    //CAMPANNA_EXTRACASH_TC_TXT("\\\\grupoib.local\\dfs3\\CrmUat-Carga\\SBL\\Campanna\\Lead\\"),
    CAMPANNA_EXTRACASH_TC_CSV("D:\\DATA\\campannaExtracash\\SBL_CAMPANNA.csv"),
    CAMPANNA_DIARIA_TC_TXT("D:\\DATA\\campannaExtracash\\APCLIN_EXT.txt"),
    //CAMPANNA_DIARIA_TC_TXT("\\\\grupoib.local\\nas\\HostPcUat\\CdqSend\\APCLIN_EXT.txt"),
    CAMPANNA_DIARIA_TC_CSV("D:\\DATA\\campannaExtracash\\APCLIN_EXT.csv"),
    CREAR_CLIENTE("src\\test\\resources\\data\\MPO\\CRM\\crearCliente.json"),
    ACTIVAR_TARJETA("src\\test\\resources\\data\\card\\activarTarjeta.xml"),
    LOGIN_TARJETA("src\\test\\resources\\data\\Login\\Login.xml"),
    CUENTA_AHORRO("D:\\DATA\\clienteCuentaAhorro.csv"),
    COD_CAMPANNA("D:\\DATA\\codCampanna.csv");


    private final String pathArchivo;

    EnumRequestSoap(String pathArchivo) {
        this.pathArchivo = pathArchivo;
    }

    public String getPathArchivo() {
        return pathArchivo;
    }
}
