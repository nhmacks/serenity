package com.interbank.pe.model.cliente.cliente.ResponseCrearCliente;

public class ResponseCliente {
    private MessageResponse messageResponse;
    public MessageResponse getMessageResponse() {
        return messageResponse;
    }
    public void setMessageResponse(MessageResponse messageResponse) {
        this.messageResponse = messageResponse;
    }
}