package com.interbank.pe.tasks.Login;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Post;

import java.io.IOException;

import static com.interbank.pe.utils.soap.EnumRequestSoap.LOGIN_TARJETA;
import static com.interbank.pe.utils.soap.UtilisSoap.obtenerRequestSoap;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class LoginTC implements Task {

    private final String tarjeta;
    private final String cu;
    private final String clave;


    public LoginTC(String tarjeta, String cu, String clave) {
        this.tarjeta = tarjeta;
        this.cu = cu;
        this.clave = clave;

    }

    public static LoginTC now(String tarjeta, String cu, String clave) {
        return instrumented(LoginTC.class, tarjeta, cu, clave);
    }

    @Override
    public <T extends Actor> void performAs(T theActor) {
        theActor.attemptsTo(
                Post.to("ib/bus/srv/soap/excelsys.enviarOperacionAPP")
                        .with(
                                request ->
                                        request
                                                .relaxedHTTPSValidation()
                                                .header("SOAPAction", "http://interbank.com.pe/bus/service/interface/excelsys/enviarOperacionBPI/v1.0/")
                                                .header("Content-Type", "text/plain")
                                                .header("Content-Type", "text/xml; charset=ISO-8859-1")
                                                .body(ObtenerRequestLoginTC())
                        )
        );
    }

    private String ObtenerRequestLoginTC() {
        try {
            return obtenerRequestSoap(LOGIN_TARJETA.getPathArchivo())
                    .replace("NUMTARJETA", tarjeta)
                    .replace("CU_TC", cu)
                    .replace("CLAVE_TC",Clave(clave));

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private String Clave(String Clave) {
        if (Clave.equals("A11111")) {
            return "EE6CF9FF1B450D57F9E749E3602892C11683F09544C76B1E0E8A433C4CC28CA81C0958901969AED0";
        } else if (Clave.equals("A111111")) {
            return "56AE41F8A2CAF13D43055F5DDF7C7DD1B047F6D66A60D4ACB39B4A1554594C111FD67AB6FFFC7D61";
        }
        return Clave;
    }
}
