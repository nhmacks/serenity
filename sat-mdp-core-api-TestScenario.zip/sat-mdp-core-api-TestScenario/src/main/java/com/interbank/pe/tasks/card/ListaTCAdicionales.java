package com.interbank.pe.tasks.card;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Get;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class ListaTCAdicionales implements Task {

    private final String codigoUnico;

    public ListaTCAdicionales(String codigoUnico) {
        this.codigoUnico = codigoUnico;
    }
public static ListaTCAdicionales delCliente (String codigoUnico) {

        return instrumented (ListaTCAdicionales.class,codigoUnico);
}

    @Override
    public <T extends Actor> void performAs(T Actor) {

Actor.attemptsTo(
        Get.resource("ibk/uat/api/credit-card/v4/"+codigoUnico+"/additional-cards")
                .with(requestSpecification -> requestSpecification
                        .relaxedHTTPSValidation()
                        .header("accept","application/json")
                        .header("x-ibm-client-id", "a668bb85-8159-4b03-bed6-a8a46380cc78")
                        .header("X-INT-CardId-Type", "1")
                        .header("X-INT-Net-Id", "TD")
                        .header("X-INT-Service-Id","SAT")
                        .header("X-INT-User-Id", "APPA0001")
                        .header("Authorization", "Basic dUJzZUZ0aUFDb246dUJjRlRJQTE5"))
);


    }
}
