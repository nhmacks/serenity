package com.interbank.pe.tasks.compraDeuda;

import io.restassured.mapper.ObjectMapperType;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Post;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class OfertaAjustadaCompraDeuda implements Task {

    private final Object request;
    private final String cardIdType;

    public OfertaAjustadaCompraDeuda(Object request, String cardIdType) {
        this.request = request;
        this.cardIdType = cardIdType;
    }

    public static OfertaAjustadaCompraDeuda deCliente(Object request, String cardIdType) {
        return instrumented(OfertaAjustadaCompraDeuda.class, request, cardIdType);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Post.to("ibk/uat/api/debt-purchase/v1/adjusted-offer")
                        .with(
                                requestSpecification ->
                                        requestSpecification
                                                .relaxedHTTPSValidation()
                                                .header("Accept", "application/json")
                                                .header("Content-Type", "application/json; charset=UTF-8")
                                                .header("X-IBM-Client-Id", "9e48c834-31ba-4849-82e3-bada86634d22")
                                                .header("X-INT-ChannelCode", "")
                                                .header("X-INT-Branch-Id", "100")
                                                .header("X-INT-Consumer-Id", "ASI")
                                                .header("X-INT-Device-Id", "13.10.13.1")
                                                .header("X-INT-Message-Id", "1234567890")
                                                .header("X-INT-Module-Id", "")
                                                .header("X-INT-Net-Id", "BI")
                                                .header("X-INT-Server-Id", "SERVER01")
                                                .header("X-INT-Service-Id", "SAT")
                                                .header("X-INT-Timestamp", "2022-07-22T10:02:48")
                                                .header("X-INT-User-Id", "XT8643")
                                                .header("X-INT-Supervisor-Id", "X1085730")
                                                .header("APIm-debug", "true")
                                                .header("X-INT-CardId-Type", cardIdType)
                                                .header("Authorization", "Basic dUJzZUFzaUFBZG06SWJrYWRtMTgr")
                                                .body(request, ObjectMapperType.GSON)
                        )
        );
    }
}
