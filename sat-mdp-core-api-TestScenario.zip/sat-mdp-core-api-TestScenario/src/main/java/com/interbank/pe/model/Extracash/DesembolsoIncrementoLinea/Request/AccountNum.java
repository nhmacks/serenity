package com.interbank.pe.model.Extracash.DesembolsoIncrementoLinea.Request;

public class AccountNum {
    private String branchId;
    private String accountHost;
    public String getBranchId() {
        return branchId;
    }
    public void setBranchId(String branchId) {
        this.branchId = branchId;
    }
    public String getAccountHost() {
        return accountHost;
    }
    public void setAccountHost(String accountHost) {
        this.accountHost = accountHost;
    }
}
