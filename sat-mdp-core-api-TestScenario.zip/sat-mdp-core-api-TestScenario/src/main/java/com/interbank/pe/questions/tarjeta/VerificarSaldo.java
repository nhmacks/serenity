package com.interbank.pe.questions.tarjeta;

import com.interbank.pe.model.Tarjeta;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

import java.text.DecimalFormat;

public class VerificarSaldo implements Question<Boolean> {
    private double saldoEsperado;
    private double saldoActual;

    private VerificarSaldo() {
    }

    public static VerificarSaldo deTarjeta() {
        return new VerificarSaldo();
    }

    @Override
    public Boolean answeredBy(Actor actor) {
        saldoActual = Double.parseDouble(Tarjeta.getResponseCollection("used")) - Double.parseDouble(Tarjeta.getResponseCollection("antesUsed"));
        saldoEsperado = Double.parseDouble(Tarjeta.getResponseCollection("antesAvailable")) - Double.parseDouble(Tarjeta.getResponseCollection("available"));

        DecimalFormat format = new DecimalFormat("#.00");
        saldoActual = Double.parseDouble(format.format(saldoActual));
        saldoEsperado= Double.parseDouble(format.format(saldoEsperado));

        System.out.println("SALDO ACTUAL:   " + saldoActual);
        System.out.println("SALDO ESPERADO: " + saldoEsperado);
        if (saldoActual==saldoEsperado){
            System.out.println("Saldo disponible actualizado correctamente.");
            return true;
        }else {
            System.out.println("El saldo disponible no se ha visto afectado.");
            return false;
        }
    }


}
