package com.interbank.pe.model.cliente.cliente.RequestCrearCliente;
public class Telefono {
    private String tipoTelefono;
    private String telediscado;
    private String numeroTelefono;
    public String getTipoTelefono() {
        return tipoTelefono;
    }
    public void setTipoTelefono(String tipoTelefono) {
        this.tipoTelefono = tipoTelefono;
    }
    public String getTelediscado() {
        return telediscado;
    }
    public void setTelediscado(String telediscado) {
        this.telediscado = telediscado;
    }
    public String getNumeroTelefono() {
        return numeroTelefono;
    }
    public void setNumeroTelefono(String numeroTelefono) {
        this.numeroTelefono = numeroTelefono;
    }
}