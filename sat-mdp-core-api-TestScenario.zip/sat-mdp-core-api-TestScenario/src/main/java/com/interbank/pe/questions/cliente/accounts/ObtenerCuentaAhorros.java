package com.interbank.pe.questions.cliente.accounts;

import com.interbank.pe.model.cliente.cuentas.CuentaAhorros;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

import java.util.List;
import java.util.Objects;

import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;

public class ObtenerCuentaAhorros implements Question<CuentaAhorros> {
    String codCliente;
    String moneda;
    String productoCuenta;
    String tipoCuenta;
    String individual;
    String numCuentaAhorro;
    String codCuentaInterbancaria;
    String flagCuenta;
    String fechaCreacion;

    public ObtenerCuentaAhorros(String codCliente) {
        this.codCliente = codCliente;
    }

    @Override
    public CuentaAhorros answeredBy(Actor actor) {
        List<CuentaAhorros> cuentaAhorrosList = new ListarCuentasAhorro().answeredBy(actor);
        for (CuentaAhorros cuentaAhorros : cuentaAhorrosList) {
            if ((Objects.equals(cuentaAhorros.getCodCliente(), this.codCliente))) {
                this.codCliente = cuentaAhorros.getCodCliente();
                this.moneda = cuentaAhorros.getMoneda();
                this.productoCuenta = cuentaAhorros.getProductoCuenta();
                this.tipoCuenta = cuentaAhorros.getTipoCuenta();
                this.individual = cuentaAhorros.getIndividual();
                this.numCuentaAhorro = cuentaAhorros.getNumCuentaAhorro();
                this.codCuentaInterbancaria = cuentaAhorros.getCodCuentaInterbancaria();
                this.flagCuenta = cuentaAhorros.getFlagCuenta();
                this.fechaCreacion = cuentaAhorros.getFechaCreacion();
                break;
            }
        }
        return new
                CuentaAhorros(codCliente, moneda, productoCuenta, tipoCuenta, individual, numCuentaAhorro, codCuentaInterbancaria, flagCuenta, fechaCreacion);
    }

}
