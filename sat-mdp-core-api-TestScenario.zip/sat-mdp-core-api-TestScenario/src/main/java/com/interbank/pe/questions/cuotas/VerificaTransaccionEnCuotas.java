package com.interbank.pe.questions.cuotas;

import com.interbank.pe.model.cuotas.TransactionInstallment;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class VerificaTransaccionEnCuotas implements Question {

    @Override
    public TransactionInstallment answeredBy(Actor actor) {
        return SerenityRest.lastResponse().as(TransactionInstallment.class);
    }
}
