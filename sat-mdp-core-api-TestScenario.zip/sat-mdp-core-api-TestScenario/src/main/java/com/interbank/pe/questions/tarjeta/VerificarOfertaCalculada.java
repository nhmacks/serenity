package com.interbank.pe.questions.tarjeta;

import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class VerificarOfertaCalculada implements Question<Object> {
    public static VerificarOfertaCalculada correspondiente() {
        return new VerificarOfertaCalculada();
    }

    @Override
    public Object answeredBy(Actor actor) {
        return SerenityRest.lastResponse().getBody().jsonPath().get("providerCode");
    }

}
