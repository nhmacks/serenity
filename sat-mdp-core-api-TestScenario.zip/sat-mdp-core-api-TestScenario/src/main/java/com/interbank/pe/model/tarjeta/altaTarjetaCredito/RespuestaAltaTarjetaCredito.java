package com.interbank.pe.model.tarjeta.altaTarjetaCredito;
import java.util.ArrayList;
import java.util.List;
public class RespuestaAltaTarjetaCredito {
    private String customerId;
    private String cardId;
    private String accountHost;
    private String dischargeDate;
    private String dueDate;
    private List<Object> beneficiaries = new ArrayList<Object>();
    public String getCustomerId() {
        return customerId;
    }
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }
    public String getCardId() {
        return cardId;
    }
    public void setCardId(String cardId) {
        this.cardId = cardId;
    }
    public String getAccountHost() {
        return accountHost;
    }
    public void setAccountHost(String accountHost) {
        this.accountHost = accountHost;
    }
    public String getDischargeDate() {
        return dischargeDate;
    }
    public void setDischargeDate(String dischargeDate) {
        this.dischargeDate = dischargeDate;
    }
    public String getDueDate() {
        return dueDate;
    }
    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }
    public List<Object> getBeneficiaries() {
        return beneficiaries;
    }
    public void setBeneficiaries(List<Object> beneficiaries) {
        this.beneficiaries = beneficiaries;
    }
}