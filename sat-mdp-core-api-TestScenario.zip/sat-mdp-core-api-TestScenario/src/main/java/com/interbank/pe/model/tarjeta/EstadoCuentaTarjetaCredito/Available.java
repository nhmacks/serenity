package com.interbank.pe.model.tarjeta.EstadoCuentaTarjetaCredito;

public class Available {
    private String sign;
    private String amount;
    public String getSign() {
        return sign;
    }
    public void setSign(String sign) {
        this.sign = sign;
    }
    public String getAmount() {
        return amount;
    }
    public void setAmount(String amount) {
        this.amount = amount;
    }
}
