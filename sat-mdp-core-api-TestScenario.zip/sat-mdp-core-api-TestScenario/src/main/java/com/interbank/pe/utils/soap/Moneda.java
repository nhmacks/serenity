package com.interbank.pe.utils.soap;

public enum Moneda {
    SOLES("soles"),
    DOLARES("dolares");
    private final String moneda;
    Moneda (String moneda){
        this.moneda=moneda;
    }
    public String getMoneda(){
     return moneda;
    }
}
