package com.interbank.pe.model.CompraDeDeuda.DesembolsoCompraDeuda.Request;

public class Purchase {
    private String institutionCode;
    private String cardId;
    private String amountDebtSoles;
    private String amountDebtDolares;
    public String getInstitutionCode() {
        return institutionCode;
    }
    public void setInstitutionCode(String institutionCode) {
        this.institutionCode = institutionCode;
    }
    public String getCardId() {
        return cardId;
    }
    public void setCardId(String cardId) {
        this.cardId = cardId;
    }
    public String getAmountDebtSoles() {
        return amountDebtSoles;
    }
    public void setAmountDebtSoles(String amountDebtSoles) {
        this.amountDebtSoles = amountDebtSoles;
    }
    public String getAmountDebtDolares() {
        return amountDebtDolares;
    }
    public void setAmountDebtDolares(String amountDebtDolares) {
        this.amountDebtDolares = amountDebtDolares;
    }
}

