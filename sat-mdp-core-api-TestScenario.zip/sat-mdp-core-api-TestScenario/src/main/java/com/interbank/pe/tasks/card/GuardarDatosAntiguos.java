package com.interbank.pe.tasks.card;

import com.interbank.pe.model.Tarjeta;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class GuardarDatosAntiguos implements Task {

    @Override
    public <T extends Actor> void performAs(T actor) {
        Tarjeta.setResponseCollection("antesCreditLine", SerenityRest.lastResponse().jsonPath().getJsonObject("creditLine.amount"));
        Tarjeta.setResponseCollection("antesUsed", SerenityRest.lastResponse().jsonPath().getJsonObject("creditLine.used.amount"));
        Tarjeta.setResponseCollection("antesAvailable", SerenityRest.lastResponse().jsonPath().getJsonObject("creditLine.available.amount"));
        Tarjeta.setResponseCollection("ContractNumber", SerenityRest.lastResponse().jsonPath().getJsonObject("account.contractNumber"));
    }

    public static GuardarDatosAntiguos deLaTC(){
        return instrumented(GuardarDatosAntiguos.class);
    }
}
