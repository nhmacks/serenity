package com.interbank.pe.model.Extracash.ofertaAjusta;

public class OfertaAjustadaResponseError {


    private String httpCode;
    private String httpMessage;
    private String providerCode;
    private String providerMessage;

    public String getHttpCode() {
        return httpCode;
    }

    public String getHttpMessage() {
        return httpMessage;
    }

    public String getProviderCode() {
        return providerCode;
    }

    public String getProviderMessage() {
        return providerMessage;
    }

    public void setHttpCode(String httpCode) {
        this.httpCode = httpCode;
    }

    public void setHttpMessage(String httpMessage) {
        this.httpMessage = httpMessage;
    }

    public void setProviderCode(String providerCode) {
        this.providerCode = providerCode;
    }
    public void setProviderMessage(String providerMessage) {
        this.providerMessage = providerMessage;
    }

}
