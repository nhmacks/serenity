package com.interbank.pe.questions.Extracash;

import com.interbank.pe.model.Extracash.ofertaAjusta.OfertaAjustadaResponseOk;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class OfertaAjustadaMensajeOk implements Question {

    @Override
    public OfertaAjustadaResponseOk answeredBy(Actor actor) {
        return SerenityRest.lastResponse().as(OfertaAjustadaResponseOk.class);
    }
}
