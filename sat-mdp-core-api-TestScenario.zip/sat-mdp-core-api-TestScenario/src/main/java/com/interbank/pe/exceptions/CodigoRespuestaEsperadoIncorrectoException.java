package com.interbank.pe.exceptions;

public class  CodigoRespuestaEsperadoIncorrectoException  extends AssertionError{
    public static final String CODIGO_ESPERADO_INCORRECTO= "Codigo de respuesta esperado es incorrecto";
    public static final String MENSAJE_ESPERADO_INCORRECTO = "Mensaje de respuesta obtenido es incorrecto";
    public CodigoRespuestaEsperadoIncorrectoException(String mensaje, Throwable e){super(mensaje, e);
    }
}
