package com.interbank.pe.model.Extracash.ofertaAjusta;

public class OfertaAjustadaResponseOk {
    private String cardId;
    private String lineCurrentAmount;
    private String lineUsedSign;
    private String lineUsedAmount;
    private String lineAvailableAmount;
    private String linePendingAmount;
    private String linePendingType;
    private String anualInterestRate;
    private String noLineIncrementOfferAmount;
    private String noLineIncrementAvailableAmount;
    private String lineIncrementFlag;
    private String lineIncrementRequiredFlag;
    private String lineIncrementOfferAmount;
    private String incrementAmount;
    private String lineIncrementAvailableAmount;
    private String lineIncrementAmount;
    private String maxLineAmount;
    private String availablePercentage;
    private String noLineIncrementCapitalizedInterestAmount;
    private String lineIncrementCapitalizedInterestAmount;

    public String getCardId() {
        return cardId;
    }

    public void setCardId(String cardId) {
        this.cardId = cardId;
    }

    public String getLineCurrentAmount() {
        return lineCurrentAmount;
    }

    public void setLineCurrentAmount(String lineCurrentAmount) {
        this.lineCurrentAmount = lineCurrentAmount;
    }

    public String getLineUsedSign() {
        return lineUsedSign;
    }

    public void setLineUsedSign(String lineUsedSign) {
        this.lineUsedSign = lineUsedSign;
    }

    public String getLineUsedAmount() {
        return lineUsedAmount;
    }

    public void setLineUsedAmount(String lineUsedAmount) {
        this.lineUsedAmount = lineUsedAmount;
    }

    public String getLineAvailableAmount() {
        return lineAvailableAmount;
    }

    public void setLineAvailableAmount(String lineAvailableAmount) {
        this.lineAvailableAmount = lineAvailableAmount;
    }

    public String getLinePendingAmount() {
        return linePendingAmount;
    }

    public void setLinePendingAmount(String linePendingAmount) {
        this.linePendingAmount = linePendingAmount;
    }

    public String getLinePendingType() {
        return linePendingType;
    }

    public void setLinePendingType(String linePendingType) {
        this.linePendingType = linePendingType;
    }

    public String getAnualInterestRate() {
        return anualInterestRate;
    }

    public void setAnualInterestRate(String anualInterestRate) {
        this.anualInterestRate = anualInterestRate;
    }

    public String getNoLineIncrementOfferAmount() {
        return noLineIncrementOfferAmount;
    }

    public void setNoLineIncrementOfferAmount(String noLineIncrementOfferAmount) {
        this.noLineIncrementOfferAmount = noLineIncrementOfferAmount;
    }

    public String getNoLineIncrementAvailableAmount() {
        return noLineIncrementAvailableAmount;
    }

    public void setNoLineIncrementAvailableAmount(String noLineIncrementAvailableAmount) {
        this.noLineIncrementAvailableAmount = noLineIncrementAvailableAmount;
    }

    public String getLineIncrementFlag() {
        return lineIncrementFlag;
    }

    public void setLineIncrementFlag(String lineIncrementFlag) {
        this.lineIncrementFlag = lineIncrementFlag;
    }

    public String getLineIncrementRequiredFlag() {
        return lineIncrementRequiredFlag;
    }

    public void setLineIncrementRequiredFlag(String lineIncrementRequiredFlag) {
        this.lineIncrementRequiredFlag = lineIncrementRequiredFlag;
    }

    public String getLineIncrementOfferAmount() {
        return lineIncrementOfferAmount;
    }

    public void setLineIncrementOfferAmount(String lineIncrementOfferAmount) {
        this.lineIncrementOfferAmount = lineIncrementOfferAmount;
    }

    public String getIncrementAmount() {
        return incrementAmount;
    }

    public void setIncrementAmount(String incrementAmount) {
        this.incrementAmount = incrementAmount;
    }

    public String getLineIncrementAvailableAmount() {
        return lineIncrementAvailableAmount;
    }

    public void setLineIncrementAvailableAmount(String lineIncrementAvailableAmount) {
        this.lineIncrementAvailableAmount = lineIncrementAvailableAmount;
    }

    public String getLineIncrementAmount() {
        return lineIncrementAmount;
    }

    public void setLineIncrementAmount(String lineIncrementAmount) {
        this.lineIncrementAmount = lineIncrementAmount;
    }

    public String getMaxLineAmount() {
        return maxLineAmount;
    }

    public void setMaxLineAmount(String maxLineAmount) {
        this.maxLineAmount = maxLineAmount;
    }

    public String getAvailablePercentage() {
        return availablePercentage;
    }

    public void setAvailablePercentage(String availablePercentage) {
        this.availablePercentage = availablePercentage;
    }

    public String getNoLineIncrementCapitalizedInterestAmount() {
        return noLineIncrementCapitalizedInterestAmount;
    }

    public void setNoLineIncrementCapitalizedInterestAmount(String noLineIncrementCapitalizedInterestAmount) {
        this.noLineIncrementCapitalizedInterestAmount = noLineIncrementCapitalizedInterestAmount;
    }

    public String getLineIncrementCapitalizedInterestAmount() {
        return lineIncrementCapitalizedInterestAmount;
    }

    public void setLineIncrementCapitalizedInterestAmount(String lineIncrementCapitalizedInterestAmount) {
        this.lineIncrementCapitalizedInterestAmount = lineIncrementCapitalizedInterestAmount;
    }
}