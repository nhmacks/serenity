package com.interbank.pe.model.CompraDeDeuda.OfertaAjustada.Response;

public class OfertaAjustadaResponse {
    private OfferInformation offerInformation;

    public OfferInformation getOfferInformation() {
        return offerInformation;
    }

    public void setOfferInformation(OfferInformation offerInformation) {
        this.offerInformation = offerInformation;
    }
}