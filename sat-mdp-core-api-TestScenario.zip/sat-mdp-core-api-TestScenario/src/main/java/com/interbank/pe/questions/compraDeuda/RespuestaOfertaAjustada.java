package com.interbank.pe.questions.compraDeuda;

import com.interbank.pe.model.CompraDeDeuda.OfertaAjustada.Response.OfertaAjustadaResponse;
import io.restassured.mapper.ObjectMapperType;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class RespuestaOfertaAjustada implements Question<OfertaAjustadaResponse> {
    @Override
    public OfertaAjustadaResponse answeredBy(Actor actor) {
        return SerenityRest.lastResponse().as(OfertaAjustadaResponse.class, ObjectMapperType.GSON);
    }
}
