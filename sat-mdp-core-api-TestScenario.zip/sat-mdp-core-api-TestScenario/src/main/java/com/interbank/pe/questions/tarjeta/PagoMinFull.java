package com.interbank.pe.questions.tarjeta;

import com.interbank.pe.model.Tarjeta;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

import java.text.DecimalFormat;

public class PagoMinFull implements Question<Boolean> {
    public String minimoDespuesSoles;
    public String TotalDespuesDolares;
    public String minimoDespuesDolares;
    public String TotalDespuesSoles;


    private PagoMinFull() {
    }

    public static PagoMinFull Liquidacion() {
        return new PagoMinFull();
    }

    @Override
    public Boolean answeredBy(Actor actor) {
        minimoDespuesSoles = String.valueOf(Tarjeta.getResponseCollection("pagominimosoles"));
        TotalDespuesDolares = String.valueOf(Tarjeta.getResponseCollection("pagototalsoles"));
        minimoDespuesDolares = String.valueOf(Tarjeta.getResponseCollection("pagominimodolares"));
        TotalDespuesSoles = String.valueOf(Tarjeta.getResponseCollection("pagototaldolares"));

        System.out.println("=========================================================");
        System.out.println("Minimo Soles despues del pago: " + minimoDespuesSoles);
        System.out.println("Total Soles despues del pago: " + TotalDespuesDolares);
        System.out.println("Minimo Dolares despues del pagoa: " + minimoDespuesDolares);
        System.out.println("Total Dolares despues del pago: " + TotalDespuesSoles);
        System.out.println("=========================================================");

        return true;
    }
}
