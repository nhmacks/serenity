package com.interbank.pe.tasks.cliente.Cuenta;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Post;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class AltaDeCuenta implements Task {
    private final String token;
    private final Object request;

    public AltaDeCuenta(String token, Object request) {
        this.token = token;
        this.request = request;
    }


    public static AltaDeCuenta deAhorro(String token, Object request) {
        return instrumented(AltaDeCuenta.class, token, request);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Post.to("/digital/sales/accounts")
                        .with(requestSpecification ->
                                requestSpecification
                                        .relaxedHTTPSValidation()
                                        .header("application", "APP")
                                        .header("company", "Interbank")
                                        .header("storeCode", "898")
                                        .header("Content-Type", "application/json")
                                        .header("Ocp-Apim-Subscription-Key", "99564832ecb446379e7dd9eeb7c300aa")
                                        .header("Authorization", "Bearer " + token)
                                        .body(request)
                        )
        );
    }
}
