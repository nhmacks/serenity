package com.interbank.pe.model.cliente.cliente.RequestCrearCliente;

public class ClienteConTarjeta {
    private String contrato;
    private String customerType;
    private String card;
    private String marcaTC;
    private String tipoTC;
    private String producto;
    private String description;
    private String condicionEconomica;
    private String lineaCredito;
    private String lineaCreditoMax;
    private String tipoDocumento;
    private String numeroDocumento;
    private String primerNombre;
    private String segundoNombre;
    private String primerApellido;
    private String segundoApellido;

    public ClienteConTarjeta(String contrato, String customerType, String card, String marcaTC, String tipoTC, String producto, String description, String condicionEconomica, String lineaCredito, String lineaCreditoMax, String tipoDocumento, String numeroDocumento, String primerNombre, String segundoNombre, String primerApellido, String segundoApellido) {
        this.contrato = contrato;
        this.customerType = customerType;
        this.card = card;
        this.marcaTC = marcaTC;
        this.tipoTC = tipoTC;
        this.producto = producto;
        this.description = description;
        this.condicionEconomica = condicionEconomica;
        this.lineaCredito = lineaCredito;
        this.lineaCreditoMax = lineaCreditoMax;
        this.tipoDocumento = tipoDocumento;
        this.numeroDocumento = numeroDocumento;
        this.primerNombre = primerNombre;
        this.segundoNombre = segundoNombre;
        this.primerApellido = primerApellido;
        this.segundoApellido = segundoApellido;
    }

    public String getContrato() {
        return contrato;
    }

    public void setContrato(String contrato) {
        this.contrato = contrato;
    }

    public String getCustomerType() {
        return customerType;
    }

    public void setCustomerType(String customerType) {
        this.customerType = customerType;
    }

    public String getCard() {
        return card;
    }

    public void setCard(String card) {
        this.card = card;
    }

    public String getMarcaTC() {
        return marcaTC;
    }

    public void setMarcaTC(String marcaTC) {
        this.marcaTC = marcaTC;
    }

    public String getTipoTC() {
        return tipoTC;
    }

    public void setTipoTC(String tipoTC) {
        this.tipoTC = tipoTC;
    }

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCondicionEconomica() {
        return condicionEconomica;
    }

    public void setCondicionEconomica(String condicionEconomica) {
        this.condicionEconomica = condicionEconomica;
    }

    public String getLineaCredito() {return lineaCredito;}

    public void setLineaCredito(String lineaCredito) {
        this.lineaCredito = lineaCredito;
    }

    public String getLineaCreditoMax() {
        return lineaCreditoMax;
    }

    public void setLineaCreditoMax(String lineaCreditoMax) {
        this.lineaCreditoMax = lineaCreditoMax;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getNumeroDocumento() {
        return numeroDocumento;
    }

    public void setNumeroDocumento(String numeroDocumento) {
        this.numeroDocumento = numeroDocumento;
    }

    public String getPrimerNombre() {
        return primerNombre;
    }

    public void setPrimerNombre(String primerNombre) {
        this.primerNombre = primerNombre;
    }

    public String getSegundoNombre() {
        return segundoNombre;
    }

    public void setSegundoNombre(String segundoNombre) {
        this.segundoNombre = segundoNombre;
    }

    public String getPrimerApellido() {
        return primerApellido;
    }

    public void setPrimerApellido(String primerApellido) {
        this.primerApellido = primerApellido;
    }

    public String getSegundoApellido() {
        return segundoApellido;
    }

    public void setSegundoApellido(String segundoApellido) {
        this.segundoApellido = segundoApellido;
    }
}
