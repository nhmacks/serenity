package com.interbank.pe.model.cliente.cliente.ResponseCrearCliente;

public class Header {
    private HeaderResponse headerResponse;
    public HeaderResponse getHeaderResponse() {
        return headerResponse;
    }
    public void setHeaderResponse(HeaderResponse headerResponse) {
        this.headerResponse = headerResponse;
    }
}