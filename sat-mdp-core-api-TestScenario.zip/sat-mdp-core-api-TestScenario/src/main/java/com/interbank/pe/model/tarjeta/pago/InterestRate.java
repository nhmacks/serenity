package com.interbank.pe.model.tarjeta.pago;

public class InterestRate {
    private String monthlyPct;
    private String anualPct;
    public String getMonthlyPct() {
        return monthlyPct;
    }
    public void setMonthlyPct(String monthlyPct) {
        this.monthlyPct = monthlyPct;
    }
    public String getAnualPct() {
        return anualPct;
    }
    public void setAnualPct(String anualPct) {
        this.anualPct = anualPct;
    }
}