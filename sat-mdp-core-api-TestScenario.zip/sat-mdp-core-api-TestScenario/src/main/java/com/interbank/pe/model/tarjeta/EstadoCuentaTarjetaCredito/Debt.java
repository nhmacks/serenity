package com.interbank.pe.model.tarjeta.EstadoCuentaTarjetaCredito;

public class Debt {
    private String solesAmount;
    private String dollarsAmount;
    private String solesAmountSign;
    private String dollarsAmountSign;
    public String getSolesAmount() {
        return solesAmount;
    }
    public void setSolesAmount(String solesAmount) {
        this.solesAmount = solesAmount;
    }
    public String getDollarsAmount() {
        return dollarsAmount;
    }
    public void setDollarsAmount(String dollarsAmount) {
        this.dollarsAmount = dollarsAmount;
    }
    public String getSolesAmountSign() {
        return solesAmountSign;
    }
    public void setSolesAmountSign(String solesAmountSign) {
        this.solesAmountSign = solesAmountSign;
    }
    public String getDollarsAmountSign() {
        return dollarsAmountSign;
    }
    public void setDollarsAmountSign(String dollarsAmountSign) {
        this.dollarsAmountSign = dollarsAmountSign;
    }
}
