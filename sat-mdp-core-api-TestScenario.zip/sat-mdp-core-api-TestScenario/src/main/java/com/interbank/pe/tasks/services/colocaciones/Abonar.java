package com.interbank.pe.tasks.services.colocaciones;

import com.interbank.pe.model.MovimientosTC;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Post;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static com.interbank.pe.utils.soap.EnumRequestSoap.*;
import static com.interbank.pe.utils.soap.UtilisSoap.obtenerRequestSoap;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class Abonar implements Task {

    private final String tarjeta, contrato, moneda, monto, flujo, codigoFactura;

    public Abonar(String flujo, String tarjeta, String contrato, String moneda, String monto, String codigoFactura) {
        this.tarjeta = tarjeta;
        this.contrato = contrato;
        this.moneda = moneda;
        this.monto = monto;
        this.flujo = flujo;
        this.codigoFactura = codigoFactura;
    }

    public static Abonar enTarjetaCredito(String flujo, String tarjeta, String contrato, String moneda, String monto, String codigoFactura) {
        return instrumented(Abonar.class, flujo, tarjeta, contrato, moneda, monto, codigoFactura);

    }

    @Override
    public <T extends Actor> void performAs(T theActor) {
        theActor.attemptsTo(
                Post.to("ibk/srv/MPO/Colocaciones/proceso.abonarTarjetaCredito/v1.0")
                        .with(
                                request ->
                                        request
                                                .relaxedHTTPSValidation()
                                                .header("SOAPAction", "http://interbank.com.pe/service/MPO/Colocaciones/proceso.abonarTarjetaCredito/v1.0/")
                                                .header("charset", "*/*")
                                                .header("Content-Type", "text/xml")
                                                .header("charset", "ISO-8859-1")
                                                .body(ObtenerRequestPasarellaAbonar(flujo))
                        )
        );
        MovimientosTC.setResponseCollection("card",tarjeta);
    }

    private String ObtenerRequestPasarellaAbonar(String flujo) {
        try {
            return obtenerRequestSoap(pathrequest(flujo))
                    .replace("PAN", tarjeta)
                    .replace("CuentaContrato", contrato)
                    .replace("TotalMonto", monto)
                    .replace("MonedaCodigo", Currency(moneda))
                    .replace("fechaMessage", SimpleDate())
                    .replace("fechaTime", SimpleDateFormat())
                    .replace("codigoFactura", codigoFactura);
        } catch (IOException e) {
            return null;
        }
    }

    private String pathrequest(String flujo) {
        if (flujo.trim().equals("PASARELLA_ABONAR")) {
            return PASARELLA_ABONAR.getPathArchivo();
        } else if (flujo.trim().equals("PREMIA")) {
            return PREMIA.getPathArchivo();
        } else if (flujo.trim().equals("GIRU")) {
            return GIRU.getPathArchivo();
        } else if (flujo.trim().equals("APP_ABONAR")) {
            return APP_ABONAR.getPathArchivo();
        }
        return null;
    }

    private String Currency(String Currency) {
        if (Currency.equals("soles")) {
            return "001";
        } else if (Currency.equals("dolares")) {
            return "010";
        }
        return Currency;
    }

    private String SimpleDate() {
        Date date = new Date(System.currentTimeMillis());
        SimpleDateFormat format1 = new SimpleDateFormat("yyyyMMddHHmmssZZZZ");
        return format1.format(date);
    }
    private String SimpleDateFormat(){
        Date date = new Date(System.currentTimeMillis());
        SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        return format1.format(date);
    }
}

