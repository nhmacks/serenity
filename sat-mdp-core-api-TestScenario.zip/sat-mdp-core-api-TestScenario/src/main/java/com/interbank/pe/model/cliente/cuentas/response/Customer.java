package com.interbank.pe.model.cliente.cuentas.response;

public class Customer {
    private String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
