package com.interbank.pe.model.tarjeta.EstadoCuentaTarjetaCredito;

public class Installment {
    private String dollarsAmount;
    private String solesAmount;
    private String flag;
    public String getDollarsAmount() {
        return dollarsAmount;
    }
    public void setDollarsAmount(String dollarsAmount) {
        this.dollarsAmount = dollarsAmount;
    }
    public String getSolesAmount() {
        return solesAmount;
    }
    public void setSolesAmount(String solesAmount) {
        this.solesAmount = solesAmount;
    }
    public String getFlag() {
        return flag;
    }
    public void setFlag(String flag) {
        this.flag = flag;
    }
}
