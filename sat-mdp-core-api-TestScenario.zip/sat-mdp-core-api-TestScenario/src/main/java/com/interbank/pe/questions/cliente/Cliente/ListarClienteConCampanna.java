package com.interbank.pe.questions.cliente.Cliente;

import com.interbank.pe.model.campaign.CampannaDiariaExtracash;
import com.interbank.pe.model.cliente.cliente.RequestCrearCliente.ClienteConCampanna;
import com.interbank.pe.model.cliente.cliente.RequestCrearCliente.Clientes;
import com.interbank.pe.model.tarjeta.Tarjeta;
import com.interbank.pe.questions.campanna.ListaCampannaDiariaExtracash;
import com.interbank.pe.questions.tarjeta.ListarTarjetas;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

import java.util.List;
import java.util.Objects;

public class ListarClienteConCampanna implements Question <ClienteConCampanna>{
    String pan;
    String montoCampanna;

    String cardIdType;
    String tipoDocumento;
    String lineaCreditoTC;
    String codigoCliente;
    String pilotoCampanna;
    String numeroContratoTC;
    String codMoneda;
    String importeExtracash;
    String tasaExtracash;
    String nroMesesDiferidos;
    String indicadorControlPlazo;
    String indicadorSeguroEfectivo;
    String importeCem;
    String indicadorPiloto;
    String indicadorIncrementoLinea;
    String porcentajeConsumo;
    String lineaCreditoOrigin;
    String lineaCreditoMaxima;
    String fechaCaducidad;
    String numeroDocumento;

    public ListarClienteConCampanna(String pan, String montoCampanna, String tipoDocumento, String lineaCreditoTC, String porcentajeConsumo, String pilotoCampanna) {
        this.pan = pan;
        this.montoCampanna = montoCampanna(montoCampanna);
        this.tipoDocumento = tipoDocumento;
        this.lineaCreditoTC = lineaCredito(lineaCreditoTC);
        this.porcentajeConsumo = porcentajeConsumo(porcentajeConsumo);
        this.pilotoCampanna = pilotoCampanna;
    }

    @Override
    public ClienteConCampanna answeredBy(Actor actor) {
        List<CampannaDiariaExtracash> campannaDiariaExtracashList = new ListaCampannaDiariaExtracash().answeredBy(actor);
        List<Tarjeta> tarjetasList = new ListarTarjetas().answeredBy(actor);
        List<Clientes> clientes = new ListarClientes().answeredBy(actor);
        for (CampannaDiariaExtracash campanna : campannaDiariaExtracashList) {
            if ((Objects.equals(campanna.getFlagCampannaDiaria(), "") | (Objects.equals(campanna.getFlagCampannaDiaria(), null)))
                    & (Objects.equals(campanna.getImporteLineaExtracash(), montoCampanna))
                    & (Objects.equals(campanna.getPorcentajeDisponibleConsumo(), porcentajeConsumo))
                    & (Objects.equals(campanna.getLineaCreditoOrigen(), lineaCreditoTC))
                    & (Objects.equals(campanna.getIndicadorPiloto(), pilotoCampanna))) {
                for (Tarjeta tarjeta : tarjetasList) {
                    for (Clientes clientes1 : clientes) {
                        if (Integer.valueOf(campanna.getNumeroCuenta()).equals(Integer.valueOf(tarjeta.getContrato())) &
                                Integer.valueOf(campanna.getNumeroCuenta()).equals(Integer.valueOf(clientes1.getContrato()))) {
                            this.pan = tarjeta.getCard();
                            this.montoCampanna = String.valueOf(Double.parseDouble(campanna.getImporteLineaExtracash().substring(0, 11)));
                            this.cardIdType = tarjeta.getTipoTC();
                            this.tipoDocumento = clientes1.getTipoDocumento();
                            this.lineaCreditoTC = tarjeta.getlineaCredito();
                            this.codigoCliente = clientes1.getCodigoCliente();
                            this.numeroContratoTC = campanna.getNumeroCuenta();
                            this.codMoneda = campanna.getCodigoMoneda();
                            this.importeExtracash = campanna.getImporteLineaExtracash();
                            this.tasaExtracash = campanna.getTasaExtracash();
                            this.nroMesesDiferidos = campanna.getMesesDiferido();
                            this.indicadorControlPlazo = campanna.getIndicadorControlPlazo();
                            this.indicadorSeguroEfectivo = campanna.getCodigoCampannaSiebel();
                            this.importeCem = campanna.getImporteCEM();
                            this.indicadorPiloto = campanna.getIndicadorPiloto();
                            this.indicadorIncrementoLinea = campanna.getIndicadorIncrementoLinea();
                            this.porcentajeConsumo = campanna.getPorcentajeDisponibleConsumo();
                            this.lineaCreditoOrigin = campanna.getLineaCreditoOrigen();
                            this.lineaCreditoMaxima = campanna.getLineaCreditoMaxima();
                            this.fechaCaducidad = campanna.getFechaCaducidad();
                            this.numeroDocumento = clientes1.getNumeroDocumento();
                            System.out.println("NumeroContrato: "+ numeroContratoTC + "PAN: " + pan + ", codigoCliente: " + codigoCliente + ", Extracash: " + montoCampanna + ", TipoTarjeta: " + cardIdType + " tipoDocumento: " + tipoDocumento + " porcentajeConsumo: " + porcentajeConsumo);
                            break;
                        }
                    }
                }
                break;
            }
        }
        return new ClienteConCampanna(pan,
                montoCampanna,
                cardIdType,
                tipoDocumento,
                lineaCreditoTC,
                porcentajeConsumo,
                codigoCliente,
                pilotoCampanna,
                numeroContratoTC,
                codMoneda,
                importeExtracash,
                tasaExtracash,
                nroMesesDiferidos,
                indicadorControlPlazo,
                indicadorSeguroEfectivo,
                importeCem,
                indicadorPiloto,
                indicadorIncrementoLinea,
                lineaCreditoOrigin,
                lineaCreditoMaxima,
                fechaCaducidad,
                numeroDocumento);
    }

    public String montoCampanna(String montoCampanna) {
        int indicePunto = montoCampanna.indexOf(".");
        String parteEntera = montoCampanna.substring(0, indicePunto);
        int valorEntero = Integer.parseInt(parteEntera);
        String parteDecimal = montoCampanna.substring(indicePunto + 1);
        return String.format("%011d", valorEntero) + "" + parteDecimal;
    }

    public String porcentajeConsumo(String montoCampanna) {
        int valorEntero = Integer.parseInt(montoCampanna);
        String parteDecimal = "00";
        return String.format("%03d", valorEntero) + "" + parteDecimal;
    }

    public String lineaCredito(String montoCampanna) {
        int indicePunto = montoCampanna.indexOf(".");
        String parteEntera = montoCampanna.substring(0, indicePunto);
        int valorEntero = Integer.parseInt(parteEntera);
        String parteDecimal = montoCampanna.substring(indicePunto + 1);
        return String.format("%010d", valorEntero) + "" + parteDecimal;
    }
}
