package com.interbank.pe.questions.movimientos;

import com.interbank.pe.utils.soap.UtilisSoap;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

import java.util.HashMap;

public class ObtenerMovimientos implements Question<HashMap<String, String>> {

    @Override
    public HashMap<String, String> answeredBy(Actor actor) {
        String cadena = SerenityRest.lastResponse().getBody().prettyPrint();
        HashMap<String, String> map = UtilisSoap.obtengoDetallesDeLaRespuesta(cadena,"consumo");
        return map;
    }
}
