package com.interbank.pe.questions.cliente.accounts;

import com.interbank.pe.model.cliente.cliente.RequestCrearCliente.Clientes;
import com.interbank.pe.model.cliente.cuentas.CuentaAhorros;
import com.interbank.pe.questions.cliente.Cliente.ListarClientes;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class ListarClientesSinCuentaAhorro implements Question {

    @Override
    public List<Clientes> answeredBy(Actor actor) {
        //Listar clientes
        //Listar cuentas de ahorro
        List<Clientes> clientesList = new ArrayList<>();

        List<Clientes> clientes = new ListarClientes().answeredBy(actor);
        List<CuentaAhorros> cuentaAhorros = new ListarCuentasAhorro().answeredBy(actor);

        for (Clientes cl : clientes) {   //Lista todos los clientes
            boolean encontrado = false;
            for (CuentaAhorros cuentaAhorros1 : cuentaAhorros) { // Lista todas las cuentas de ahorro
                if (Objects.equals(cl.getCodigoCliente(), cuentaAhorros1.getCodCliente())) {
                    System.out.println("cliente con cuenta de ahorro" + cl.getCodigoCliente());
                    encontrado = true;
                    break;
                }
            }
            if (encontrado) {
                System.out.println("El dato " + cl.getCodigoCliente() + "ha sido encontrado en la lista.");
            } else {
                System.out.println("Cliente no cuenta con cuenta de ahorro: " + cl.getCodigoCliente());
                Clientes dataCliente = new Clientes(cl.getTipoDocumento(), cl.getNumeroDocumento(), cl.getPrimerNombre(), cl.getSegundoNombre(), cl.getPrimerApellido(), cl.getSegundoApellido(), cl.getCodigoCliente(), cl.getFechaCreacionCodClient(), cl.getTarjetaCredito(), cl.getFechaCreacionTC(), cl.getContrato(), cl.getFechaActivacionTC());
                clientesList.add(dataCliente);
            }

        }
        return clientesList;
    }
}
