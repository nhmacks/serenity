package com.interbank.pe.questions.cliente.accounts;

import com.interbank.pe.model.cliente.cuentas.CuentaAhorros;
import net.serenitybdd.screenplay.Actor;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.interbank.pe.utils.soap.EnumRequestSoap.CUENTA_AHORRO;
import static com.interbank.pe.utils.soap.UtilsTarjeta.existsValue;

public class ListarCuentasAhorro {
    public List<CuentaAhorros> answeredBy(Actor actor) {
        String filePath = CUENTA_AHORRO.getPathArchivo();
        String line = "";
        List<CuentaAhorros> cuentaAhorrosList = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            int contador = 0;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length >= 4 & contador > 0) {
                    CuentaAhorros cuentaAhorros = new CuentaAhorros(
                            existsValue(data, 0) ? data[0] : "",
                            existsValue(data, 1) ? data[1] : "",
                            existsValue(data, 2) ? data[2] : "",
                            existsValue(data, 3) ? data[3] : "",
                            existsValue(data, 4) ? data[4] : "",
                            existsValue(data, 5) ? data[5] : "",
                            existsValue(data, 6) ? data[6] : "",
                            existsValue(data, 7) ? data[7] : "",
                            existsValue(data, 8) ? data[8] : ""
                    );
                    cuentaAhorrosList.add(cuentaAhorros);
                }
                contador++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return cuentaAhorrosList;
    }
}
