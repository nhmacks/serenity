package com.interbank.pe.model.tarjeta;

public class ClientesConTarjetaDebito {


    private String tarjetaDebito;
    private String claveWeb;
    private String codigoUnico;
    private String cargoMoneda;
    private String tarjetaCredito;
    private String abonoMoneda;
    private String abonoCuenta;
    private String importeTransferencia;
    private String monedaTransferencia;

    public ClientesConTarjetaDebito(String tarjetaDebito, String claveWeb, String codigoUnico, String cargoMoneda, String tarjetaCredito, String abonoMoneda, String abonoCuenta, String importeTransferencia, String monedaTransferencia) {
        this.tarjetaDebito = tarjetaDebito;
        this.claveWeb = claveWeb;
        this.codigoUnico = codigoUnico;
        this.cargoMoneda = cargoMoneda;
        this.tarjetaCredito = tarjetaCredito;
        this.abonoMoneda = abonoMoneda;
        this.abonoCuenta = abonoCuenta;
        this.importeTransferencia = importeTransferencia;
        this.monedaTransferencia = monedaTransferencia;
    }

    public String gettarjetaDebito() {
        return tarjetaDebito;
    }

    public void settarjetaDebito(String tarjetaDebito) {
        this.tarjetaDebito = tarjetaDebito;
    }

    public String getclaveWeb() {
        return claveWeb;
    }

    public void setclaveWeb(String claveWeb) {
        this.claveWeb = claveWeb;
    }

    public String getcargoMoneda() {
        return cargoMoneda;
    }

    public void setcargoMoneda(String cargoMoneda) {
        this.cargoMoneda = cargoMoneda;
    }

    public String gettarjetaCredito() {
        return tarjetaCredito;
    }

    public void settarjetaCredito(String tarjetaCredito) {
        this.tarjetaCredito = tarjetaCredito;
    }

    public String getcodigoUnico() {
        return codigoUnico;
    }

    public void setcodigoUnico(String codigoUnico) {
        this.codigoUnico = codigoUnico;
    }


    public String getabonoMoneda() {
        return abonoMoneda;
    }

    public void setabonoMoneda(String abonoMoneda) {
        this.abonoMoneda = abonoMoneda;
    }

    public String getabonoCuenta() {
        return abonoCuenta;
    }

    public void setabonoCuenta(String abonoCuenta) {
        this.abonoCuenta = abonoCuenta;
    }

    public String getimporteTransferencia() {
        return importeTransferencia;
    }

    public void setimporteTransferencia(String importeTransferencia) {
        this.importeTransferencia = importeTransferencia;
    }

    public String getmonedaTransferencia() {
        return monedaTransferencia;
    }

    public void setmonedaTransferencia(String monedaTransferencia) {
        this.monedaTransferencia = monedaTransferencia;
    }

}
