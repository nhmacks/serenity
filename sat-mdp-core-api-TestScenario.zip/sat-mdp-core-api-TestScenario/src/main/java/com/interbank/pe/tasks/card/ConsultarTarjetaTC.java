package com.interbank.pe.tasks.card;

import com.interbank.pe.model.Tarjeta;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Get;

import static com.interbank.pe.utils.soap.UtilsTarjeta.truncarPAN;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class ConsultarTarjetaTC implements Task {
    private final String tarjeta;
    private final String codigoUnico;

    public ConsultarTarjetaTC(String tarjeta, String codigoUnico) {
        this.tarjeta = tarjeta;
        this.codigoUnico = codigoUnico;
    }

    public static ConsultarTarjetaTC obtenerDatos(String tarjeta, String codigoUnico) {
        return instrumented(ConsultarTarjetaTC.class, tarjeta, codigoUnico);
    }

    @Override
    public <T extends Actor> void performAs(T theActor) {
        theActor.attemptsTo(
                Get.resource("ibk/uat/api/credit-card/v3/"+truncarPAN(tarjeta))
                        .with(
                                request ->
                                        request
                                                .relaxedHTTPSValidation()
                                                .header("X-IBM-Client-Id", "a3a383ba-3d4d-4a35-a85e-0cd0f09eae26")
                                                .header("X-INT-Branch-Id", "100")
                                                .header("X-INT-CardId-Type", "1")
                                                .header("X-INT-Consumer-Id", "FTI")
                                                .header("X-INT-Message-Id", "202244291744564")
                                                .header("X-INT-Net-Id", "TD")
                                                .header("X-INT-Service-Id", "SAT")
                                                .header("X-INT-Supervisor-Id", "BUSSPWP")
                                                .header("X-INT-Timestamp", "2022-01-06T02:36:50.852Z")
                                                .header("X-INT-User-Id", "S38504")
                                                .header("Authorization", "Basic dUJzZUdlblVhdDpJYmsyMDE4JA==")
                                                .header("Content-Type","application/json")
                                                .queryParam("referenceId", codigoUnico)
                        )
        );
        Tarjeta.setResponseCollection("creditLine", SerenityRest.lastResponse().jsonPath().getJsonObject("creditLine.amount"));
        Tarjeta.setResponseCollection("used", SerenityRest.lastResponse().jsonPath().getJsonObject("creditLine.used.amount"));
        Tarjeta.setResponseCollection("available", SerenityRest.lastResponse().jsonPath().getJsonObject("creditLine.available.amount"));
        Tarjeta.setResponseCollection("contractNumber", SerenityRest.lastResponse().jsonPath().getJsonObject("account.contractNumber"));
        Tarjeta.setResponseCollection("pagominimosoles", SerenityRest.lastResponse().jsonPath().getJsonObject("payment.minimumAmountSoles"));
        Tarjeta.setResponseCollection("pagototalsoles", SerenityRest.lastResponse().jsonPath().getJsonObject("payment.totalAmountSoles"));
        Tarjeta.setResponseCollection("pagominimodolares", SerenityRest.lastResponse().jsonPath().getJsonObject("payment.minimumAmountDollars"));
        Tarjeta.setResponseCollection("pagototaldolares", SerenityRest.lastResponse().jsonPath().getJsonObject("payment.totalAmountDollars"));
    }
}
