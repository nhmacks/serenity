package com.interbank.pe.tasks.card;

import com.interbank.pe.model.MovimientosTC;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Get;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class SimulacionDePago implements Task {

    private final String cuota;

    //CONSTRUCTOR
    public SimulacionDePago(String cuota) {
        this.cuota = cuota;
    }

    public static SimulacionDePago EnCuotas(String cuota) {
        return instrumented(SimulacionDePago.class, cuota);
    }

    //METODO PERFORMABLE
    @Override
    public <T extends Actor> void performAs(T theActor) {
        theActor.attemptsTo(
                Get.resource("ibk/uat/api/credit-card/v1/installments-simulation")
                        .with(
                                request ->
                                        request
                                                .relaxedHTTPSValidation()
                                                .header("Content-Type", "application/json")
                                                .header("X-INT-Channel-Id", "BI")
                                                .header("X-INT-Device-Id", "SERVER01")
                                                .header("X-INT-Timestamp", "2022-07-21T14:46:56.128Z")
                                                .header("X-INT-Service-Id", "APA")
                                                .header("X-INT-Net-Id", "BI")
                                                .header("X-IBM-Client-Id", "2b22dc85-b740-4838-a7c8-b2bb7d225126")
                                                .header("X-INT-Supervisor-Id", "APPA0000")
                                                .header("X-INT-Branch-Id", "898")
                                                .header("X-INT-Consumer-Id", "APP")
                                                .header("X-INT-Message-Id", "222")
                                                .header("X-INT-User-Id", "APPA0000")
                                                .header("Authorization", "Basic dUJzZUFwcEFDbzpJYmt1YnNhY28xNw==")
                                                .queryParam("cardId", MovimientosTC.getResponseCollection("card"))
                                                .queryParam("extractNum", MovimientosTC.getResponseCollection("numeroExtracto"))
                                                .queryParam("extractSequence", MovimientosTC.getResponseCollection("numeroMovimientoExtracto"))
                                                .queryParam("currencyId", MovimientosTC.getResponseCollection("currency"))
                                                .queryParam("amount", MovimientosTC.getResponseCollection("amount"))
                                                .queryParam("installmentsNum", cuota)
                        )
        );
        MovimientosTC.setResponseCollection("cuotas", cuota);
    }
}
