package com.interbank.pe.tasks.cliente.Token;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Post;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class GeneraToken implements Task {
    public static GeneraToken deSesion() {
        return instrumented(GeneraToken.class);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Post.to("/api/clientes/oauth/token")
                        .with(
                                requestSpecification ->
                                        requestSpecification
                                                .relaxedHTTPSValidation()
                                                .header("Ocp-Apim-Subscription-Key", "f0e6bdd85d624e1c81b71a2298152277")
                                                .header("Content-Type", "application/x-www-form-urlencoded")
                                                .header("Authorization", "Basic YnBpOm9ia1ZOcDRhZnJBSGJ5Vnc=")
                                                .urlEncodingEnabled(true)
                                                .formParam("scope", "all")
                                                .formParam("grant_type", "client_credentials")

                        )
        );
    }
}
