package com.interbank.pe.tasks.cliente.Cliente;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import static com.interbank.pe.utils.soap.EnumRequestSoap.CLIENTE;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class ActualizarDatosCliente implements Task {

    private final String numeroDocumento;
    private final String codigoCliente;
    private final String numeroTarjeta;
    private final String fechaCreacionTC;
    private final String contrato;

    public ActualizarDatosCliente(String numeroDocumento, String codigoCliente, String numeroTarjeta, String fechaCreacionTC, String contrato) {
        this.numeroDocumento = numeroDocumento;
        this.codigoCliente = codigoCliente;
        this.numeroTarjeta = numeroTarjeta;
        this.fechaCreacionTC = fechaCreacionTC;
        this.contrato = contrato;
    }

    public static ActualizarDatosCliente nuevos(String numeroDocumento, String codigoCliente, String numeroTarjeta, String fechaCreacionTC, String contrato) {
        return instrumented(ActualizarDatosCliente.class, numeroDocumento, codigoCliente, numeroTarjeta, fechaCreacionTC, contrato);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        String filePath = CLIENTE.getPathArchivo();

        try {
            // Lectura del archivo CSV
            BufferedReader br = new BufferedReader(new FileReader(filePath));
            String line;
            StringBuilder sb = new StringBuilder();
            boolean found = false;

            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");

                // Busqueda del dato a actualizar o agregar
                if (data[6].equals(codigoCliente)) {
                    data = addDataToRow(data, numeroTarjeta, fechaCreacionTC,contrato);
                    found = true;
                }

                // Construccion del nuevo contenido del archivo
                sb.append(String.join(",", data)).append("\n");
            }

            br.close();

            // Si el dato fue encontrado, se guarda el archivo con los nuevos datos
            if (found) {
                FileWriter fw = new FileWriter(filePath);
                fw.write(sb.toString());
                fw.close();
                System.out.println("Archivo actualizado correctamente.");
            } else {
                System.out.println("El dato buscado no se encontro en el archivo.");
            }

        } catch (IOException e) {
            System.out.println("Error al leer o escribir el archivo.");
            e.printStackTrace();
        }
    }

    private static String[] addDataToRow(String[] data, String numeroTarjeta, String fechaCreacion, String contrato) {
        String[] newData = new String[data.length + 3];
        System.arraycopy(data, 0, newData, 0, data.length);
        newData[data.length] = numeroTarjeta;
        newData[data.length + 1] = fechaCreacion;
        newData[data.length + 2] = contrato;
        return newData;
    }
}
