package com.interbank.pe.tasks.card;

import com.interbank.pe.model.MovimientosTC;
import com.interbank.pe.utils.soap.UtilisSoap;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;

import java.util.HashMap;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class SeleccionarUltimoMovimientosTC implements Task {

    @Override
    public <T extends Actor> void performAs(T actor) {
        String cadena = SerenityRest.lastResponse().getBody().asPrettyString();
        HashMap<String, String> map = UtilisSoap.obtengoDetallesDeLaRespuesta(cadena, "consumo");
        MovimientosTC.setResponseCollection("numeroExtracto", map.get("numeroExtracto"));
        MovimientosTC.setResponseCollection("numeroMovimientoExtracto", map.get("numeroMovimientoExtracto"));
        MovimientosTC.setResponseCollection("nombreComercioReducido", map.get("nombreComercioReducido"));
        MovimientosTC.setResponseCollection("importeFactura", map.get("importeFactura"));
        MovimientosTC.setResponseCollection("fechaFactura", map.get("fechaFactura"));
        MovimientosTC.setResponseCollection("horaSIAIDCD", map.get("horaSIAIDCD"));
    }

    public static SeleccionarUltimoMovimientosTC now() {
        return instrumented(SeleccionarUltimoMovimientosTC.class);
    }
}
