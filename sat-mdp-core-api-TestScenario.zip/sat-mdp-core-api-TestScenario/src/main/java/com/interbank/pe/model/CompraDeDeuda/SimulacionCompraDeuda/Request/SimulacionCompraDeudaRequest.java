package com.interbank.pe.model.CompraDeDeuda.SimulacionCompraDeuda.Request;
public class SimulacionCompraDeudaRequest {
    private String documentType;
    private String referenceId;
    private Simulation simulation;
    public String getDocumentType() {
        return documentType;
    }
    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }
    public String getReferenceId() {
        return referenceId;
    }
    public void setReferenceId(String referenceId) {
        this.referenceId = referenceId;
    }
    public Simulation getSimulation() {
        return simulation;
    }
    public void setSimulation(Simulation simulation) {
        this.simulation = simulation;
    }

}

