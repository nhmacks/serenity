package com.interbank.pe.model.cuotas.Request;

public class PaseCuotasRequest {
    String totalInstallments;
    String transactionCurrency;
    Integer documentType;
    String invoiceAmount;
    String invoiceDate;
    String referenceId;
    String extracNumber;
    public PaseCuotasRequest(){
    }

    public PaseCuotasRequest(String totalInstallments, String transactionCurrency, Integer documentType, String invoiceAmount, String invoiceDate, String referenceId, String extracNumber) {
        this.totalInstallments = totalInstallments;
        this.transactionCurrency = transactionCurrency;
        this.documentType = documentType;
        this.invoiceAmount = invoiceAmount;
        this.invoiceDate = invoiceDate;
        this.referenceId = referenceId;
        this.extracNumber = extracNumber;
    }

    public String getTotalInstallments() {
        return totalInstallments;
    }

    public void setTotalInstallments(String totalInstallments) {
        this.totalInstallments = totalInstallments;
    }

    public String getTransactionCurrency() {
        return transactionCurrency;
    }

    public void setTransactionCurrency(String transactionCurrency) {
        this.transactionCurrency = transactionCurrency;
    }

    public Integer getDocumentType() {
        return documentType;
    }

    public void setDocumentType(Integer documentType) {
        this.documentType = documentType;
    }

    public String getInvoiceAmount() {
        return invoiceAmount;
    }

    public void setInvoiceAmount(String invoiceAmount) {
        this.invoiceAmount = invoiceAmount;
    }

    public String getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(String invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public String getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(String referenceId) {
        this.referenceId = referenceId;
    }

    public String getExtracNumber() {
        return extracNumber;
    }

    public void setExtracNumber(String extracNumber) {
        this.extracNumber = extracNumber;
    }
}
