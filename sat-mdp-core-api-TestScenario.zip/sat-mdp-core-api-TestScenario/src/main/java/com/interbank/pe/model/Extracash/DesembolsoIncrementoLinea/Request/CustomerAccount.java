package com.interbank.pe.model.Extracash.DesembolsoIncrementoLinea.Request;
public class CustomerAccount {

    private AccountId accountId;
    private AccountNum accountNum;
    public AccountId getAccountId() {
        return accountId;
    }
    public void setAccountId(AccountId accountId) {
        this.accountId = accountId;
    }
    public AccountNum getAccountNum() {
        return accountNum;
    }
    public void setAccountNum(AccountNum accountNum) {
        this.accountNum = accountNum;
    }
}
