package com.interbank.pe.tasks.cliente.Cuenta;

import com.interbank.pe.model.cliente.cliente.RequestCrearCliente.Clientes;
import com.interbank.pe.model.cliente.cuentas.CuentaAhorros;
import com.interbank.pe.model.cliente.cuentas.response.Account;
import com.interbank.pe.questions.cliente.Cliente.ListarClientes;
import com.interbank.pe.questions.cliente.accounts.DatosDeLaCuenta;
import com.interbank.pe.questions.cliente.accounts.ListarClientesSinCuentaAhorro;
import com.interbank.pe.questions.cliente.accounts.ListarCuentasAhorro;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;

import java.util.List;
import java.util.Objects;

import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;

public class AltaMasivaCuentaAhorros implements Task {
    @Override
    public <T extends Actor> void performAs(T actor) {
        //Listar clientes sin cuenta de ahorros
            //Listar clientes

        //Alta cuenta de ahorros para los "<cantClientes>" si cuenta de ahorros
    }
}
