package com.interbank.pe.model.tarjeta.EstadoCuentaTarjetaCredito;

public class Cashdraw {
    private String anualRate;
    private String used;
    private String available;
    public String getAnualRate() {
        return anualRate;
    }
    public void setAnualRate(String anualRate) {
        this.anualRate = anualRate;
    }
    public String getUsed() {
        return used;
    }
    public void setUsed(String used) {
        this.used = used;
    }
    public String getAvailable() {
        return available;
    }
    public void setAvailable(String available) {
        this.available = available;
    }
}