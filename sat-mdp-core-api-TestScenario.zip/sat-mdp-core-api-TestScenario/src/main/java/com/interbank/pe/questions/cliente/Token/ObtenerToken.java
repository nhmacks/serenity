package com.interbank.pe.questions.cliente.Token;

import com.interbank.pe.model.cliente.Token.TokenResponse;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class ObtenerToken implements Question<TokenResponse> {
    @Override
    public TokenResponse answeredBy(Actor actor) {
        return SerenityRest.lastResponse().as(TokenResponse.class);
    }
}
