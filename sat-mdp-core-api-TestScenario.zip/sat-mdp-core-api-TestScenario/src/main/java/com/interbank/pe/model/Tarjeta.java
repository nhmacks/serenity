package com.interbank.pe.model;

import java.util.HashMap;

public class Tarjeta {
    public static HashMap<String, String> responseCollection = new HashMap<String, String>();

    public static String getResponseCollection(String key) {
        return responseCollection.get(key);
    }

    public static void setResponseCollection(String key, String value) {
        responseCollection.put(key, value);
    }
}
