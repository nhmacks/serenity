package com.interbank.pe.tasks.card;

import com.interbank.pe.model.MovimientosTC;
import io.restassured.mapper.ObjectMapperType;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Post;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class PagoDeServicio implements Task {
    private final Object request;
    private final String tarjetaCredito;
    private final String numeroMovimientoExtracto;

    public PagoDeServicio(Object request, String tarjetaCredito, String numeroMovimientoExtracto) {
        this.request = request;
        this.tarjetaCredito = tarjetaCredito;
        this.numeroMovimientoExtracto = numeroMovimientoExtracto;
    }

    public static PagoDeServicio EnCuotas(Object request, String tarjetaCredito, String numeroMovimientoExtracto) {
        return instrumented(PagoDeServicio.class,request, tarjetaCredito, numeroMovimientoExtracto);
    }

    @Override
    public <T extends Actor> void performAs(T theActor) {
        theActor.attemptsTo(
                Post.to("ibk/uat/api/credit-card/v2/" + tarjetaCredito + "/transaction/" + numeroMovimientoExtracto + "/to-installments")
                        .with(
                                request ->
                                        request
                                                .relaxedHTTPSValidation()
                                                .header("Content-Type", "application/json")
                                                .header("X-INT-Channel-Id", "BI")
                                                .header("X-INT-Device-Id", "SERVER01")
                                                .header("X-INT-Timestamp", "2022-07-21T14:46:56.128Z")
                                                .header("X-INT-Service-Id", "APA")
                                                .header("X-INT-Net-Id", "BI")
                                                .header("X-IBM-Client-Id", "a3a383ba-3d4d-4a35-a85e-0cd0f09eae26")
                                                .header("X-INT-Supervisor-Id", "APPA0000")
                                                .header("X-INT-Branch-Id", "898")
                                                .header("X-INT-Consumer-Id", "APP")
                                                .header("X-INT-Message-Id", "222")
                                                .header("X-INT-User-Id", "APPA0000")
                                                .header("X-INT-CardId-Type", "0")
                                                .header("Authorization", "Basic dUJzZUdlblVhdDpJYmsyMDE4JA==")
                                                .body(this.request, ObjectMapperType.GSON)
                        )
        );
    }
}