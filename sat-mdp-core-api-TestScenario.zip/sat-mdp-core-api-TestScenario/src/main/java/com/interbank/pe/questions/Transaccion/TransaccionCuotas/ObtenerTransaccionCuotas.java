package com.interbank.pe.questions.Transaccion.TransaccionCuotas;

import com.interbank.pe.model.Transaccion.TransaccionCuotas.TransaccionCuotas;
import io.restassured.mapper.ObjectMapperType;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class ObtenerTransaccionCuotas implements Question<TransaccionCuotas> {

    @Override
    public TransaccionCuotas answeredBy(Actor actor) {
        return SerenityRest.lastResponse().as(TransaccionCuotas.class, ObjectMapperType.GSON);
    }
}
