package com.interbank.pe.tasks.services;

import com.interbank.pe.model.MovimientosTC;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Get;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class ConsultaCuotasTransaccion implements Task {

    public ConsultaCuotasTransaccion() {
    }

    public static ConsultaCuotasTransaccion cliente() {
        return instrumented(ConsultaCuotasTransaccion.class);
    }

    @Override
    public <T extends Actor> void performAs(T theActor) {
        System.out.println("Card: "+MovimientosTC.getResponseCollection("card").trim());
        System.out.println("Num Movimiento: "+MovimientosTC.getResponseCollection("numeroMovimientoExtracto"));
        theActor.attemptsTo(
                Get.resource("ibk/uat/api/credit-card/v3/" + MovimientosTC.getResponseCollection("card").trim() + "/transactions/" + MovimientosTC.getResponseCollection("numeroMovimientoExtracto").trim() + "/installments")
                        .with(
                                request ->
                                        request
                                                .relaxedHTTPSValidation()
                                                .header("Content-Type", "application/json")
                                                .header("X-INT-Channel-Id", "BI")
                                                .header("X-INT-Device-Id", "SERVER01")
                                                .header("X-INT-Timestamp", "2022-07-21T14:46:56.128Z")
                                                .header("X-INT-Service-Id", "APA")
                                                .header("X-INT-Net-Id", "BI")
                                                .header("X-IBM-Client-Id", "2b22dc85-b740-4838-a7c8-b2bb7d225126")
                                                .header("X-INT-Supervisor-Id", "APPA0000")
                                                .header("X-INT-Branch-Id", "898")
                                                .header("X-INT-Consumer-Id", "APP")
                                                .header("X-INT-Message-Id", "222")
                                                .header("X-INT-User-Id", "APPA0000")
                                                .header("Authorization", "Basic dUJzZUFwcEFDbzpJYmt1YnNhY28xNw==")
                                                .header("Accept", "*/*")
                                                .header("Content-Type", "application/json")
                                                .header("X-INT-CardId-Type", "0")
                                                .queryParam("rowsNumber", 50)

                        )
        );
    }
}
