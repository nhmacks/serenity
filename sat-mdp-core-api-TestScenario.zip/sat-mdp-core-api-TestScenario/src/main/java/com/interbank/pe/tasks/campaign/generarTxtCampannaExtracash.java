package com.interbank.pe.tasks.campaign;

import com.interbank.pe.utils.enums.campanna.EnumCampannaExtracash;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Objects;

import static com.interbank.pe.utils.soap.EnumRequestSoap.CAMPANNA_EXTRACASH_TC_TXT;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class generarTxtCampannaExtracash implements Task {
    private final String file;
    private final String tipoDoc;
    private final String numeroDocumento;
    private final String codUnico;
    private final String primerNombre;
    private final String segundoNombre;
    private final String apellidoPaterno;
    private final String apellidoMaterno;
    private final String numeroTarjeta;
    private final String marcaTarjeta;
    private final String tipoTarjeta;
    private final String monto;
    private final String tipoCliente;
    private final String montoTrack;
    private final String orden;
    private final String descripcionMarcaTarjeta;
    private final String descripcionTipoTarjeta;

    public generarTxtCampannaExtracash(String file, String tipoDoc, String numeroDocumento, String codUnico, String primerNombre, String segundoNombre, String apellidoPaterno, String apellidoMaterno, String numeroTarjeta, String marcaTarjeta, String tipoTarjeta, String monto, String tipoCliente, String montoTrack, String orden, String descripcionMarcaTarjeta, String descripcionTipoTarjeta) {
        this.file = file;
        this.tipoDoc = tipoDoc;
        this.numeroDocumento = numeroDocumento;
        this.codUnico = codUnico;
        this.primerNombre = primerNombre;
        this.segundoNombre = segundoNombre;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.numeroTarjeta = numeroTarjeta;
        this.marcaTarjeta = marcaTarjeta;
        this.tipoTarjeta = tipoTarjeta;
        this.monto = monto;
        this.tipoCliente = tipoCliente;
        this.montoTrack = montoTrack;
        this.orden = orden;
        this.descripcionMarcaTarjeta = descripcionMarcaTarjeta;
        this.descripcionTipoTarjeta = descripcionTipoTarjeta;
    }

    public static generarTxtCampannaExtracash porTarjeta(String file, String tipoDoc, String numeroDocumento, String codUnico, String primerNombre, String segundoNombre, String apellidoPaterno, String apellidoMaterno, String numeroTarjeta, String marcaTarjeta, String tipoTarjeta, String monto, String tipoCliente, String montoTrack, String orden, String descripcionMarcaTarjeta, String descripcionTipoTarjeta) {
        return instrumented(generarTxtCampannaExtracash.class, file, tipoDoc, numeroDocumento, codUnico, primerNombre, segundoNombre, apellidoPaterno, apellidoMaterno, numeroTarjeta, marcaTarjeta, tipoTarjeta, monto, tipoCliente, montoTrack, orden, descripcionMarcaTarjeta, descripcionTipoTarjeta);
    }

    @Override
    public <T extends Actor> void performAs(T t) {
        String rutaArchivo1 = CAMPANNA_EXTRACASH_TC_TXT.getPathArchivo() + file;

        File archivo1 = new File(rutaArchivo1);

        if (archivo1.exists()) {
            editarArchivo(archivo1);
        } else {
            crearArchivo(archivo1);
        }

    }

    private void crearArchivo(File archivo) {
        try {
            if (archivo.createNewFile()) {
                System.out.println("Se ha creado el archivo SBL_CAMPANNA_TXT " + archivo.getName());
                insertarDatosEnArchivo(archivo, "1");
            } else {
                System.out.println("No se pudo crear el archivo SBL_CAMPANNA_TXT ");
            }
        } catch (IOException e) {
            System.out.println("Se produjo un error al crear el archivo SBL_CAMPANNA_TXT ");
            e.printStackTrace();
        }
    }

    private void editarArchivo(File archivo) {
        insertarDatosEnArchivo(archivo, "0");
    }

    private void insertarDatosEnArchivo(File archivo, String numFila) {
        try {
            FileWriter fileWriter = new FileWriter(archivo, true); // true indica que se agregara contenido al final del archivo
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

            Integer codigoUnico = Integer.valueOf(this.codUnico);
            String codigoCampaign = EnumCampannaExtracash.CODIGO_CAMPANNA.getValor();
            String tiendaSectorizada = EnumCampannaExtracash.TIENDA_SECTORIZADA.getValor();
            String rangoEjecutivo = "";
            String registroEjecutivo = "";
            String Region = "";
            String codigoTratamiento = EnumCampannaExtracash.CODIGO_TRATAMIENTO.getValor();
            String tipoDoc = this.tipoDoc;
            String numeroDocumento = this.numeroDocumento;
            String codUnico = String.valueOf(codigoUnico);
            String primerNombre = this.primerNombre;
            String segundoNombre = this.segundoNombre;
            String apellidoPaterno = this.apellidoPaterno;
            String apellidoMaterno = this.apellidoMaterno;
            String tipoTelefono1 = "";
            String codigoCiudad1 = "";
            String nroTelefono1 = "";
            String tipoTelefono2 = "";
            String codigoCiudad2 = "";
            String nroTelefono2 = "";
            String tipoTelefono3 = "";
            String codigoCiudad3 = "";
            String nroTelefono3 = "";
            String tipoTelefono4 = "";
            String codigoCiudad4 = "";
            String nroTelefono4 = "";
            String tipoTelefono5 = "";
            String codigoCiudad5 = "";
            String nroTelefono5 = "";
            String tipoTelefono6 = "";
            String codigoCiudad6 = "";
            String nroTelefono6 = "";
            String tipoTelefono7 = "";
            String codigoCiudad7 = "";
            String nroTelefono7 = "";
            String tipoTelefono8 = "";
            String codigoCiudad8 = "";
            String nroTelefono8 = "";
            String tipoTelefono9 = "";
            String codigoCiudad9 = "";
            String nroTelefono9 = "";
            String tipoTelefono10 = "";
            String codigoCiudad10 = "";
            String nroTelefono10 = "";
            String tipoEmail = "";
            String email = "";
            String tipoDireccion = "";
            String tipoviaCod = "";
            String nombreVia = "";
            String nroMz = "";
            String pisoOLote = "";
            String interior = "";
            String numero = "";
            String urbanizacion = "";
            String referencia = "";
            String codigoPostal = "";
            String ubigeo = "";
            String codDepartamento = "";
            String codProvincia = "";
            String codDistrito = "";
            String rucEmpresa = "";
            String nombreEmpresa = "";
            String familia = "";
            String telefonoEmpresa = "";
            String valor01 = EnumCampannaExtracash.VALOR_01.getValor();
            String valor02 = this.numeroTarjeta;
            String valor03 = "";
            String valor04 = "";
            String valor05 = "";
            String valor06 = "";
            String valor07 = "";
            String valor08 = "";
            String valor09 = "";
            String valor10 = "";
            String valor11 = "";
            String valor12 = "";
            String valor13 = "";
            String valor14 = "";
            String valor15 = "";
            String valor16 = "";
            String valor17 = "";
            String valor18 = "";
            String valor19 = "";
            String valor20 = "";
            String valor21 = "";
            String valor22 = "";
            String valor23 = "";
            String valor24 = "";
            String valor25 = "";
            String tipoOferta = EnumCampannaExtracash.TIPO_OFERTA.getValor();
            String marcaTarjeta = this.marcaTarjeta;
            String tipoTarjeta = this.tipoTarjeta;
            String idMoneda = EnumCampannaExtracash.ID_MONEDA.getValor();
            String monto = resultadoExtracash();
            String tasa1 = EnumCampannaExtracash.TASA1.getValor();
            String tasa2 = EnumCampannaExtracash.TASA2.getValor();
            String tipoCliente = this.tipoCliente;
            String Cem = EnumCampannaExtracash.CEM.getValor();
            String plazoMaximo = EnumCampannaExtracash.PLAZO_MAXIMO.getValor();
            String fuenteOrigen = "";
            String numeroTarjeta = this.numeroTarjeta;
            String nroConvenio = "";
            String nroSubConvenio = "";
            String merchandising = EnumCampannaExtracash.MERCHANDISING.getValor();
            String campoLibre1 = EnumCampannaExtracash.CAMPO_LIBRE_1.getValor();
            String campoLibre2 = "";
            String campoLibre3 = EnumCampannaExtracash.CAMPO_LIBRE_3.getValor();
            String campoLibre4 = EnumCampannaExtracash.CAMPO_LIBRE_4.getValor();
            String campoLibre5 = EnumCampannaExtracash.CAMPO_LIBRE_5.getValor();
            String monto2 = "";
            String renta = EnumCampannaExtracash.RENTA.getValor();
            String flujoIngreso = EnumCampannaExtracash.FLUJO_INGRESO.getValor();
            String segmentoGenesys = "";
            String particion = "";
            String tipoBase = "";
            String propension = "";
            String rangoLinea = "";
            String codigoInterno = "";
            String nroCuenta = "";
            String montoTrack = resultadoExtracash();
            String orden = this.orden;
            String flagRegistro = EnumCampannaExtracash.FLAG_REGISTRO.getValor();
            String descripcionMarcaTarjeta = this.descripcionMarcaTarjeta;
            String descripcionTipoTarjeta = this.descripcionTipoTarjeta;
            String codigoPlan = "";
            String descripcionPlanSeguro = "";
            String codigoPeriodoPlanSeguro = "";
            String descripcionPeriodoPlanSeguro = "";
            String montoPrima = "";
            String codigoMonedaInternacional = "";
            String codigoDeProductoSeguroBAIS = "";
            String simboloMoneda = EnumCampannaExtracash.SIMBOLO_MONEDA.getValor();
            String descripcionMoneda = EnumCampannaExtracash.DESCRIPCION_MONEDA.getValor();
            String campoAdicional1 = "";
            String campoAdicional2 = "";
            String campoAdicional3 = "";
            String campoAdicional4 = "";
            String campoAdicional5 = "";
            String campoAdicional6 = "";
            String campoAdicional7 = "";
            String campoAdicional8 = "";
            String campoAdicional9 = "";
            String campoAdicional10 = "";
            String lineaActualProducto = "";
            String valorCuota = "";
            String cantidadCuotas = "";
            String prioridadCanalPresencial = EnumCampannaExtracash.PRIORIDAD_CANAL_PRESENCIAL.getValor();
            String prioridadCanal = EnumCampannaExtracash.PRIORIDAD_CANAL.getValor();
            String segmentoCP = EnumCampannaExtracash.SEGMENTO_CP.getValor();
            String flagAM = EnumCampannaExtracash.FLAG_AM.getValor();

            String newData = codigoCampaign + "|" + tiendaSectorizada + "|" + rangoEjecutivo + "|" + registroEjecutivo + "|" + Region + "|" + codigoTratamiento + "|" + tipoDoc + "|" + numeroDocumento + "|" + codUnico + "|" + primerNombre + "|" + segundoNombre + "|" + apellidoPaterno + "|" + apellidoMaterno + "|" + tipoTelefono1 + "|" + codigoCiudad1 + "|" + nroTelefono1 + "|" + tipoTelefono2 + "|" + codigoCiudad2 + "|" + nroTelefono2 + "|" + tipoTelefono3 + "|" + codigoCiudad3 + "|" + nroTelefono3 + "|" + tipoTelefono4 + "|" + codigoCiudad4 + "|" + nroTelefono4 + "|" + tipoTelefono5 + "|" + codigoCiudad5 + "|" + nroTelefono5 + "|" + tipoTelefono6 + "|" + codigoCiudad6 + "|" + nroTelefono6 + "|" + tipoTelefono7 + "|" + codigoCiudad7 + "|" + nroTelefono7 + "|" + tipoTelefono8 + "|" + codigoCiudad8 + "|" + nroTelefono8 + "|" + tipoTelefono9 + "|" + codigoCiudad9 + "|" + nroTelefono9 + "|" + tipoTelefono10 + "|" + codigoCiudad10 + "|" + nroTelefono10 + "|" + tipoEmail + "|" + email + "|" + tipoDireccion + "|" + tipoviaCod + "|" + nombreVia + "|" + nroMz + "|" + pisoOLote + "|" + interior + "|" + numero + "|" + urbanizacion + "|" + referencia + "|" + codigoPostal + "|" + ubigeo + "|" + codDepartamento + "|" + codProvincia + "|" + codDistrito + "|" + rucEmpresa + "|" + nombreEmpresa + "|" + familia + "|" + telefonoEmpresa + "|" + valor01 + "|" + valor02 + "|" + valor03 + "|" + valor04 + "|" + valor05 + "|" + valor06 + "|" + valor07 + "|" + valor08 + "|" + valor09 + "|" + valor10 + "|" + valor11 + "|" + valor12 + "|" + valor13 + "|" + valor14 + "|" + valor15 + "|" + valor16 + "|" + valor17 + "|" + valor18 + "|" + valor19 + "|" + valor20 + "|" + valor21 + "|" + valor22 + "|" + valor23 + "|" + valor24 + "|" + valor25 + "|" + tipoOferta + "|" + marcaTarjeta + "|" + tipoTarjeta + "|" + idMoneda + "|" + monto + "|" + tasa1 + "|" + tasa2 + "|" + tipoCliente + "|" + Cem + "|" + plazoMaximo + "|" + fuenteOrigen + "|" + numeroTarjeta + "|" + nroConvenio + "|" + nroSubConvenio + "|" + merchandising + "|" + campoLibre1 + "|" + campoLibre2 + "|" + campoLibre3 + "|" + campoLibre4 + "|" + campoLibre5 + "|" + monto2 + "|" + renta + "|" + flujoIngreso + "|" + segmentoGenesys + "|" + particion + "|" + tipoBase + "|" + propension + "|" + rangoLinea + "|" + codigoInterno + "|" + nroCuenta + "|" + montoTrack + "|" + orden + "|" + flagRegistro + "|" + descripcionMarcaTarjeta + "|" + descripcionTipoTarjeta + "|" + codigoPlan + "|" + descripcionPlanSeguro + "|" + codigoPeriodoPlanSeguro + "|" + descripcionPeriodoPlanSeguro + "|" + montoPrima + "|" + codigoMonedaInternacional + "|" + codigoDeProductoSeguroBAIS + "|" + simboloMoneda + "|" + descripcionMoneda + "|" + campoAdicional1 + "|" + campoAdicional2 + "|" + campoAdicional3 + "|" + campoAdicional4 + "|" + campoAdicional5 + "|" + campoAdicional6 + "|" + campoAdicional7 + "|" + campoAdicional8 + "|" + campoAdicional9 + "|" + campoAdicional10 + "|" + lineaActualProducto + "|" + valorCuota + "|" + cantidadCuotas + "|" + prioridadCanalPresencial + "|" + prioridadCanal + "|" + segmentoCP + "|" + flagAM;
            if (!Objects.equals(numFila, "1")) {
                bufferedWriter.newLine();
            }
            bufferedWriter.write(newData);
            bufferedWriter.close();
            fileWriter.close();

            System.out.println("TXT carga campanna Extracash actualizado, successfully!");
        } catch (IOException e) {
            System.out.println("Se produjo un error al insertar datos en el archivo.");
            e.printStackTrace();
        }
    }


    private String resultadoExtracash() {
        double valorNum = Double.parseDouble(this.monto);
        DecimalFormat formato = new DecimalFormat("#.##");
        double resultadoNum = valorNum * 2;
        String valorFormateado = formato.format(resultadoNum);
        return valorFormateado + ".00";
    }

}
