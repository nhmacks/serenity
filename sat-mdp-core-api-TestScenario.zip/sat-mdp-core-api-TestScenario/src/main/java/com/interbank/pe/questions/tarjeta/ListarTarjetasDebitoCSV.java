package com.interbank.pe.questions.tarjeta;

import com.interbank.pe.model.tarjeta.ClientesConTarjetaDebito;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.interbank.pe.utils.soap.EnumRequestSoap.DATA_DISPOSCIONEFECTIVO;
import static com.interbank.pe.utils.soap.UtilsTarjeta.existsValue;

public class ListarTarjetasDebitoCSV implements Question {


    @Override
    public List<ClientesConTarjetaDebito> answeredBy(Actor actor) {
        String filePath = DATA_DISPOSCIONEFECTIVO.getPathArchivo();
        String line = "";
        String cvsSplitBy = ",";
        List<ClientesConTarjetaDebito> tarjeta = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            int contador = 0;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(cvsSplitBy);
                if (contador > 0) {
                    ClientesConTarjetaDebito tarjeta1 = new ClientesConTarjetaDebito(
                            existsValue(data, 0) ? data[0] : "",
                            existsValue(data, 1) ? data[1] : "",
                            existsValue(data, 2) ? data[2] : "",
                            existsValue(data, 3) ? data[3] : "",
                            existsValue(data, 4) ? data[4] : "",
                            existsValue(data, 5) ? data[5] : "",
                            existsValue(data, 6) ? data[6] : "",
                            existsValue(data, 7) ? data[7] : "",
                            existsValue(data, 8) ? data[8] : ""
                    );
                    tarjeta.add(tarjeta1);

                }
                contador++;
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return tarjeta;
    }
}

