package com.interbank.pe.tasks.services;

import com.interbank.pe.model.MovimientosTC;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Post;

import java.io.IOException;

import static com.interbank.pe.utils.soap.EnumRequestSoap.DISPOSICION_EFECTIVO;
import static com.interbank.pe.utils.soap.UtilisSoap.obtenerRequestSoap;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class DispocicionDeEfectivo implements Task {

    private final String tarjeta;
    private final String cu;
    private final String cargoMoneda;
    private final String cargoCuenta;
    private final String abonoMoneda;
    private final String abonoCuenta;
    private final String referenceId;
    private final String trxImporte;
    private final String trxMoneda;
    private final String clave;

    public DispocicionDeEfectivo(String tarjeta, String cu, String cargoMoneda,
                                 String cargoCuenta, String abonoMoneda, String abonoCuenta,
                                 String referenceId, String trxImporte, String trxMoneda, String clave) {
        this.tarjeta = tarjeta;
        this.cu = cu;
        this.cargoMoneda = cargoMoneda;
        this.cargoCuenta = cargoCuenta;
        this.abonoMoneda = abonoMoneda;
        this.abonoCuenta = abonoCuenta;
        this.referenceId = referenceId;
        this.trxImporte = trxImporte;
        this.trxMoneda = trxMoneda;
        this.clave = clave;
    }

    public static DispocicionDeEfectivo conCargoEnTC(String tarjeta, String cu, String cargoMoneda,
                                                     String cargoCuenta, String abonoMoneda, String abonoCuenta,
                                                     String referenceId, String trxImporte, String trxMoneda,
                                                     String clave) {
        return instrumented(DispocicionDeEfectivo.class, tarjeta, cu, cargoMoneda, cargoCuenta, abonoMoneda,
                abonoCuenta, referenceId, trxImporte, trxMoneda, clave);
    }

    @Override
    public <T extends Actor> void performAs(T theActor) {
        theActor.attemptsTo(
                Post.to("ib/bus/srv/soap/excelsys.enviarOperacionAPP")
                        .with(
                                request ->
                                        request
                                                .relaxedHTTPSValidation()
                                                .header("SOAPAction", "http://interbank.com.pe/bus/service/interface/excelsys/enviarOperacionBPI/v1.0/")
                                                .header("Content-Type", "text/plain")
                                                .header("Content-Type", "text/xml; charset=ISO-8859-1")
                                                .body(ObtenerRequestDisposicionEfetivo())
                        )
        );
        MovimientosTC.setResponseCollection("card", cargoCuenta);
        MovimientosTC.setResponseCollection("amount", trxImporte);
        MovimientosTC.setResponseCollection("currency", trxMoneda);
    }

    private String ObtenerRequestDisposicionEfetivo() {
        try {
            return obtenerRequestSoap(DISPOSICION_EFECTIVO.getPathArchivo())
                    .replace("PAR_NROTARJETA", tarjeta)
                    .replace("PAR_CODUNICO", cu)
                    .replace("PAR_CLAVE", Clave(clave))
                    .replace("PAR_CARGOMONEDA", cargoMoneda)
                    .replace("PAR_CARGOCUENTA", cargoCuenta)
                    .replace("PAR_ABONOMONEDA", abonoMoneda)
                    .replace("PAR_ABONOCUENTA", abonoCuenta)
                    .replace("PAR_TRXIMPORTE", trxImporte)
                    .replace("PAR_TRXMONEDA", trxMoneda);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private String Clave(String Clave) {
        if (Clave.equals("A11111")) {
            return "EE6CF9FF1B450D57F9E749E3602892C11683F09544C76B1E0E8A433C4CC28CA81C0958901969AED0";
        } else if (Clave.equals("A111111")) {
            return "56AE41F8A2CAF13D43055F5DDF7C7DD1B047F6D66A60D4ACB39B4A1554594C111FD67AB6FFFC7D61";
        }
        return Clave;
    }
}
