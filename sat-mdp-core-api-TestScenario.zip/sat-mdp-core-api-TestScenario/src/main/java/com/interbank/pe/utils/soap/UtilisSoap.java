package com.interbank.pe.utils.soap;

import org.apache.commons.io.IOUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;

public class UtilisSoap {
    public static String obtenerRequestSoap(String path) throws IOException {
        String content;
        try {
            content = IOUtils.toString(Files.newInputStream(Paths.get(path)), StandardCharsets.UTF_8);
        } catch (Exception e) {
            throw e;
        }
        return content;
    }

    public static String obtenerValorEtiquetaXML(String xml, String etiquetaXml)
            throws IOException, SAXException, ParserConfigurationException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.parse(new InputSource(new StringReader(xml)));
        Element rootElement = document.getDocumentElement();
        NodeList list = rootElement.getElementsByTagName(etiquetaXml);
        if (list != null && list.getLength() > 0) {
            NodeList subList = list.item(0).getChildNodes();
            if (subList != null && subList.getLength() > 0) {
                return subList.item(0).getNodeValue();
            }
        }
        return null;
    }


    public static String obtenerEtiquetaXML(String xml, String xPathExpression)
            throws IOException, SAXException, ParserConfigurationException, XPathExpressionException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.parse(new InputSource(new StringReader(xml)));

        XPath xpath = XPathFactory.newInstance().newXPath();
        NodeList nodos = (NodeList) xpath.evaluate(xPathExpression, document, XPathConstants.NODESET);

        for (int i = 0; i < nodos.getLength(); i++) {
            System.out.println(nodos.item(i).getNodeName() + " : " +
                    nodos.item(i).getAttributes().getNamedItem("nombre"));
        }
        return null;
    }

    public static HashMap<String, String> obtengoDetallesDeLaRespuesta(String responseTramaString, String tramaIndex) {
        String response = responseTramaString;

        String start = "<" + tramaIndex + ">";
        String end = "</" + tramaIndex + ">";

        String trama1 = response.substring(
                response.indexOf(start),
                response.indexOf(end) + 11
        );

        String[] atributos = trama1.split("\n");
        HashMap<String, String> map = new HashMap<>();

        for (String f : atributos) {
            try {
                String key = f.substring(f.indexOf("<") + 1);
                String value = key.substring(key.indexOf(">") + 1);
                map.put(key.substring(0, key.indexOf(">")), value.substring(0, value.indexOf("<")));
            } catch (Exception e) {
            }
        }

        return map;
    }
}
