package com.interbank.pe.model.tarjeta.MovimientosDeTC;

public class V4HeaderResponse {
    private String timestamp;
    private Status status;
    public String getTimestamp() {
        return timestamp;
    }
    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
    public Status getStatus() {
        return status;
    }
    public void setStatus(Status status) {
        this.status = status;
    }
}