package com.interbank.pe.model.cliente.cuentas;

public class CuentaAhorros {
    String codCliente;
    String moneda;
    String productoCuenta;
    String tipoCuenta;
    String individual;
    String numCuentaAhorro;
    String codCuentaInterbancaria;
    String flagCuenta;
    String fechaCreacion;

    public CuentaAhorros(String codCliente, String moneda, String productoCuenta, String tipoCuenta, String individual, String numCuentaAhorro, String codCuentaInterbancaria, String flagCuenta, String fechaCreacion) {
        this.codCliente = codCliente;
        this.moneda = moneda;
        this.productoCuenta = productoCuenta;
        this.tipoCuenta = tipoCuenta;
        this.individual = individual;
        this.numCuentaAhorro = numCuentaAhorro;
        this.codCuentaInterbancaria = codCuentaInterbancaria;
        this.flagCuenta = flagCuenta;
        this.fechaCreacion = fechaCreacion;
    }

    public String getCodCliente() {
        return codCliente;
    }

    public void setCodCliente(String codCliente) {
        this.codCliente = codCliente;
    }

    public String getMoneda() {
        return moneda;
    }

    public void setMoneda(String moneda) {
        this.moneda = moneda;
    }

    public String getProductoCuenta() {
        return productoCuenta;
    }

    public void setProductoCuenta(String productoCuenta) {
        this.productoCuenta = productoCuenta;
    }

    public String getTipoCuenta() {
        return tipoCuenta;
    }

    public void setTipoCuenta(String tipoCuenta) {
        this.tipoCuenta = tipoCuenta;
    }

    public String getIndividual() {
        return individual;
    }

    public void setIndividual(String individual) {
        this.individual = individual;
    }

    public String getNumCuentaAhorro() {
        return numCuentaAhorro;
    }

    public void setNumCuentaAhorro(String numCuentaAhorro) {
        this.numCuentaAhorro = numCuentaAhorro;
    }

    public String getCodCuentaInterbancaria() {
        return codCuentaInterbancaria;
    }

    public void setCodCuentaInterbancaria(String codCuentaInterbancaria) {
        this.codCuentaInterbancaria = codCuentaInterbancaria;
    }

    public String getFlagCuenta() {
        return flagCuenta;
    }

    public void setFlagCuenta(String flagCuenta) {
        this.flagCuenta = flagCuenta;
    }

    public String getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(String fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    @Override
    public String toString() {
        return "ListaCuentasCliente{" +
                "codCliente='" + codCliente + '\'' +
                ", moneda='" + moneda + '\'' +
                ", productoCuenta='" + productoCuenta + '\'' +
                ", tipoCuenta='" + tipoCuenta + '\'' +
                ", individual='" + individual + '\'' +
                ", numCuentaAhorro='" + numCuentaAhorro + '\'' +
                ", codCuentaInterbancaria='" + codCuentaInterbancaria + '\'' +
                ", flagCuenta='" + flagCuenta + '\'' +
                '}';
    }
}
