package com.interbank.pe.tasks.card.debito;

import com.interbank.pe.model.cliente.cliente.RequestCrearCliente.Cliente;
import com.interbank.pe.model.tarjeta.ClientesConTarjetaDebito;
import com.interbank.pe.questions.tarjeta.ListarTarjetasDebitoCSV;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.Task;

import java.util.List;

import static net.serenitybdd.screenplay.Tasks.instrumented;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;


public class ListaClientesconTD implements Task{

    String tarjetaDebito;
    String claveWeb;
    String codigoUnico;
    String cargoMoneda;
    String tarjetaCredito;

    String abonoMoneda;
    String abonoCuenta;
    String importeTransferencia;
    String monedaTransferencia;


    public static ListaClientesconTD Activado(){
        return instrumented(ListaClientesconTD.class);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        List<ClientesConTarjetaDebito> ListarTarjetasDebito = new ListarTarjetasDebitoCSV().answeredBy(actor);
        for (ClientesConTarjetaDebito ClientesConTarjetaDebito : ListarTarjetasDebito) {
            this.tarjetaDebito = ClientesConTarjetaDebito.gettarjetaDebito();
            this.claveWeb = ClientesConTarjetaDebito.getclaveWeb();
            this.codigoUnico = ClientesConTarjetaDebito.getcodigoUnico();
            this.cargoMoneda = ClientesConTarjetaDebito.getcargoMoneda();
            this.tarjetaCredito = ClientesConTarjetaDebito.gettarjetaCredito();
            this.abonoMoneda = ClientesConTarjetaDebito.getabonoMoneda();
            this.abonoCuenta = ClientesConTarjetaDebito.getabonoCuenta();
            this.importeTransferencia = ClientesConTarjetaDebito.getimporteTransferencia();
            this.monedaTransferencia = ClientesConTarjetaDebito.getmonedaTransferencia();
            theActorInTheSpotlight().remember("tarjetaDebito", tarjetaDebito);
            theActorInTheSpotlight().remember("claveWeb", claveWeb);
            theActorInTheSpotlight().remember("codigoUnico", codigoUnico);
            theActorInTheSpotlight().remember("cargoMoneda", cargoMoneda);
            theActorInTheSpotlight().remember("tarjetaCredito", tarjetaCredito);
            theActorInTheSpotlight().remember("abonoMoneda", abonoMoneda);
            theActorInTheSpotlight().remember("abonoCuenta", abonoCuenta);
            theActorInTheSpotlight().remember("importeTransferencia", importeTransferencia);
            theActorInTheSpotlight().remember("monedaTransferencia", monedaTransferencia);
            break;
        }
    }
}
