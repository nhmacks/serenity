package com.interbank.pe.model.tarjeta;

public class Tarjeta {
    private String contrato;
    private String customerType;
    private String card;
    private String marcaTC;
    private String tipoTC;
    private String producto;
    private String descripcionProducto;
    private String condicionEconomica;
    private String lineaCredito;
    private String lineaCreditoMax;
    private String fechaCreacionTC;
    private String fechaActivacionTC;
    private String flagActivacionTC;
    private String flagCampanaExtracash;
    private String fechaAdquisicionCampana;

    public Tarjeta(String contrato, String customerType, String card, String marcaTC, String tipoTC, String producto, String descripcionProducto, String condicionEconomica, String lineaCredito, String lineaCreditoMax, String fechaCreacionTC, String fechaActivacionTC, String flagActivacionTC, String flagCampanaExtracash, String fechaAdquisicionCampana) {
        this.contrato = contrato;
        this.customerType = customerType;
        this.card = card;
        this.marcaTC = marcaTC;
        this.tipoTC = tipoTC;
        this.producto = producto;
        this.descripcionProducto = descripcionProducto;
        this.condicionEconomica = condicionEconomica;
        this.lineaCredito = lineaCredito;
        this.lineaCreditoMax = lineaCreditoMax;
        this.fechaCreacionTC = fechaCreacionTC;
        this.fechaActivacionTC = fechaActivacionTC;
        this.flagActivacionTC = flagActivacionTC;
        this.flagCampanaExtracash = flagCampanaExtracash;
        this.fechaAdquisicionCampana = fechaAdquisicionCampana;
    }

    public String getContrato() {
        return contrato;
    }

    public void setContrato(String contrato) {
        this.contrato = contrato;
    }

    public String getCustomerType() {
        return customerType;
    }

    public void setCustomerType(String customerType) {
        this.customerType = customerType;
    }

    public String getCard() {
        return card;
    }

    public void setCard(String card) {
        this.card = card;
    }

    public String getMarcaTC() {
        return marcaTC;
    }

    public void setMarcarTC(String marcaTC) {
        this.marcaTC = marcaTC;
    }

    public String getTipoTC() {
        return tipoTC;
    }

    public void setTipoTC(String tipoTC) {
        this.tipoTC = tipoTC;
    }

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public String getDescription() {
        return descripcionProducto;
    }

    public String getCondicionEconomica() {
        return condicionEconomica;
    }

    public void setDescription(String descripcionProducto) {
        this.descripcionProducto = descripcionProducto;
    }

    public void setCondicionEconomica(String condicionEconomica) {
        this.condicionEconomica = condicionEconomica;
    }

    public String getlineaCredito() {
        return lineaCredito;
    }

    public void setlineaCredito(String lineaCredito) {
        this.lineaCredito = lineaCredito;
    }

    public String getlineaCreditoMax() {
        return lineaCreditoMax;
    }

    public void setlineaCreditoMax(String lineaCreditoMax) {
        this.lineaCreditoMax = lineaCreditoMax;
    }

    public String getfechaCreacionTC() {
        return fechaCreacionTC;
    }

    public void setfechaCreacionTC(String fechaCreacionTC) {
        this.fechaCreacionTC = fechaCreacionTC;
    }

    public String getfechaActivacionTC() {
        return fechaActivacionTC;
    }

    public void setfechaActivacionTC(String fechaActivacionTC) {
        this.fechaActivacionTC = fechaActivacionTC;
    }

    public String getflagActivacionTC() {
        return flagActivacionTC;
    }

    public void setflagActivacionTC(String flagActivacionTC) {
        this.flagActivacionTC = flagActivacionTC;
    }

    public String getFlagCampanaExtracash() {
        return flagCampanaExtracash;
    }

    public void setFlagCampanaExtracash(String flagCampanaExtracash) {
        this.flagCampanaExtracash = flagCampanaExtracash;
    }

    public String getfechaAdquisicionCampana() {
        return fechaAdquisicionCampana;
    }

    public void setfechaAdquisicionCampana(String fechaAdquisicionCampana) {
        this.fechaAdquisicionCampana = fechaAdquisicionCampana;
    }
}