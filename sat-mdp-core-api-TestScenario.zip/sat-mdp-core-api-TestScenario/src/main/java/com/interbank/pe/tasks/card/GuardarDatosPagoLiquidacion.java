package com.interbank.pe.tasks.card;

import com.interbank.pe.model.Tarjeta;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import static net.serenitybdd.screenplay.Tasks.instrumented;
public class GuardarDatosPagoLiquidacion implements Task {
    @Override
    public <T extends Actor> void performAs(T actor) {
        Tarjeta.setResponseCollection("ContractNumber", SerenityRest.lastResponse().jsonPath().getJsonObject("account.contractNumber"));
        Tarjeta.setResponseCollection("AntespagoMinimoSoles",SerenityRest.lastResponse().jsonPath().getJsonObject("payment.minimumAmountSoles"));
        Tarjeta.setResponseCollection("AntespagoMinimoDolares",SerenityRest.lastResponse().jsonPath().getJsonObject("payment.minimumAmountDollars"));
        Tarjeta.setResponseCollection("AntespagoTotalSoles",SerenityRest.lastResponse().jsonPath().getJsonObject("payment.totalAmountSoles"));
        Tarjeta.setResponseCollection("AntespagoTotalDolares",SerenityRest.lastResponse().jsonPath().getJsonObject("payment.totalAmountDollars"));
        System.out.println("=======================================================================");
        System.out.println("ContractNumber: "+Tarjeta.getResponseCollection("ContractNumber"));
        System.out.println("Pago Minimo Soles : "+Tarjeta.getResponseCollection("AntespagoMinimoSoles"));
        System.out.println("Pago Minimo Dolares : "+Tarjeta.getResponseCollection("AntespagoMinimoDolares"));
        System.out.println("Pago Total Soles : "+Tarjeta.getResponseCollection("AntespagoTotalSoles"));
        System.out.println("Pago Total Dolares : "+Tarjeta.getResponseCollection("AntespagoTotalDolares"));
        System.out.println("=======================================================================");
    }

    public static GuardarDatosPagoLiquidacion deLaTC(){
        return instrumented(GuardarDatosPagoLiquidacion.class);
    }
    }

