package com.interbank.pe.tasks.cliente.Cliente;

import com.interbank.pe.model.Tarjeta;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.joda.time.LocalDateTime;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import static com.interbank.pe.utils.soap.EnumRequestSoap.CLIENTE;
import static net.serenitybdd.screenplay.Tasks.instrumented;
public class GuardarDatosCliente implements Task {

    public static GuardarDatosCliente enArchivoCSV(){
        return instrumented(GuardarDatosCliente.class);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        String idCliente = String.valueOf(SerenityRest.lastResponse().getBody().jsonPath().get("MessageResponse.Body.crearClienteResponse.codigoUnicoCliente").toString());
        String filePath = CLIENTE.getPathArchivo();
        try {
            File csvFile = new File(filePath);
            FileReader csvReader = new FileReader(csvFile);
            CSVParser parser = new CSVParser(csvReader, CSVFormat.DEFAULT);
            FileWriter csvWriter = new FileWriter(csvFile, true);
            CSVPrinter printer = new CSVPrinter(csvWriter, CSVFormat.DEFAULT);
            LocalDateTime dateTime = LocalDateTime.now();
            String tipoDocumento = Tarjeta.getResponseCollection("tipoDocumento");
            String numeroDocumento = Tarjeta.getResponseCollection("NumeroDocumento");
            String primerNombre = Tarjeta.getResponseCollection("primerNombre");
            String segundoNombre = Tarjeta.getResponseCollection("segundoNombre");
            String primerApellido = Tarjeta.getResponseCollection("primerApellido");
            String segundoApellido = Tarjeta.getResponseCollection("segundoApellido");

            List<String> newData = Arrays.asList(tipoDocumento,numeroDocumento, primerNombre, segundoNombre, primerApellido, segundoApellido,idCliente,dateTime.toString());
            printer.printRecord(newData);
            parser.close();
            printer.close();
            csvReader.close();
            csvWriter.close();
            System.out.println("CSV file created successfully!");
        } catch (IOException e) {
            System.out.println("Error creating CSV file: " + e.getMessage());
        };
    }
}
