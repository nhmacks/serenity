package com.interbank.pe.tasks.campaign;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import org.joda.time.LocalDateTime;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import static com.interbank.pe.utils.soap.EnumRequestSoap.CLIENTE_TARJETA;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class ActualizarCampanna implements Task {
    private final String numeroTarjeta;
    public ActualizarCampanna(String numeroTarjeta) {
        this.numeroTarjeta = numeroTarjeta;
    }
    public static ActualizarCampanna comoActivada(String numeroTarjeta){
        return instrumented(ActualizarCampanna.class,numeroTarjeta);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        String filePath = CLIENTE_TARJETA.getPathArchivo();

        try {
            // Lectura del archivo CSV
            BufferedReader br = new BufferedReader(new FileReader(filePath));
            String line;
            StringBuilder sb = new StringBuilder();
            boolean found = false;
            LocalDateTime dateTime = LocalDateTime.now();
            String fechaActivacionCamp = dateTime.toString();
            String flagActivacionTC = "1";
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");

                // Busqueda del dato a actualizar o agregar
                if (data.length >=11){
                    if (data[2].equals(numeroTarjeta)) {
                        data = addDataToRow(data, fechaActivacionCamp,flagActivacionTC);
                        found = true;
                    }}

                // Construccion del nuevo contenido del archivo
                sb.append(String.join(",", data)).append("\n");
            }

            br.close();

            // Si el dato fue encontrado, se guarda el archivo con los nuevos datos
            if (found) {
                FileWriter fw = new FileWriter(filePath);
                fw.write(sb.toString());
                fw.close();
                System.out.println("Archivo actualizado correctamente.");
            } else {
                System.out.println("El dato buscado no se encontro en el archivo.");
            }

        } catch (IOException e) {
            System.out.println("Error al leer o escribir el archivo.");
            e.printStackTrace();
        }
    }
    private static String[] addDataToRow(String[] data, String fechaActivacionTC, String flagActivacionTC) {
        String[] newData = new String[data.length + 2];
        System.arraycopy(data, 0, newData, 0, data.length);
        newData[data.length] = fechaActivacionTC;
        newData[data.length + 1] = flagActivacionTC;
        return newData;
    }
}

