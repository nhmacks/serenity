package com.interbank.pe.model.cliente.cliente.RequestCrearCliente;

import java.util.ArrayList;
import java.util.List;
public class ListaTelefonos {
    private List<Telefono> telefono = new ArrayList<Telefono>();
    public List<Telefono> getTelefono() {
        return telefono;
    }
    public void setTelefono(List<Telefono> telefono) {
        this.telefono = telefono;
    }
}