package com.interbank.pe.tasks.services;

import com.interbank.pe.model.MovimientosTC;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Post;

import java.io.IOException;

import static com.interbank.pe.utils.soap.EnumRequestSoap.*;
import static com.interbank.pe.utils.soap.UtilisSoap.obtenerRequestSoap;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class PagoDeServicio implements Task {

    private final String tarjeta, amount, currency, flujo;


    public PagoDeServicio(String flujo, String card, String amount, String currency) {
        this.flujo = flujo;
        this.tarjeta = card;
        this.amount = amount;
        this.currency = currency;
    }

    public static PagoDeServicio EnEfectivo(String flujo, String tarjeta, String amount, String currency) {
        return instrumented(PagoDeServicio.class, flujo, tarjeta, amount, currency);
    }

    @Override
    public <T extends Actor> void performAs(T theActor) {
        theActor.attemptsTo(
                Post.to("/ibk/srv/MPO/Servicios/cliente.pagoServicio/v2.0")
                        .with(
                                request ->
                                        request
                                                .relaxedHTTPSValidation()
                                                .header("SOAPAction", "http://interbank.com.pe/service/MPO/Servicios/cliente.pagoServicio/v2.0")
                                                .header("Particion", "12345678")
                                                .header("Msgid", "pagoServiciox3")
                                                .header("Content-Type", "*/*")
                                                .header("Content-Type", "text/plain")
                                                .header("Content-Type", "application/soap+xml;charset=UTF-8")
                                                .body(ObtenerRequestRealizarConsumo(flujo))
                        ));
        MovimientosTC.setResponseCollection("card", tarjeta);
        MovimientosTC.setResponseCollection("amount", amount);
        MovimientosTC.setResponseCollection("currency", currency);
    }

    private String ObtenerRequestRealizarConsumo(String flujo) {
        try {
            return obtenerRequestSoap(pathrequest(flujo))
                    .replace("montoTrx", amount)
                    .replace("PAN", tarjeta)
                    .replace("monedaTrx", Currency(currency));
        } catch (IOException e) {
            return null;
        }
    }

    private String pathrequest(String flujo) {
        if (flujo.trim().equals("BENEFIT")) {
            return REALIZAR_CONSUMO.getPathArchivo();
        } else if (flujo.trim().equals("CORECSALEASING")) {
            return CORECSALEASING.getPathArchivo();
        } else if (flujo.trim().equals("DonacionTomas")) {
            return DonacionTomas.getPathArchivo();
        } else if (flujo.trim().equals("DonacionFeyAlegria")) {
            return DonacionFeyAlegria.getPathArchivo();
        }
        return null;
    }

    private String Currency(String Currency) {
        if (Currency.equals("604")) {
            return "001";
        } else if (Currency.equals("840")) {
            return "010";
        }
        return Currency;
    }
}
