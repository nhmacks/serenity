package com.interbank.pe.model.cliente.cliente.RequestCrearCliente;

import java.util.HashMap;

public class Cliente {
    public static HashMap<String,String> responseCollection = new HashMap<>();
    public static String getResponseCollection(String key){
        return responseCollection.get(key);
    }
    public static void setResponseCollection(String key, String value){
        responseCollection.put(key, value);
    }
}
