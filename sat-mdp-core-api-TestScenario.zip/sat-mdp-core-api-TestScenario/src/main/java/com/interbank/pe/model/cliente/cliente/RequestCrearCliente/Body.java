package com.interbank.pe.model.cliente.cliente.RequestCrearCliente;

public class Body {
    private CrearCliente crearCliente;
    public CrearCliente getCrearCliente() {
        return crearCliente;
    }
    public void setCrearCliente(CrearCliente crearCliente) {
        this.crearCliente = crearCliente;
    }
}