package com.interbank.pe.model.Transaccion.TransaccionCuotas;

import java.util.HashMap;
import java.util.Map;
public class Installment {
    private String payBalance;
    private String liquidatedNumberShare;
    private String currentNumberShare;
    private String installmentsTotal;
    private String loanAmount;
    private String totalAmount;
    private String Commerce;
    private String installmentsPassDate;
    private String processHour;
    private String processDate;
    private String operationCurrency;
    private String financingNumber;
    private String loanOperation;
    private String operationDate;
    public String getPayBalance() {
        return payBalance;
    }
    public void setPayBalance(String payBalance) {
        this.payBalance = payBalance;
    }
    public String getLiquidatedNumberShare() {
        return liquidatedNumberShare;
    }
    public void setLiquidatedNumberShare(String liquidatedNumberShare) {
        this.liquidatedNumberShare = liquidatedNumberShare;
    }
    public String getCurrentNumberShare() {
        return currentNumberShare;
    }
    public void setCurrentNumberShare(String currentNumberShare) {
        this.currentNumberShare = currentNumberShare;
    }
    public String getInstallmentsTotal() {
        return installmentsTotal;
    }
    public void setInstallmentsTotal(String installmentsTotal) {
        this.installmentsTotal = installmentsTotal;
    }
    public String getLoanAmount() {
        return loanAmount;
    }
    public void setLoanAmount(String loanAmount) {
        this.loanAmount = loanAmount;
    }
    public String getTotalAmount() {
        return totalAmount;
    }
    public void setTotalAmount(String totalAmount) {
        this.totalAmount = totalAmount;
    }
    public String getCommerce() {
        return Commerce;
    }
    public void setCommerce(String Commerce) {
        this.Commerce = Commerce;
    }
    public String getInstallmentsPassDate() {
        return installmentsPassDate;
    }
    public void setInstallmentsPassDate(String installmentsPassDate) {
        this.installmentsPassDate = installmentsPassDate;
    }
    public String getProcessHour() {
        return processHour;
    }
    public void setProcessHour(String processHour) {
        this.processHour = processHour;
    }
    public String getProcessDate() {
        return processDate;
    }
    public void setProcessDate(String processDate) {
        this.processDate = processDate;
    }
    public String getOperationCurrency() {
        return operationCurrency;
    }
    public void setOperationCurrency(String operationCurrency) {
        this.operationCurrency = operationCurrency;
    }
    public String getFinancingNumber() {
        return financingNumber;
    }
    public void setFinancingNumber(String financingNumber) {
        this.financingNumber = financingNumber;
    }
    public String getLoanOperation() {
        return loanOperation;
    }
    public void setLoanOperation(String loanOperation) {
        this.loanOperation = loanOperation;
    }
    public String getOperationDate() {
        return operationDate;
    }
    public void setOperationDate(String operationDate) {
        this.operationDate = operationDate;
    }
}

