package com.interbank.pe.model.tarjeta.EstadoCuentaTarjetaCredito;

public class ConsumptionLine {
    private Processed processed;
    private Authorized authorized;
    public Processed getProcessed() {
        return processed;
    }
    public void setProcessed(Processed processed) {
        this.processed = processed;
    }
    public Authorized getAuthorized() {
        return authorized;
    }
    public void setAuthorized(Authorized authorized) {
        this.authorized = authorized;
    }
}
