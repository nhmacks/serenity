package com.interbank.pe.questions.tarjeta;

import com.interbank.pe.model.tarjeta.InformacionTC.Response.ResponseListaTCAdicional;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class ListarTCadicionales implements Question<ResponseListaTCAdicional> {
    @Override
    public ResponseListaTCAdicional answeredBy(Actor actor) {
        return SerenityRest.lastResponse().as(ResponseListaTCAdicional.class);
    }
}
