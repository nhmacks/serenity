package com.interbank.pe.model.tarjeta.EstadoCuentaTarjetaCredito;
import java.util.ArrayList;
import java.util.List;

public class EstadoCuentaTarjetaCredito {
    private String isflagNSAT;
    private String customerTypeCode;
    private String branch;
    private String bin;
    private String brandCode;
    private String typeIndicator;
    private String isBlock;
    private Situation situation;
    private Account account;
    private ConsumptionLine consumptionLine;
    private CreditLine creditLine;
    private List<ParallelLineList> parallelLineList = new ArrayList<ParallelLineList>();
    private Shipping shipping;
    private Installment installment;
    private Cashdraw cashdraw;
    private Consumption consumption;
    private Overdraft overdraft;
    private String blockReason;
    private Debt debt;
    private DelayPenalty delayPenalty;
    private Payment payment;
    private String parallelLine;

    public String getIsflagNSAT() {
        return isflagNSAT;
    }

    public void setIsflagNSAT(String isflagNSAT) {
        this.isflagNSAT = isflagNSAT;
    }

    public String getCustomerTypeCode() {
        return customerTypeCode;
    }

    public void setCustomerTypeCode(String customerTypeCode) {
        this.customerTypeCode = customerTypeCode;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getBin() {
        return bin;
    }

    public void setBin(String bin) {
        this.bin = bin;
    }

    public String getBrandCode() {
        return brandCode;
    }

    public void setBrandCode(String brandCode) {
        this.brandCode = brandCode;
    }

    public String getTypeIndicator() {
        return typeIndicator;
    }

    public void setTypeIndicator(String typeIndicator) {
        this.typeIndicator = typeIndicator;
    }

    public String getIsBlock() {
        return isBlock;
    }

    public void setIsBlock(String isBlock) {
        this.isBlock = isBlock;
    }

    public Situation getSituation() {
        return situation;
    }

    public void setSituation(Situation situation) {
        this.situation = situation;
    }

    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    public ConsumptionLine getConsumptionLine() {
        return consumptionLine;
    }

    public void setConsumptionLine(ConsumptionLine consumptionLine) {
        this.consumptionLine = consumptionLine;
    }

    public CreditLine getCreditLine() {
        return creditLine;
    }

    public void setCreditLine(CreditLine creditLine) {
        this.creditLine = creditLine;
    }

    public List<ParallelLineList> getParallelLineList() {
        return parallelLineList;
    }

    public void setParallelLineList(List<ParallelLineList> parallelLineList) {
        this.parallelLineList = parallelLineList;
    }

    public Shipping getShipping() {
        return shipping;
    }

    public void setShipping(Shipping shipping) {
        this.shipping = shipping;
    }

    public Installment getInstallment() {
        return installment;
    }

    public void setInstallment(Installment installment) {
        this.installment = installment;
    }

    public Cashdraw getCashdraw() {
        return cashdraw;
    }

    public void setCashdraw(Cashdraw cashdraw) {
        this.cashdraw = cashdraw;
    }

    public Consumption getConsumption() {
        return consumption;
    }

    public void setConsumption(Consumption consumption) {
        this.consumption = consumption;
    }

    public Overdraft getOverdraft() {
        return overdraft;
    }

    public void setOverdraft(Overdraft overdraft) {
        this.overdraft = overdraft;
    }

    public String getBlockReason() {
        return blockReason;
    }

    public void setBlockReason(String blockReason) {
        this.blockReason = blockReason;
    }

    public Debt getDebt() {
        return debt;
    }

    public void setDebt(Debt debt) {
        this.debt = debt;
    }

    public DelayPenalty getDelayPenalty() {
        return delayPenalty;
    }

    public void setDelayPenalty(DelayPenalty delayPenalty) {
        this.delayPenalty = delayPenalty;
    }

    public Payment getPayment() {
        return payment;
    }

    public void setPayment(Payment payment) {
        this.payment = payment;
    }

    public String getParallelLine() {
        return parallelLine;
    }

    public void setParallelLine(String parallelLine) {
        this.parallelLine = parallelLine;
    }
}

