package com.interbank.pe.tasks.cliente.Cuenta;

import com.interbank.pe.model.cliente.cuentas.request.AccountRequest;
import com.interbank.pe.model.cliente.cuentas.response.Account;
import com.interbank.pe.model.cliente.cuentas.response.Customer;
import com.interbank.pe.questions.cliente.accounts.DatosDeLaCuenta;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.joda.time.LocalDateTime;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import static com.interbank.pe.utils.soap.EnumRequestSoap.CLIENTE_CUENTA_AHORRO;
import static net.serenitybdd.screenplay.Tasks.instrumented;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;

public class GuardarDatosDeCuenta implements Task {

    private String codigoUnicoCliente;
    private String currencyCode;
    private String product;
    private String subProduct;
    private String accountType;
    private String accountNumber;
    private String cci;
    private String success;
    private String emailType;
    private String valueEmail;
    private String accountCurrencyCode;
    private String accountSubProduct;
    private String accountAccountType;
    private String tipoDocumento;
    private String numeroDocumento;
    private String phoneType;
    private String phoneCarrier;
    private String phoneNumber;
    private String customerTitular;
    private AccountRequest accountRequest = new AccountRequest();

    public static GuardarDatosDeCuenta deAhorro() {
        return instrumented(GuardarDatosDeCuenta.class);
    }

    @Override
    public <T extends Actor> void performAs(T t) {
        Customer customer = new DatosDeLaCuenta().answeredBy(theActorInTheSpotlight()).getCustomers().get(0);
        this.codigoUnicoCliente = customer.getId();
        Account account = new DatosDeLaCuenta().answeredBy(theActorInTheSpotlight()).getAccounts().get(0);
        this.currencyCode = account.getCurrencyCode();
        this.product = account.getProduct();
        this.subProduct = account.getSubProduct();
        this.accountType = account.getAccountType();
        this.accountNumber = account.getAccountNumber();
        this.cci = account.getCci();
        this.success = String.valueOf(account.getSuccess());

        theActorInTheSpotlight().remember("cuentaMoneda", currencyCode);
        theActorInTheSpotlight().remember("cuentaProducto", product);
        theActorInTheSpotlight().remember("cuentaSubproducto", subProduct);
        theActorInTheSpotlight().remember("accountType", accountType);
        theActorInTheSpotlight().remember("accountNumber", accountNumber);
        theActorInTheSpotlight().remember("cci", cci);



        String filePath = CLIENTE_CUENTA_AHORRO.getPathArchivo();

        try {
            File csvFile = new File(filePath);
            FileReader csvReader = new FileReader(csvFile);
            CSVParser parser = new CSVParser(csvReader, CSVFormat.DEFAULT);
            FileWriter csvWriter = new FileWriter(csvFile, true);
            CSVPrinter printer = new CSVPrinter(csvWriter, CSVFormat.DEFAULT);
            LocalDateTime dateTime = LocalDateTime.now();

            List<String> newData = Arrays.asList(codigoUnicoCliente, currencyCode, product, subProduct, accountType, accountNumber, cci, success, dateTime.toString());
            printer.printRecord(newData);
            parser.close();
            printer.close();
            csvReader.close();
            csvWriter.close();
            System.out.println("CSV file created successfully!");
        } catch (IOException e) {
            System.out.println("Error creating CSV file: " + e.getMessage());
        }
        ;
    }
}
