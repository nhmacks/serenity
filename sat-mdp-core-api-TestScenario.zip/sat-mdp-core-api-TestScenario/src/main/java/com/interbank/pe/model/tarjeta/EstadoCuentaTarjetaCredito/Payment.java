package com.interbank.pe.model.tarjeta.EstadoCuentaTarjetaCredito;

public class Payment {
    private String minimumAmountSoles;
    private String totalAmountSoles;
    private String minimumAmountDollars;
    private String totalAmountDollars;
    private String paymentDate;
    private String billingClosingDate;
    public String getMinimumAmountSoles() {
        return minimumAmountSoles;
    }
    public void setMinimumAmountSoles(String minimumAmountSoles) {
        this.minimumAmountSoles = minimumAmountSoles;
    }
    public String getTotalAmountSoles() {
        return totalAmountSoles;
    }
    public void setTotalAmountSoles(String totalAmountSoles) {
        this.totalAmountSoles = totalAmountSoles;
    }
    public String getMinimumAmountDollars() {
        return minimumAmountDollars;
    }
    public void setMinimumAmountDollars(String minimumAmountDollars) {
        this.minimumAmountDollars = minimumAmountDollars;
    }
    public String getTotalAmountDollars() {
        return totalAmountDollars;
    }
    public void setTotalAmountDollars(String totalAmountDollars) {
        this.totalAmountDollars = totalAmountDollars;
    }
    public String getPaymentDate() {
        return paymentDate;
    }
    public void setPaymentDate(String paymentDate) {
        this.paymentDate = paymentDate;
    }
    public String getBillingClosingDate() {
        return billingClosingDate;
    }
    public void setBillingClosingDate(String billingClosingDate) {
        this.billingClosingDate = billingClosingDate;
    }
}
