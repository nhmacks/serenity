package com.interbank.pe.tasks.campaign;

import com.interbank.pe.utils.enums.campanna.EnumCargaMasivaDiariaExtracash;
import com.interbank.pe.utils.soap.UtilsCampanna;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.joda.time.LocalDateTime;

import java.io.*;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static com.interbank.pe.utils.soap.EnumRequestSoap.*;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class generarTxtCargaMasivaDiariaExtracash implements Task {
    private final String numeroCuenta;
    private final  String lineaCredito;

    public generarTxtCargaMasivaDiariaExtracash(String numeroCuenta, String lineaCredito) {
        this.numeroCuenta = numeroCuenta;
        this.lineaCredito = lineaCredito;
    }

    public static generarTxtCargaMasivaDiariaExtracash porTarjeta(String numeroCuenta, String lineaCredito) {
        return instrumented(generarTxtCargaMasivaDiariaExtracash.class, numeroCuenta, lineaCredito);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        String rutaArchivoTXT = CAMPANNA_DIARIA_TC_TXT.getPathArchivo();
        File archivoTXT = new File(rutaArchivoTXT);

        String rutaArchivoCSV = CAMPANNA_DIARIA_TC_CSV.getPathArchivo();
        File archivoCSV = new File(rutaArchivoCSV);

        Date fechaActual = new Date();
        long ultimaModificacionTXT = archivoTXT.lastModified();
        Date fechaModificacionTXT = new Date(ultimaModificacionTXT);
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        SimpleDateFormat sdfSalida = new SimpleDateFormat("ddMMyy");

        String fechaModificacionFormateada = formatoFecha.format(fechaModificacionTXT);
        String fechaModFormateadaTXT = sdfSalida.format(fechaModificacionTXT);
        String fechaActualFormateada = sdfSalida.format(fechaActual);
        //Verifica si el archivo TXT existe
        if (archivoTXT.exists()) {
            //Fecha de modificacion del archivo Igual a FechaActual
            if (fechaModFormateadaTXT.equals(fechaActualFormateada)) {
                editarArchivoTXT(archivoTXT);

            } else {
                String nuevoNombreArchivo = archivoTXT.getName().replaceFirst("[.][^.]+$", "") + "_" + fechaModFormateadaTXT;
                backupArchivoTXT(archivoTXT, nuevoNombreArchivo);
                crearArchivoTXT(archivoTXT);
            }
            //Archivo TXT no existe
        } else {
            if (Files.exists(Path.of(archivoTXT.getPath()))) {
                System.out.println("La ruta existe");
            } else {
                try {
                    Files.createDirectories(Path.of(archivoTXT.getPath()));
                    System.out.println("Ruta creada: " + archivoTXT.getPath());
                } catch (IOException e) {
                    System.err.println("Error al crear la ruta: " + e.getMessage());
                    throw new RuntimeException(e);
                }
            }
            crearArchivoTXT(archivoTXT);
            System.out.println("Nombre archivo 1.2: " + archivoTXT.getName());
        }

        //Verifica si el archivo CSV existe
        if (archivoCSV.exists()) {
            editarArchivoCSV(archivoCSV);
        } else {
            crearArchivoCSV(archivoCSV);
        }
    }

    private void crearArchivoTXT(File archivoTXT) {
        try {
            if (archivoTXT.createNewFile()) {
                insertarEncabezadoTXT(archivoTXT);
                insertarDatosEnArchivoTXT(archivoTXT);
            } else {
                System.out.println("No se pudo crear el archivo CARGA_DIARIA_TXT ");
            }
        } catch (IOException e) {
            System.out.println("Se produjo un error al crear el archivo CARGA_DIARIA_TXT ");
            e.printStackTrace();
        }
    }

    private void editarArchivoTXT(File archivoTXT) {
        insertarDatosEnArchivoTXT(archivoTXT);
    }

    private void insertarDatosEnArchivoTXT(File archivoTXT) {
        try {
            FileWriter fileWriter = new FileWriter(archivoTXT, true);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            BigDecimal numero = new BigDecimal(lineaCredito);
            String numeroCuenta = String.format("%012d", Integer.parseInt(this.numeroCuenta));
            String codigoMoneda = EnumCargaMasivaDiariaExtracash.CODIGO_MONEDA.getValor();
            String importeLineaExtracash = String.format("%011d", numero.intValue() * 2) + "00"; //Verificar Si esta bien//
            String tasaExtracash = UtilsCampanna.tasaExtracash();  //01  //02  //03
            String nroMesesDiferidos = UtilsCampanna.nroMesesDiferidos();  //00 //01 //02 //03
            String indicadorControlPlazo = UtilsCampanna.verdad();     //S //N
            String indicadorSeguroEfectivo = UtilsCampanna.verdad();       //S //N
            String codCampannaSiebel = EnumCargaMasivaDiariaExtracash.COD_CAMPANNA_SIEBEL.getValor();
            String importeCEM = EnumCargaMasivaDiariaExtracash.IMPORTE_CEM.getValor();
            String indicadorPiloto = UtilsCampanna.verdad();   //S //N
            String indicadorIncLinea = UtilsCampanna.verdad(); //S //N
            String disponibleConsumo = UtilsCampanna.aleatorioDisponibleConsumo();         //Saldo actual de la tarjeta
            String lineaCreditoOrigen = String.format("%010d", numero.intValue()) + "00"; //Linea de la tarjeta
            String lineaCreditoMaxima = String.format("%010d", numero.intValue() * 2) + "00";             //Linea tarjeta + 5000.00
            String fechaCaducidad = UtilsCampanna.ultimoDiaMesformatddMMyy(); //ultimo dia del Mes
            String filler = UtilsCampanna.espacios(16);

            String newData = numeroCuenta + codigoMoneda + importeLineaExtracash + tasaExtracash + nroMesesDiferidos + indicadorControlPlazo + indicadorSeguroEfectivo + codCampannaSiebel + importeCEM + indicadorPiloto + indicadorIncLinea + disponibleConsumo + lineaCreditoOrigen + lineaCreditoMaxima + fechaCaducidad + filler;
            bufferedWriter.newLine();
            bufferedWriter.write(newData);
            bufferedWriter.close();
            fileWriter.close();
        } catch (IOException e) {
            System.out.println("Error creating CSV file: " + e.getMessage());
        }
    }

    private void crearArchivoCSV(File archivoCSV) {
        try {
            if (archivoCSV.createNewFile()) {
                System.out.println("Se ha creado el archivo CARGA_DIARIA_TXT " + archivoCSV.getName());
                insertarDatosEnArchivoCSV(archivoCSV);
            } else {
                System.out.println("No se pudo crear el archivo CARGA_DIARIA_TXT ");
            }
        } catch (IOException e) {
            System.out.println("Se produjo un error al crear el archivo CARGA_DIARIA_TXT ");
            e.printStackTrace();
        }
    }

    private void editarArchivoCSV(File archivoCSV) {
        System.out.println("El archivo ya existe: " + archivoCSV.getName());
        insertarDatosEnArchivoCSV(archivoCSV);
    }

    private void insertarDatosEnArchivoCSV(File archivoCSV) {
        try {
            FileReader csvReader2 = new FileReader(archivoCSV);
            CSVParser parser2 = new CSVParser(csvReader2, CSVFormat.DEFAULT);
            FileWriter csvWriter2 = new FileWriter(archivoCSV, true);
            CSVPrinter printer2 = new CSVPrinter(csvWriter2, CSVFormat.DEFAULT);

            BigDecimal numero = new BigDecimal(lineaCredito);
            String numeroCuenta = String.format("%012d", Integer.parseInt(this.numeroCuenta));
            String codigoMoneda = EnumCargaMasivaDiariaExtracash.CODIGO_MONEDA.getValor();
            String importeLineaExtracash = String.format("%011d", numero.intValue() * 2) + "00"; //Verificar Si esta bien//
            String tasaExtracash = UtilsCampanna.tasaExtracash();  //01  //02  //03
            String nroMesesDiferidos = UtilsCampanna.nroMesesDiferidos();  //00 //01 //02 //03
            String indicadorControlPlazo = UtilsCampanna.verdad();     //S //N
            String indicadorSeguroEfectivo = UtilsCampanna.verdad();       //S //N
            String codCampannaSiebel = EnumCargaMasivaDiariaExtracash.COD_CAMPANNA_SIEBEL.getValor();
            String importeCEM = EnumCargaMasivaDiariaExtracash.IMPORTE_CEM.getValor();
            String indicadorPiloto = UtilsCampanna.verdad();   //S //N
            String indicadorIncLinea = UtilsCampanna.verdad(); //S //N
            String disponibleConsumo = UtilsCampanna.aleatorioDisponibleConsumo();         //Saldo actual de la tarjeta
            String lineaCreditoOrigen = String.format("%010d", numero.intValue()) + "00"; //Linea de la tarjeta
            String lineaCreditoMaxima = String.format("%010d", numero.intValue() * 2) + "00";             //Linea tarjeta + 5000.00
            String fechaCaducidad = UtilsCampanna.ultimoDiaMesformatddMMyy(); //ultimo dia del Mes
            String filler = UtilsCampanna.espacios(16);
            LocalDateTime dateTime = LocalDateTime.now();

            List<String> newData = List.of(numeroCuenta, codigoMoneda, importeLineaExtracash, tasaExtracash, nroMesesDiferidos, indicadorControlPlazo, indicadorSeguroEfectivo, codCampannaSiebel, importeCEM, indicadorPiloto, indicadorIncLinea, disponibleConsumo, lineaCreditoOrigen, lineaCreditoMaxima, fechaCaducidad, filler, dateTime.toString());
            printer2.printRecord(newData);
            parser2.close();
            printer2.close();
            csvReader2.close();
            csvWriter2.close();

            System.out.println("CSV carga masiva diaria Extracash actualizado, successfully!");
        } catch (IOException e) {
            System.out.println("Error creating CSV file: " + e.getMessage());
        }
    }

    private void backupArchivoTXT(File archivoTXT, String nuevoNombreArchivo) {
        // Obtener la ruta absoluta del archivo
        String rutaArchivo = archivoTXT.getAbsolutePath();

        // Crear una copia de seguridad del archivo
        String rutaBackup = rutaArchivo + nuevoNombreArchivo;
        File backup = new File(rutaBackup);
        try {
            Files.copy(archivoTXT.toPath(), backup.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
        }

        // Renombrar el archivo original
        String nuevaRuta = rutaArchivo.replace(archivoTXT.getName(), nuevoNombreArchivo);
        File nuevoArchivo = new File(nuevaRuta);

        if (archivoTXT.renameTo(nuevoArchivo)) {
            System.out.println("Se cambio el nombre del archivo a " + nuevoNombreArchivo);

            // Eliminar la copia de seguridad del archivo original
            if (backup.delete()) {
                System.out.println("Se elimino la copia de seguridad del archivo original.");
            } else {
                System.out.println("No se pudo eliminar la copia de seguridad del archivo original.");
            }
        } else {
            System.out.println("No se pudo cambiar el nombre del archivo.");
        }
    }

    private void insertarEncabezadoTXT(File archivoTXT) {

        try {
            Date fechaActual = new Date();
            SimpleDateFormat formatoHora = new SimpleDateFormat("dd/MM/yyyy");
            String fechaFormateada = formatoHora.format(fechaActual);
            FileWriter fileWriter = new FileWriter(archivoTXT, true);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            String[] registroEncontrado = obtenerCodCampanna();
            assert registroEncontrado != null;
            System.out.println("registroEncontrado::::: " + registroEncontrado[1]);
            String value;
            value = registroEncontrado[1];
            String encabezadoTXT = value + fechaFormateada;
            bufferedWriter.write(encabezadoTXT);
            bufferedWriter.close();
            fileWriter.close();

        } catch (IOException e) {
            System.out.println("Error creating CSV file: " + e.getMessage());
        }
    }


    public static String[] obtenerCodCampanna() {
        String rutaCodCampanna = COD_CAMPANNA.getPathArchivo();
        File archivo = new File(rutaCodCampanna);

        Date fechaActual = new Date();

        SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyyMM");
        String condicionAnioMesFormateado = formatoFecha.format(fechaActual);


        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;

            while ((linea = br.readLine()) != null) {
                String[] campos = linea.split(",");

                // Verificar la condicion en el campo deseado (por ejemplo, el primer campo)
                if (campos.length > 0 && campos[0].equals(condicionAnioMesFormateado)) {
                    // Se encontro el registro que cumple la condicion
                    return campos;
                }
            }

            // No se encontro ningun registro que cumpla la condicion
            System.out.println("No se encontro ningun registro que cumpla la condicion.");

        } catch (IOException e) {
            System.out.println("Error al leer el archivo CSV: " + e.getMessage());
        }

        return null;
    }
}
