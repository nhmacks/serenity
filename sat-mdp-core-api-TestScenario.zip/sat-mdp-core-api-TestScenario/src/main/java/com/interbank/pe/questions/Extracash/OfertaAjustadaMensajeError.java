package com.interbank.pe.questions.Extracash;

import com.interbank.pe.model.Extracash.ofertaAjusta.OfertaAjustadaResponseError;
import io.restassured.mapper.ObjectMapperType;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class OfertaAjustadaMensajeError implements Question {

    @Override
    public OfertaAjustadaResponseError answeredBy(Actor actor) {
        return SerenityRest.lastResponse().as(OfertaAjustadaResponseError.class, ObjectMapperType.GSON);
    }
}
