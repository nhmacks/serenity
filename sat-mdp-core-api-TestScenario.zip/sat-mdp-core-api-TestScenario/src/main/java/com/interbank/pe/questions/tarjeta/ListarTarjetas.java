package com.interbank.pe.questions.tarjeta;

import com.interbank.pe.model.tarjeta.Tarjeta;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.interbank.pe.utils.soap.EnumRequestSoap.CLIENTE_TARJETA;
import static com.interbank.pe.utils.soap.UtilsTarjeta.existsValue;

public class ListarTarjetas implements Question {
    @Override
    public List<Tarjeta> answeredBy(Actor actor) {
        String filePath = CLIENTE_TARJETA.getPathArchivo();
        String line = "";
        String cvsSplitBy = ",";
        List<Tarjeta> tarjeta = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            int contador = 0;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(cvsSplitBy);
                if (data.length >= 11 & contador>0) {
                    Tarjeta tarjeta1 = new Tarjeta(
                            existsValue(data, 0) ? data[0] : "",
                            existsValue(data, 1) ? data[1] : "",
                            existsValue(data, 2) ? data[2] : "",
                            existsValue(data, 3) ? data[3] : "",
                            existsValue(data, 4) ? data[4] : "",
                            existsValue(data, 5) ? data[5] : "",
                            existsValue(data, 6) ? data[6] : "",
                            existsValue(data, 7) ? data[7] : "",
                            existsValue(data, 8) ? data[8] : "",
                            existsValue(data, 9) ? data[9] : "",
                            existsValue(data, 10) ? data[10] : "",
                            existsValue(data, 11) ? data[11] : "",
                            existsValue(data, 12) ? data[12] : "",
                            existsValue(data, 13) ? data[13] : "",
                            existsValue(data, 14) ? data[14] : ""
                    );
                    tarjeta.add(tarjeta1);
                }
                contador++;
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return tarjeta;
    }
}
