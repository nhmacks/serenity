package com.interbank.pe.model.cliente.cliente.RequestCrearCliente;

public class HeaderRequest {
    private Request request;
    private Identity identity;
    public Request getRequest() {
        return request;
    }
    public void setRequest(Request request) {
        this.request = request;
    }
    public Identity getIdentity() {
        return identity;
    }
    public void setIdentity(Identity identity) {
        this.identity = identity;
    }
}