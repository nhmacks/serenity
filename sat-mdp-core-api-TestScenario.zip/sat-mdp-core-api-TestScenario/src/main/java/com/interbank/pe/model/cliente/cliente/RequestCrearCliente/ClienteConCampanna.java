package com.interbank.pe.model.cliente.cliente.RequestCrearCliente;

public class ClienteConCampanna {
    private String pan;
    private String montoCampanna;
    private String carIdType;
    private String tipoDocumento;
    private String lineaCreditoTC;
    private String porcentajeConsumo;
    private String codigoCliente;
    private String pilotoCampanna;
    private String numeroContratoTC;
    private String codMoneda;
    private String importeExtracash;
    private String tasaExtracash;
    private String nroMesesDiferidos;
    private String indicadorControlPlazo;
    private String indicadorSeguroEfectivo;
    private String importeCem;
    private String indicadorPiloto;
    private String indicadorIncrementoLinea;
    private String lineaCreditoOrigin;
    private String lineaCreditoMaxima;
    private String fechaCaducidad;
    private String numeroDocumento;

    public ClienteConCampanna(String pan,
                              String montoCampanna,
                              String carIdType,
                              String tipoDocumento,
                              String lineaCreditoTC,
                              String porcentajeConsumo,
                              String codigoCliente,
                              String pilotoCampanna,
                              String numeroContratoTC,
                              String codMoneda,
                              String importeExtracash,
                              String tasaExtracash,
                              String nroMesesDiferidos,
                              String indicadorControlPlazo,
                              String indicadorSeguroEfectivo,
                              String importeCem,
                              String indicadorPiloto,
                              String indicadorIncrementoLinea,
                              String lineaCreditoOrigin,
                              String lineaCreditoMaxima,
                              String fechaCaducidad, String numeroDocumento) {
        this.pan = pan;
        this.montoCampanna = montoCampanna;
        this.carIdType = carIdType;
        this.tipoDocumento = tipoDocumento;
        this.lineaCreditoTC = lineaCreditoTC;
        this.porcentajeConsumo = porcentajeConsumo;
        this.codigoCliente = codigoCliente;
        this.pilotoCampanna = pilotoCampanna;
        this.numeroContratoTC = numeroContratoTC;
        this.codMoneda = codMoneda;
        this.importeExtracash = importeExtracash;
        this.tasaExtracash = tasaExtracash;
        this.nroMesesDiferidos = nroMesesDiferidos;
        this.indicadorControlPlazo = indicadorControlPlazo;
        this.indicadorSeguroEfectivo = indicadorSeguroEfectivo;
        this.importeCem = importeCem;
        this.indicadorPiloto = indicadorPiloto;
        this.indicadorIncrementoLinea = indicadorIncrementoLinea;
        this.lineaCreditoOrigin = lineaCreditoOrigin;
        this.lineaCreditoMaxima = lineaCreditoMaxima;
        this.fechaCaducidad = fechaCaducidad;
        this.numeroDocumento = numeroDocumento;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public String getMontoCampanna() {
        return montoCampanna;
    }

    public void setMontoCampanna(String montoCampanna) {
        this.montoCampanna = montoCampanna;
    }

    public String getCarIdType() {
        return carIdType;
    }

    public void setCarIdType(String carIdType) {
        this.carIdType = carIdType;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getLineaCreditoTC() {
        return lineaCreditoTC;
    }

    public void setLineaCreditoTC(String lineaCreditoTC) {
        this.lineaCreditoTC = lineaCreditoTC;
    }

    public String getPorcentajeConsumo() {
        return porcentajeConsumo;
    }

    public void setPorcentajeConsumo(String porcentajeConsumo) {
        this.porcentajeConsumo = porcentajeConsumo;
    }

    public String getCodigoCliente() {
        return codigoCliente;
    }

    public void setCodigoCliente(String codigoCliente) {
        this.codigoCliente = codigoCliente;
    }

    public String getPilotoCampanna() {
        return pilotoCampanna;
    }

    public void setPilotoCampanna(String pilotoCampanna) {
        this.pilotoCampanna = pilotoCampanna;
    }

    public String getNumeroContratoTC() {
        return numeroContratoTC;
    }

    public void setNumeroContratoTC(String numeroContratoTC) {
        this.numeroContratoTC = numeroContratoTC;
    }

    public String getCodMoneda() {
        return codMoneda;
    }

    public void setCodMoneda(String codMoneda) {
        this.codMoneda = codMoneda;
    }

    public String getImporteExtracash() {
        return importeExtracash;
    }

    public void setImporteExtracash(String importeExtracash) {
        this.importeExtracash = importeExtracash;
    }

    public String getTasaExtracash() {
        return tasaExtracash;
    }

    public void setTasaExtracash(String tasaExtracash) {
        this.tasaExtracash = tasaExtracash;
    }

    public String getNroMesesDiferidos() {
        return nroMesesDiferidos;
    }

    public void setNroMesesDiferidos(String nroMesesDiferidos) {
        this.nroMesesDiferidos = nroMesesDiferidos;
    }

    public String getIndicadorControlPlazo() {
        return indicadorControlPlazo;
    }

    public void setIndicadorControlPlazo(String indicadorControlPlazo) {
        this.indicadorControlPlazo = indicadorControlPlazo;
    }

    public String getIndicadorSeguroEfectivo() {
        return indicadorSeguroEfectivo;
    }

    public void setIndicadorSeguroEfectivo(String indicadorSeguroEfectivo) {
        this.indicadorSeguroEfectivo = indicadorSeguroEfectivo;
    }

    public String getImporteCem() {
        return importeCem;
    }

    public void setImporteCem(String importeCem) {
        this.importeCem = importeCem;
    }

    public String getIndicadorPiloto() {
        return indicadorPiloto;
    }

    public void setIndicadorPiloto(String indicadorPiloto) {
        this.indicadorPiloto = indicadorPiloto;
    }

    public String getIndicadorIncrementoLinea() {
        return indicadorIncrementoLinea;
    }

    public void setIndicadorIncrementoLinea(String indicadorIncrementoLinea) {
        this.indicadorIncrementoLinea = indicadorIncrementoLinea;
    }

    public String getLineaCreditoOrigin() {
        return lineaCreditoOrigin;
    }

    public void setLineaCreditoOrigin(String lineaCreditoOrigin) {
        this.lineaCreditoOrigin = lineaCreditoOrigin;
    }

    public String getLineaCreditoMaxima() {
        return lineaCreditoMaxima;
    }

    public void setLineaCreditoMaxima(String lineaCreditoMaxima) {
        this.lineaCreditoMaxima = lineaCreditoMaxima;
    }

    public String getFechaCaducidad() {
        return fechaCaducidad;
    }

    public void setFechaCaducidad(String fechaCaducidad) {
        this.fechaCaducidad = fechaCaducidad;
    }

    public String getNumeroDocumento() {
        return numeroDocumento;
    }

    public void setNumeroDocumento(String numeroDocumento) {
        this.numeroDocumento = numeroDocumento;
    }
}
