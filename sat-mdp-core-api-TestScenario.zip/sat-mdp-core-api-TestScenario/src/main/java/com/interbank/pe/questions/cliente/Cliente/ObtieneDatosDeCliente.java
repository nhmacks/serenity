package com.interbank.pe.questions.cliente.Cliente;

import com.interbank.pe.model.cliente.cliente.ResponseCrearCliente.ResponseCliente;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class ObtieneDatosDeCliente implements Question {
    @Override
    public ResponseCliente answeredBy(Actor actor) {
        return SerenityRest.lastResponse().as(ResponseCliente.class);
    }
}
