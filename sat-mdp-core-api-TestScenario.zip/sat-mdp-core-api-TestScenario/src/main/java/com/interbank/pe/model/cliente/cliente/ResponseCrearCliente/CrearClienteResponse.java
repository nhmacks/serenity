package com.interbank.pe.model.cliente.cliente.ResponseCrearCliente;

public class CrearClienteResponse {
    private String codigoUnicoCliente;
    public String getCodigoUnicoCliente() {
        return codigoUnicoCliente;
    }
    public void setCodigoUnicoCliente(String codigoUnicoCliente) {
        this.codigoUnicoCliente = codigoUnicoCliente;
    }
}