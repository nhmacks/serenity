package com.interbank.pe.model.tarjeta.EstadoCuentaTarjetaCredito;

public class CreditLine {
    private String sign;
    private String amount;
    private Used used;
    private Available available;
    public String getSign() {
        return sign;
    }
    public void setSign(String sign) {
        this.sign = sign;
    }
    public String getAmount() {
        return amount;
    }
    public void setAmount(String amount) {
        this.amount = amount;
    }
    public Used getUsed() {
        return used;
    }
    public void setUsed(Used used) {
        this.used = used;
    }
    public Available getAvailable() {
        return available;
    }
    public void setAvailable(Available available) {
        this.available = available;
    }
}