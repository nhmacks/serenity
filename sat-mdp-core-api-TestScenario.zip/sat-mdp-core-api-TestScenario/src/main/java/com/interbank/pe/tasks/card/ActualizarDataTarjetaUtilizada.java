package com.interbank.pe.tasks.card;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import org.joda.time.LocalDateTime;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import static com.interbank.pe.utils.soap.EnumRequestSoap.DATA_TARJETA_DISPONIBLE;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class ActualizarDataTarjetaUtilizada implements Task {

    private final String numeroTarjeta;

    public ActualizarDataTarjetaUtilizada(String numeroTarjeta) {
        this.numeroTarjeta = numeroTarjeta;
    }

    public static ActualizarDataTarjetaUtilizada now(String numeroTarjeta) {
        return instrumented(ActualizarDataTarjetaUtilizada.class, numeroTarjeta);
    }

    @Override
    public <T extends Actor> void performAs(T t) {
        String filePath = DATA_TARJETA_DISPONIBLE.getPathArchivo();
        System.out.println("ruta archivo" + filePath);
        System.out.println("Tarjeta credito actualizar: " + numeroTarjeta);
        try {
            BufferedReader br = new BufferedReader(new FileReader(filePath));
            String line;
            StringBuilder sb = new StringBuilder();
            boolean found = false;

            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                if (data[0].equals(numeroTarjeta)) {
                    String estado = "1";
                    data = addDataToRow(data, estado);
                    found = true;
                }
                sb.append(String.join(",", data)).append("\n");
            }
            br.close();
            if (found) {
                FileWriter fw = new FileWriter(filePath);
                fw.write(sb.toString());
                fw.close();
                System.out.println("Archivo actualizado correctamente.");
            } else {
                System.out.println("El dato buscado no se encontro en el archivo.");
            }

        } catch (IOException e) {
            System.out.println("Error al leer o escribir el archivo.");
            e.printStackTrace();
        }
    }

    private static String[] addDataToRow(String[] data, String estado) {
        LocalDateTime dateTime = LocalDateTime.now();
        String fechaActivacion = dateTime.toString();
        String[] newData = new String[data.length + 2];
        System.arraycopy(data, 0, newData, 0, data.length);
        newData[data.length] = estado;
        newData[data.length + 1] = fechaActivacion;
        return newData;
    }
}
