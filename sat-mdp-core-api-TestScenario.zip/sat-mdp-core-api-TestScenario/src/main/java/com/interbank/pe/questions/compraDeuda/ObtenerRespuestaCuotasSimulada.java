package com.interbank.pe.questions.compraDeuda;

import com.interbank.pe.model.CompraDeDeuda.SimulacionCompraDeuda.Response.SimulacionCuotasResponse;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class ObtenerRespuestaCuotasSimulada implements Question<SimulacionCuotasResponse> {
    @Override
    public SimulacionCuotasResponse answeredBy(Actor actor) {
        return SerenityRest.lastResponse().as(SimulacionCuotasResponse.class);
    }
}
