package com.interbank.pe.model.tarjeta.pago;

public class PaymentCard {
    private String paymentDate;
    private String amount;
    private InterestRate interestRate;
    private String companyName;
    private String transactionNumber;
    private String settlementDate;
    public String getPaymentDate() {
        return paymentDate;
    }
    public void setPaymentDate(String paymentDate) {
        this.paymentDate = paymentDate;
    }
    public String getAmount() {
        return amount;
    }
    public void setAmount(String amount) {
        this.amount = amount;
    }
    public InterestRate getInterestRate() {
        return interestRate;
    }
    public void setInterestRate(InterestRate interestRate) {
        this.interestRate = interestRate;
    }
    public String getCompanyName() {
        return companyName;
    }
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
    public String getTransactionNumber() {
        return transactionNumber;
    }
    public void setTransactionNumber(String transactionNumber) {
        this.transactionNumber = transactionNumber;
    }
    public String getSettlementDate() {
        return settlementDate;
    }
    public void setSettlementDate(String settlementDate) {
        this.settlementDate = settlementDate;
    }
}