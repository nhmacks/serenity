package com.interbank.pe.tasks.card;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Post;
import net.thucydides.core.steps.StepInterceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

import static com.interbank.pe.utils.soap.EnumRequestSoap.CONSULTAR_MOVIMIENTO;
import static com.interbank.pe.utils.soap.UtilisSoap.obtenerRequestSoap;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class ListaLosUltimoMovimientos implements Task {
    private static final Logger LOGGER = LoggerFactory.getLogger(StepInterceptor.class);
    private final String card;
    private final String numFilas;

    public ListaLosUltimoMovimientos(String card, String numFilas) {
        this.card = card;
        this.numFilas = numFilas;
    }

    public static ListaLosUltimoMovimientos deTarjeta(String card, String numFilas) {
        return instrumented(ListaLosUltimoMovimientos.class, card, numFilas);
    }

    @Override
    public <T extends Actor> void performAs(T theActor) {
        theActor.attemptsTo(
                Post.to("ibk/srv/MPO/Colocaciones/tarjeta.consultarMovimientosTC/v1.0")
                        .with(
                                request ->
                                        request
                                                .relaxedHTTPSValidation()
                                                .header("SOAPAction", "http://interbank.com.pe/service/MPO/Colocaciones/tarjeta.consultarMovimientosTC/v1.0/")
                                                .header("charset", "*/*")
                                                .header("Content-Type", "text/xml; charset=ISO-8859-1")
                                                .body(ObtenerRequestConsultarMovimientosTC())
                        )
        );
    }

    private String ObtenerRequestConsultarMovimientosTC() {
        try {
            return obtenerRequestSoap(CONSULTAR_MOVIMIENTO.getPathArchivo())
                    .replace("cardNumber", card)
            .replace("numFilas", numFilas);
        } catch (IOException e) {
            LOGGER.info("Error al obtener el xml con los datos: " + e);
            return null;
        }
    }


}
