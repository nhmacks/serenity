package com.interbank.pe.model.Extracash.DesembolsoIncrementoLinea.Request;

import java.util.ArrayList;
import java.util.List;

public class CommonData {
    private IdentityDocument identityDocument;
    private Transaction transaction;
    private ExchangeRate exchangeRate;
    private List<PaymentMethod> paymentMethods = new ArrayList<PaymentMethod>();
    public IdentityDocument getIdentityDocument() {
        return identityDocument;
    }
    public void setIdentityDocument(IdentityDocument identityDocument) {
        this.identityDocument = identityDocument;
    }
    public Transaction getTransaction() {
        return transaction;
    }
    public void setTransaction(Transaction transaction) {
        this.transaction = transaction;
    }
    public ExchangeRate getExchangeRate() {
        return exchangeRate;
    }
    public void setExchangeRate(ExchangeRate exchangeRate) {
        this.exchangeRate = exchangeRate;
    }
    public List<PaymentMethod> getPaymentMethods() {
        return paymentMethods;
    }
    public void setPaymentMethods(List<PaymentMethod> paymentMethods) {
        this.paymentMethods = paymentMethods;
    }
}
