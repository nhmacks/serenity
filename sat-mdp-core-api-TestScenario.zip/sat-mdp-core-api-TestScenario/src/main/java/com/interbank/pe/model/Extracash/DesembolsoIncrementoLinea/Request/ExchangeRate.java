package com.interbank.pe.model.Extracash.DesembolsoIncrementoLinea.Request;

public class ExchangeRate {
    private Double buy;
    private Double sale;

    public Double getBuy() {
        return buy;
    }

    public void setBuy(Double buy) {
        this.buy = buy;
    }

    public Double getSale() {
        return sale;
    }

    public void setSale(Double sale) {
        this.sale = sale;
    }
}
