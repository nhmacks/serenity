package com.interbank.pe.model.tarjeta.EstadoCuentaTarjetaCredito;

public class Consumption {
    private String monthlyRate;
    private String anualRate;
    public String getMonthlyRate() {
        return monthlyRate;
    }
    public void setMonthlyRate(String monthlyRate) {
        this.monthlyRate = monthlyRate;
    }
    public String getAnualRate() {
        return anualRate;
    }
    public void setAnualRate(String anualRate) {
        this.anualRate = anualRate;
    }
}
