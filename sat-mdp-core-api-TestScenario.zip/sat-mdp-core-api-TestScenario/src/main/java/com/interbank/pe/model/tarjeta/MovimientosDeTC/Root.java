package com.interbank.pe.model.tarjeta.MovimientosDeTC;

public class Root {
    private SoapenvEnvelope soapenvEnvelope;
    public SoapenvEnvelope getSoapenvEnvelope() {
        return soapenvEnvelope;
    }
    public void setSoapenvEnvelope(SoapenvEnvelope soapenvEnvelope) {
        this.soapenvEnvelope = soapenvEnvelope;
    }
}

