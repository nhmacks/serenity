package com.interbank.pe.model.CompraDeDeuda.DesembolsoCompraDeuda.Request;

public class AltaCompraDeuda {
    private String documentType;
    private String referenceId;
    private Registration registration;
    public String getDocumentType() {
        return documentType;
    }
    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }
    public String getReferenceId() {
        return referenceId;
    }
    public void setReferenceId(String referenceId) {
        this.referenceId = referenceId;
    }
    public Registration getRegistration() {
        return registration;
    }
    public void setRegistration(Registration registration) {
        this.registration = registration;
    }
}
