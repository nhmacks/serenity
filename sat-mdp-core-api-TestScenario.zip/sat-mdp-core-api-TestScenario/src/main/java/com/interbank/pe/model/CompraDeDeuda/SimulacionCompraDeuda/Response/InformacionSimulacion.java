package com.interbank.pe.model.CompraDeDeuda.SimulacionCompraDeuda.Response;

public class InformacionSimulacion {
    private String cardId;
    private String simulatedAmount;
    private String currency;
    private String tea;
    private String capitalizedInterest;
    private String deferredInterest;
    private String financedAmount;
    private String expirationDate;
    private String deferredDays;
    private String installmentAmount;
    private String amountAvailable;
    private String maximumOffer;
    private String flag;

    public String getCardId() {
        return cardId;
    }

    public void setCardId(String cardId) {
        this.cardId = cardId;
    }

    public String getSimulatedAmount() {
        return simulatedAmount;
    }

    public void setSimulatedAmount(String simulatedAmount) {
        this.simulatedAmount = simulatedAmount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getTea() {
        return tea;
    }

    public void setTea(String tea) {
        this.tea = tea;
    }

    public String getCapitalizedInterest() {
        return capitalizedInterest;
    }

    public void setCapitalizedInterest(String capitalizedInterest) {
        this.capitalizedInterest = capitalizedInterest;
    }

    public String getDeferredInterest() {
        return deferredInterest;
    }

    public void setDeferredInterest(String deferredInterest) {
        this.deferredInterest = deferredInterest;
    }

    public String getFinancedAmount() {
        return financedAmount;
    }

    public void setFinancedAmount(String financedAmount) {
        this.financedAmount = financedAmount;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    public String getDeferredDays() {
        return deferredDays;
    }

    public void setDeferredDays(String deferredDays) {
        this.deferredDays = deferredDays;
    }

    public String getInstallmentAmount() {
        return installmentAmount;
    }

    public void setInstallmentAmount(String installmentAmount) {
        this.installmentAmount = installmentAmount;
    }

    public String getAmountAvailable() {
        return amountAvailable;
    }

    public void setAmountAvailable(String amountAvailable) {
        this.amountAvailable = amountAvailable;
    }

    public String getMaximumOffer() {
        return maximumOffer;
    }

    public void setMaximumOffer(String maximumOffer) {
        this.maximumOffer = maximumOffer;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }
}
