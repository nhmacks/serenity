package com.interbank.pe.model.cliente.cliente.RequestCrearCliente;
public class Root {
    private MessageRequest MessageRequest;
    public MessageRequest getMessageRequest() {
        return MessageRequest;
    }
    public void setMessageRequest(MessageRequest MessageRequest) {
        this.MessageRequest = MessageRequest;
    }
}