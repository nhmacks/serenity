package com.interbank.pe.model.tarjeta;

public class ListaTarjetasDisponible {
    private String tarjeta;
    private String estadoTarjeta;

    public ListaTarjetasDisponible(String tarjeta, String estadoTarjeta) {
        this.tarjeta = tarjeta;
        this.estadoTarjeta = estadoTarjeta;
    }

    public String getTarjeta() {
        return tarjeta;
    }

    public void setTarjeta(String tarjeta) {
        this.tarjeta = tarjeta;
    }

    public String getEstadoTarjeta() {
        return estadoTarjeta;
    }

    public void setEstadoTarjeta(String estadoTarjeta) {
        this.estadoTarjeta = estadoTarjeta;
    }
}
