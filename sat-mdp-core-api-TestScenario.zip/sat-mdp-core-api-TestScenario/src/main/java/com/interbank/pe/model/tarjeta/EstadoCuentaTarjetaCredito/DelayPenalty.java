package com.interbank.pe.model.tarjeta.EstadoCuentaTarjetaCredito;

public class DelayPenalty {
    private String isDelay;
    private String days;
    private String startDay;
    public String getIsDelay() {
        return isDelay;
    }
    public void setIsDelay(String isDelay) {
        this.isDelay = isDelay;
    }
    public String getDays() {
        return days;
    }
    public void setDays(String days) {
        this.days = days;
    }
    public String getStartDay() {
        return startDay;
    }
    public void setStartDay(String startDay) {
        this.startDay = startDay;
    }
}
