package com.interbank.pe.model.cliente.cliente.ResponseCrearCliente;

public class Body {
    private CrearClienteResponse crearClienteResponse;
    public CrearClienteResponse getCrearClienteResponse() {
        return crearClienteResponse;
    }
    public void setCrearClienteResponse(CrearClienteResponse crearClienteResponse) {
        this.crearClienteResponse = crearClienteResponse;
    }
}