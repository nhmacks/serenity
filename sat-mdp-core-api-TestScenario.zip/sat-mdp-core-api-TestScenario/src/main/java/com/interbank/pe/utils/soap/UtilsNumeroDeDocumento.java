package com.interbank.pe.utils.soap;

import java.util.Random;

public class UtilsNumeroDeDocumento {
    public static String DNI() {
        Random random = new Random();
        int min = 10000000;
        int max = 90000000;
        int num = random.nextInt(min)+max;
        return String.valueOf(num);
    }

    public static String randomText(){
        String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        String randomString = null;
        int length = 8;
        for (int i = 0; i < length; i++){
            int index = random.nextInt(alphabet.length());
            char randomChar = alphabet.charAt(index);
            sb.append(randomChar);
             randomString = sb.toString();
        }
        return randomString;
    }
}
