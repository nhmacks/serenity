package com.interbank.pe.model.tarjeta.MovimientosDeTC;

public class SoapenvHeader {
    private V4HeaderResponse v4HeaderResponse;
    public V4HeaderResponse getV4HeaderResponse() {
        return v4HeaderResponse;
    }
    public void setV4HeaderResponse(V4HeaderResponse v4HeaderResponse) {
        this.v4HeaderResponse = v4HeaderResponse;
    }
}

