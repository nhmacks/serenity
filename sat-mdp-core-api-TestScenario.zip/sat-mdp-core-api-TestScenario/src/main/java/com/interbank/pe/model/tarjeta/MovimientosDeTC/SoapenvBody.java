package com.interbank.pe.model.tarjeta.MovimientosDeTC;

public class SoapenvBody {
    private V1ConsultarMovimientosTCResponse v1ConsultarMovimientosTCResponse;
    public V1ConsultarMovimientosTCResponse getV1ConsultarMovimientosTCResponse() {
        return v1ConsultarMovimientosTCResponse;
    }
    public void setV1ConsultarMovimientosTCResponse(V1ConsultarMovimientosTCResponse v1ConsultarMovimientosTCResponse) {
        this.v1ConsultarMovimientosTCResponse = v1ConsultarMovimientosTCResponse;
    }
}
