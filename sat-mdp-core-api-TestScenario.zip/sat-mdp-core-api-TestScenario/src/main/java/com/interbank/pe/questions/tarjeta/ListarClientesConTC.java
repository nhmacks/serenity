package com.interbank.pe.questions.tarjeta;

import com.interbank.pe.model.cliente.cliente.RequestCrearCliente.ClienteConTarjeta;
import com.interbank.pe.model.cliente.cliente.RequestCrearCliente.Clientes;
import com.interbank.pe.model.tarjeta.ListaTarjetasDisponible;
import com.interbank.pe.model.tarjeta.Tarjeta;
import com.interbank.pe.questions.cliente.Cliente.ListarClientes;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

import java.util.List;
import java.util.Objects;


public class ListarClientesConTC implements Question<ClienteConTarjeta> {
    String contrato;
    String customerType;
    String card;
    String marcaTC;
    String tipoTC;
    String producto;
    String description;
    String condicionEconomica;
    String lineaCredito;
    String lineaCreditoMax;
    String tipoDocumento;
    String numeroDocumento;
    String primerNombre;
    String segundoNombre;
    String primerApellido;
    String segundoApellido;

    @Override
    public ClienteConTarjeta answeredBy(Actor actor) {
        List<Tarjeta> tarjetasList = new ListarTarjetas().answeredBy(actor);
        List<Clientes> clientes = new ListarClientes().answeredBy(actor);
        List<ListaTarjetasDisponible> tarjetasDisponibles = new ListarTarjetasDisponiblesParaPruebas().answeredBy(actor);
        for (ListaTarjetasDisponible listaTarjetasDisponible : tarjetasDisponibles) {
            if (Objects.equals(listaTarjetasDisponible.getEstadoTarjeta(), "")|Objects.equals(listaTarjetasDisponible.getEstadoTarjeta(),null)) {
                for (Tarjeta tarjeta : tarjetasList) {
                    if (Objects.equals(tarjeta.getflagActivacionTC(), "1")&Objects.equals(tarjeta.getCard(),listaTarjetasDisponible.getTarjeta())) {
                        for (Clientes clientes1 : clientes) {
                            if (Integer.valueOf(clientes1.getContrato()).equals(Integer.valueOf(tarjeta.getContrato()))&(tarjeta.getCard().equals(listaTarjetasDisponible.getTarjeta()))) {
                                this.contrato = tarjeta.getContrato();
                                this.customerType = tarjeta.getCustomerType();
                                this.card = tarjeta.getCard();
                                this.marcaTC = tarjeta.getMarcaTC();
                                this.tipoTC = tarjeta.getTipoTC();
                                this.producto = tarjeta.getProducto();
                                this.description = tarjeta.getDescription();
                                this.condicionEconomica = tarjeta.getCondicionEconomica();
                                this.lineaCredito = tarjeta.getlineaCredito();
                                this.lineaCreditoMax = tarjeta.getlineaCreditoMax();
                                this.tipoDocumento = clientes1.getTipoDocumento();
                                this.numeroDocumento = clientes1.getNumeroDocumento();
                                this.primerNombre = clientes1.getPrimerNombre();
                                this.segundoNombre = clientes1.getSegundoNombre();
                                this.primerApellido = clientes1.getPrimerApellido();
                                this.segundoApellido = clientes1.getSegundoApellido();
                                break;
                            }
                        }
                        break;
                    }
                }
                break;
            }
        }


        return new ClienteConTarjeta(contrato, customerType, card, marcaTC, tipoTC, producto, description, condicionEconomica, lineaCredito, lineaCreditoMax, tipoDocumento, numeroDocumento, primerNombre, segundoNombre, primerApellido, segundoApellido);
    }
}
