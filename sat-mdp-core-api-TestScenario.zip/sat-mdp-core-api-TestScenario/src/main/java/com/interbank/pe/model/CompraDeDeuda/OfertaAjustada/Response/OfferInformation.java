package com.interbank.pe.model.CompraDeDeuda.OfertaAjustada.Response;

public class OfferInformation {
    private String cardId;
    private String currentLine;
    private String usedSign;
    private String lineUses;
    private String lineAvailable;
    private String availableCalculated;
    private String factorAvailable;
    private String tea;
    private String capitalizedDays;
    private String minimumOffer;
    private String interestMinimumOffer;
    private String offerIncreaseLine;
    private String availableOfferIncreaseLine;
    private String interestOfferIncreaseLine;
    private String offerWithoutLineIncrease;
    private String AvailableOfferWithoutLineIncrease;
    private String interestOfferWithoutLineIncrease;
    public String getCardId() {
        return cardId;
    }
    public void setCardId(String cardId) {
        this.cardId = cardId;
    }
    public String getCurrentLine() {
        return currentLine;
    }
    public void setCurrentLine(String currentLine) {
        this.currentLine = currentLine;
    }
    public String getUsedSign() {
        return usedSign;
    }
    public void setUsedSign(String usedSign) {
        this.usedSign = usedSign;
    }
    public String getLineUses() {
        return lineUses;
    }
    public void setLineUses(String lineUses) {
        this.lineUses = lineUses;
    }
    public String getLineAvailable() {
        return lineAvailable;
    }
    public void setLineAvailable(String lineAvailable) {
        this.lineAvailable = lineAvailable;
    }
    public String getAvailableCalculated() {
        return availableCalculated;
    }
    public void setAvailableCalculated(String availableCalculated) {
        this.availableCalculated = availableCalculated;
    }
    public String getFactorAvailable() {
        return factorAvailable;
    }
    public void setFactorAvailable(String factorAvailable) {
        this.factorAvailable = factorAvailable;
    }
    public String getTea() {
        return tea;
    }
    public void setTea(String tea) {
        this.tea = tea;
    }
    public String getCapitalizedDays() {
        return capitalizedDays;
    }
    public void setCapitalizedDays(String capitalizedDays) {
        this.capitalizedDays = capitalizedDays;
    }
    public String getMinimumOffer() {
        return minimumOffer;
    }
    public void setMinimumOffer(String minimumOffer) {
        this.minimumOffer = minimumOffer;
    }
    public String getInterestMinimumOffer() {
        return interestMinimumOffer;
    }
    public void setInterestMinimumOffer(String interestMinimumOffer) {
        this.interestMinimumOffer = interestMinimumOffer;
    }
    public String getOfferIncreaseLine() {
        return offerIncreaseLine;
    }
    public void setOfferIncreaseLine(String offerIncreaseLine) {
        this.offerIncreaseLine = offerIncreaseLine;
    }
    public String getAvailableOfferIncreaseLine() {
        return availableOfferIncreaseLine;
    }
    public void setAvailableOfferIncreaseLine(String availableOfferIncreaseLine) {
        this.availableOfferIncreaseLine = availableOfferIncreaseLine;
    }
    public String getInterestOfferIncreaseLine() {
        return interestOfferIncreaseLine;
    }
    public void setInterestOfferIncreaseLine(String interestOfferIncreaseLine) {
        this.interestOfferIncreaseLine = interestOfferIncreaseLine;
    }
    public String getOfferWithoutLineIncrease() {
        return offerWithoutLineIncrease;
    }
    public void setOfferWithoutLineIncrease(String offerWithoutLineIncrease) {
        this.offerWithoutLineIncrease = offerWithoutLineIncrease;
    }
    public String getAvailableOfferWithoutLineIncrease() {
        return AvailableOfferWithoutLineIncrease;
    }
    public void setAvailableOfferWithoutLineIncrease(String AvailableOfferWithoutLineIncrease) {
        this.AvailableOfferWithoutLineIncrease = AvailableOfferWithoutLineIncrease;
    }
    public String getInterestOfferWithoutLineIncrease() {
        return interestOfferWithoutLineIncrease;
    }
    public void setInterestOfferWithoutLineIncrease(String interestOfferWithoutLineIncrease) {
        this.interestOfferWithoutLineIncrease = interestOfferWithoutLineIncrease;
    }
}
