package com.interbank.pe.utils.soap;

import java.text.DecimalFormat;
import java.util.Random;

public class UtilsTarjeta {
    public static String truncarPAN(String a) {
        String pan = "";
        if (a.length() == 16) {
            pan = a.substring(0, 6) + "******" + a.substring(12);
        } else if (a.length() == 15) {
            pan = a.substring(0, 6) + "*****" + a.substring(11);
        } else {
            System.out.println("PAN erroneo" + "\n");
        }
        return pan;
    }

    public static boolean existsValue(String[] array, int index) {
        boolean result = false;
        try {
            String valor = array[index];
            result = true;
        } catch (Exception ignored) {

        }
        return result;
    }

    public static Double montoAleatorioRandom(Double ini, Double fin) {
        DecimalFormat df = new DecimalFormat("#.##");

        Random random = new Random();

        int numeroAleatorio = (int) (random.nextInt((int) (fin - ini + 1)) + ini);

        String valorFormateadoStr = df.format(numeroAleatorio);
        return Double.parseDouble(valorFormateadoStr);
    }

    public static double parseStringToDouble(String input) {
        // Obtenemos los dos ultimos caracteres del string (parte decimal)
        String decimalString = input.substring(input.length() - 2);

        // Obtenemos el substring sin la parte decimal
        String integerString = input.substring(0, input.length() - 2);

        // Eliminamos los ceros iniciales
        integerString = integerString.replaceFirst("^0+(?!$)", "");

        // Convertimos el substring a double
        double result = Double.parseDouble(integerString);

        // Agregamos la parte decimal
        result += Double.parseDouble(decimalString) / 100;

        return result;
    }
}
