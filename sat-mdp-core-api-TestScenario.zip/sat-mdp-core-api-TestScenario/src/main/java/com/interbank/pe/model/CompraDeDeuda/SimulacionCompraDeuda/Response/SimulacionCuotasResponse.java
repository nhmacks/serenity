package com.interbank.pe.model.CompraDeDeuda.SimulacionCompraDeuda.Response;

public class SimulacionCuotasResponse {
    private InformacionSimulacion informacionSimulacion;

    public InformacionSimulacion getSimulationInformation() {
        return informacionSimulacion;
    }

    public void setSimulationInformation(InformacionSimulacion informacionSimulacion) {
        this.informacionSimulacion = informacionSimulacion;
    }
}