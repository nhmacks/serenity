package com.interbank.pe.model.cliente.cliente.RequestCrearCliente;

public class MessageRequest {
    private Header Header;
    private Body Body;
    public Header getHeader() {
        return Header;
    }
    public void setHeader(Header Header) {
        this.Header = Header;
    }
    public Body getBody() {
        return Body;
    }
    public void setBody(Body Body) {
        this.Body = Body;
    }
}