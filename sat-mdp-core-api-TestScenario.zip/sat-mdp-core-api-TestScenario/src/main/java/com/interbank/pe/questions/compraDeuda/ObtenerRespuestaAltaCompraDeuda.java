package com.interbank.pe.questions.compraDeuda;

import com.interbank.pe.model.CompraDeDeuda.DesembolsoCompraDeuda.Response.ResponseAltaCompraDeuda;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class ObtenerRespuestaAltaCompraDeuda implements Question<ResponseAltaCompraDeuda> {
    @Override
    public ResponseAltaCompraDeuda answeredBy(Actor actor) {
        return SerenityRest.lastResponse().as(ResponseAltaCompraDeuda.class);
    }
}
