package com.interbank.pe.model.cliente.cliente.ResponseCrearCliente;

public class HeaderResponse {
    private String timestamp;
    private Status status;
    public String getTimestamp() {
        return timestamp;
    }
    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
    public Status getStatus() {
        return status;
    }
    public void setStatus(Status status) {
        this.status = status;
    }
}