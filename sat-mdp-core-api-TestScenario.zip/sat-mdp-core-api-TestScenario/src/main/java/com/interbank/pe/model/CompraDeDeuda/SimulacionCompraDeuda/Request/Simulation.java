package com.interbank.pe.model.CompraDeDeuda.SimulacionCompraDeuda.Request;

public class Simulation {
    private String processType;
    private String contractId;
    private String cardId;
    private String amount;
    private String paymentTerm;
    private String deferredTerm;
    private String newAmount;
    private String currency;
    private String tem;
    private String maximumAmount;
    private String minimumAmount;
    private String percentageAvailable;
    private String user;
    public String getProcessType() {
        return processType;
    }
    public void setProcessType(String processType) {
        this.processType = processType;
    }
    public String getContractId() {
        return contractId;
    }
    public void setContractId(String contractId) {
        this.contractId = contractId;
    }
    public String getCardId() {
        return cardId;
    }
    public void setCardId(String cardId) {
        this.cardId = cardId;
    }
    public String getAmount() {
        return amount;
    }
    public void setAmount(String amount) {
        this.amount = amount;
    }
    public String getPaymentTerm() {
        return paymentTerm;
    }
    public void setPaymentTerm(String paymentTerm) {
        this.paymentTerm = paymentTerm;
    }
    public String getDeferredTerm() {
        return deferredTerm;
    }
    public void setDeferredTerm(String deferredTerm) {
        this.deferredTerm = deferredTerm;
    }
    public String getNewAmount() {
        return newAmount;
    }
    public void setNewAmount(String newAmount) {
        this.newAmount = newAmount;
    }
    public String getCurrency() {
        return currency;
    }
    public void setCurrency(String currency) {
        this.currency = currency;
    }
    public String getTem() {
        return tem;
    }
    public void setTem(String tem) {
        this.tem = tem;
    }
    public String getMaximumAmount() {
        return maximumAmount;
    }
    public void setMaximumAmount(String maximumAmount) {
        this.maximumAmount = maximumAmount;
    }
    public String getMinimumAmount() {
        return minimumAmount;
    }
    public void setMinimumAmount(String minimumAmount) {
        this.minimumAmount = minimumAmount;
    }
    public String getPercentageAvailable() {
        return percentageAvailable;
    }
    public void setPercentageAvailable(String percentageAvailable) {
        this.percentageAvailable = percentageAvailable;
    }
    public String getUser() {
        return user;
    }
    public void setUser(String user) {
        this.user = user;
    }
}