package com.interbank.pe.model.Extracash.DesembolsoIncrementoLinea.Request;

public class Transaction {
    private String currencyId;
    private Double amount;

    public String getCurrencyId() {
        return currencyId;
    }

    public void setCurrencyId(String currencyId) {
        this.currencyId = currencyId;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }
}
