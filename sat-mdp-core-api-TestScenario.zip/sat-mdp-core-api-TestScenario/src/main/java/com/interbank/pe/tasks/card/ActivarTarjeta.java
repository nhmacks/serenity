package com.interbank.pe.tasks.card;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Post;

import java.io.IOException;

import static com.interbank.pe.utils.soap.EnumRequestSoap.ACTIVAR_TARJETA;
import static com.interbank.pe.utils.soap.UtilisSoap.obtenerRequestSoap;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class ActivarTarjeta implements Task {

    private final String tarjeta;

    public ActivarTarjeta(String tarjeta) {
        this.tarjeta = tarjeta;
    }
    public static ActivarTarjeta nueva(String tarjeta){
        return instrumented(ActivarTarjeta.class, tarjeta);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Post.to("ibk/srv/MPO/Colocaciones/activarTarjeta/v1.0")
                        .with(
                                request ->
                                        request
                                                .relaxedHTTPSValidation()
                                                .header("SOAPAction", "http://interbank.com.pe/service/MPO/Colocaciones/activarTarjeta/v1.0/")
                                                .header("charset", "*/*")
                                                .header("Content-Type", "text/xml;charset=UTF-8")
                                                .header("Accept-Encoding","gzip,deflate")
                                                .header("charset", "ISO-8859-1")
                                                .body(ObtenerRequestActivarTarjeta(tarjeta))
                        )
        );
    }

    private String ObtenerRequestActivarTarjeta(String tarjeta) {
        try {
            return obtenerRequestSoap(ACTIVAR_TARJETA.getPathArchivo())
                    .replace("${numero_tarjeta}", tarjeta);
        } catch (IOException e) {
            return null;
        }
    }
}
