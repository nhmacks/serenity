package com.interbank.pe.model.Extracash.SimulacionCuotas;

public class SimulacionCuotaRequest {
    private String cardId;
    private String referenceId;
    private String documentType;
    private Double simulationAmount;
    private Integer payTerm;
    private Integer deferredTerm;
    private Double newLineAmount;


    public String getCardId() {
        return cardId;
    }

    public void setCardId(String cardId) {
        this.cardId = cardId;
    }

    public Double getSimulationAmount() {
        return simulationAmount;
    }

    public void setSimulationAmount(Double simulationAmount) {
        this.simulationAmount = simulationAmount;
    }

    public Integer getPayTerm() {
        return payTerm;
    }

    public void setPayTerm(Integer payTerm) {
        this.payTerm = payTerm;
    }

    public Integer getDeferredTerm() {
        return deferredTerm;
    }

    public void setDeferredTerm(Integer deferredTerm) {
        this.deferredTerm = deferredTerm;
    }

    public Double getNewLineAmount() {
        return newLineAmount;
    }

    public void setNewLineAmount(Double newLineAmount) {
        this.newLineAmount = newLineAmount;
    }

    public String getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(String referenceId) {
        this.referenceId = referenceId;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

}
