package com.interbank.pe.model.CompraDeDeuda.DesembolsoCompraDeuda.Request;

import java.util.ArrayList;
import java.util.List;

public class Registration {
    private String processType;
    private String contractId;
    private String cardId;
    private String typeLine;
    private String typeDebt;
    private String newLine;
    private String itemNumber;
    private List<Purchase> purchases = new ArrayList<Purchase>();
    private String seller;
    private String currencyCode;
    private String installmentNumber;
    private String consolidatedRate;
    private String catcherBranch;
    private String debtAmount;
    private String graceMonth;
    private String customerId;
    private String offeredRate;
    private String user;
    public String getProcessType() {
        return processType;
    }
    public void setProcessType(String processType) {
        this.processType = processType;
    }
    public String getContractId() {
        return contractId;
    }
    public void setContractId(String contractId) {
        this.contractId = contractId;
    }
    public String getCardId() {
        return cardId;
    }
    public void setCardId(String cardId) {
        this.cardId = cardId;
    }
    public String getTypeLine() {
        return typeLine;
    }
    public void setTypeLine(String typeLine) {
        this.typeLine = typeLine;
    }
    public String getTypeDebt() {
        return typeDebt;
    }
    public void setTypeDebt(String typeDebt) {
        this.typeDebt = typeDebt;
    }
    public String getNewLine() {
        return newLine;
    }
    public void setNewLine(String newLine) {
        this.newLine = newLine;
    }
    public String getItemNumber() {
        return itemNumber;
    }
    public void setItemNumber(String itemNumber) {
        this.itemNumber = itemNumber;
    }
    public List<Purchase> getPruchases() {
        return purchases;
    }
    public void setPurchases(List<Purchase> purchases) {
        this.purchases = purchases;
    }
    public String getSeller() {
        return seller;
    }
    public void setSeller(String seller) {
        this.seller = seller;
    }
    public String getCurrencyCode() {
        return currencyCode;
    }
    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }
    public String getInstallmentNumber() {
        return installmentNumber;
    }
    public void setInstallmentNumber(String installmentNumber) {
        this.installmentNumber = installmentNumber;
    }
    public String getConsolidatedRate() {
        return consolidatedRate;
    }
    public void setConsolidatedRate(String consolidatedRate) {
        this.consolidatedRate = consolidatedRate;
    }
    public String getCatcherBranch() {
        return catcherBranch;
    }
    public void setCatcherBranch(String catcherBranch) {
        this.catcherBranch = catcherBranch;
    }
    public String getDebtAmount() {
        return debtAmount;
    }
    public void setDebtAmount(String debtAmount) {
        this.debtAmount = debtAmount;
    }
    public String getGraceMonth() {
        return graceMonth;
    }
    public void setGraceMonth(String graceMonth) {
        this.graceMonth = graceMonth;
    }
    public String getCustomerId() {
        return customerId;
    }
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }
    public String getOfferedRate() {
        return offeredRate;
    }
    public void setOfferedRate(String offeredRate) {
        this.offeredRate = offeredRate;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }
}
