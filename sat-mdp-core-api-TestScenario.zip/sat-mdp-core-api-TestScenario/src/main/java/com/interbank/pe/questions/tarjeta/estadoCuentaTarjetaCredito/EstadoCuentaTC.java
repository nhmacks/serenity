package com.interbank.pe.questions.tarjeta.estadoCuentaTarjetaCredito;

import com.interbank.pe.model.tarjeta.EstadoCuentaTarjetaCredito.EstadoCuentaTarjetaCredito;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class EstadoCuentaTC implements Question<EstadoCuentaTarjetaCredito> {
    @Override
    public EstadoCuentaTarjetaCredito answeredBy(Actor actor) {
        return SerenityRest.lastResponse().as(EstadoCuentaTarjetaCredito.class);
    }
}
