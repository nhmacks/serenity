package com.interbank.pe.questions.campanna;

import com.interbank.pe.model.campaign.CampannaDiariaExtracash;
import net.serenitybdd.screenplay.Actor;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.interbank.pe.utils.soap.EnumRequestSoap.CAMPANNA_DIARIA_TC_CSV;
import static com.interbank.pe.utils.soap.UtilsTarjeta.existsValue;

public class ListaCampannaDiariaExtracash {
    public List<CampannaDiariaExtracash> answeredBy(Actor actor) {
        String filePath = CAMPANNA_DIARIA_TC_CSV.getPathArchivo();
        String line = "";
        LocalTime horaPrimerBatch = LocalTime.of(13, 0);
        LocalTime horaSegundoBath = LocalTime.of(17, 0);
        List<CampannaDiariaExtracash> campannaDiariaExtracashList = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            int contador = 0;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length >= 17 & contador > 0) {
                    CampannaDiariaExtracash campannaDiariaExtracash = new CampannaDiariaExtracash(
                            existsValue(data, 0) ? data[0] : "",
                            existsValue(data, 1) ? data[1] : "",
                            existsValue(data, 2) ? data[2] : "",
                            existsValue(data, 3) ? data[3] : "",
                            existsValue(data, 4) ? data[4] : "",
                            existsValue(data, 5) ? data[5] : "",
                            existsValue(data, 6) ? data[6] : "",
                            existsValue(data, 7) ? data[7] : "",
                            existsValue(data, 8) ? data[8] : "",
                            existsValue(data, 9) ? data[9] : "",
                            existsValue(data, 10) ? data[10] : "",
                            existsValue(data, 11) ? data[11] : "",
                            existsValue(data, 12) ? data[12] : "",
                            existsValue(data, 13) ? data[13] : "",
                            existsValue(data, 14) ? data[14] : "",
                            existsValue(data, 15) ? data[15] : "",
                            existsValue(data, 16) ? data[16] : "",
                            existsValue(data, 17) ? data[17] : ""

                    );

                    String cadenaCreacionCampanna = campannaDiariaExtracash.getFechaCreacionCampanna();
                    LocalDateTime fechaHora = LocalDateTime.parse(cadenaCreacionCampanna);
                    LocalTime horaActivacionTC = LocalTime.of(fechaHora.getHour(), fechaHora.getMinute());
                    LocalDateTime fechaHoraHoy = LocalDateTime.now();
                    LocalTime horaHoy = LocalTime.of(fechaHoraHoy.getHour(), fechaHoraHoy.getMinute());

                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    Date fechaActivacionTC = dateFormat.parse(cadenaCreacionCampanna);

                    LocalDateTime dateTime = LocalDateTime.now();
                    Date fechaActual = dateFormat.parse(dateTime.toString());
                    if (fechaActivacionTC.equals(fechaActual)) {
                        if (horaActivacionTC.isBefore(horaPrimerBatch) && horaHoy.isAfter(horaPrimerBatch)) {

                            campannaDiariaExtracashList.add(campannaDiariaExtracash);
                        } else if (horaActivacionTC.isBefore(horaSegundoBath) && horaHoy.isAfter(horaSegundoBath)) {

                            campannaDiariaExtracashList.add(campannaDiariaExtracash);
                        }
                    } else {
                        campannaDiariaExtracashList.add(campannaDiariaExtracash);
                    }
                }
                contador++;

            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        return campannaDiariaExtracashList;
    }
}
