package com.interbank.pe.model.cliente.cuentas.request;

import java.util.ArrayList;
import java.util.List;

public class AccountRequest {
    private List<Account> accounts = new ArrayList<Account>();
    private List<Customer> customers = new ArrayList<Customer>();

    public List<Account> getAccounts() {
        return accounts;
    }

    public void setAccounts(List<Account> accounts) {
        this.accounts = accounts;
    }

    public List<Customer> getCustomers() {
        return customers;
    }

    public void setCustomers(List<Customer> customers) {
        this.customers = customers;
    }
}
